"""
Threading Examples for Stream Cinema Addon

This file demonstrates proper threading patterns using the improved
threading utilities that follow Kodi best practices.
"""

import time
from typing import List, Dict, Any
from resources.lib.common.threading_utils import (
    run_in_background, run_concurrent, ThreadSafeOperation,
    safe_notification, ensure_main_thread, get_thread_info
)
from resources.lib.common.thread_monitor import monitor_thread
from resources.lib.common.logger import debug

# Example 1: Simple background task
def example_background_task():
    """Example of running a simple task in the background"""
    
    def fetch_data():
        """Simulate fetching data from a remote source"""
        time.sleep(2)  # Simulate network delay
        return {"status": "success", "data": "example_data"}
    
    # Run the task in background with automatic error handling
    thread = run_in_background(fetch_data, timeout=10.0)
    
    # Continue with other work while background task runs
    debug("Background task started, continuing with other work...")
    
    # Wait for completion if needed
    thread.join(timeout=5.0)
    if thread.is_alive():
        debug("Background task is still running...")
    else:
        debug("Background task completed")

# Example 2: Concurrent stream resolution
def example_concurrent_streams():
    """Example of resolving multiple streams concurrently"""
    
    def resolve_stream(stream_url: str) -> Dict[str, Any]:
        """Simulate resolving a single stream"""
        time.sleep(1)  # Simulate resolution time
        return {
            "url": stream_url,
            "quality": "720p",
            "bitrate": 2500000,
            "resolved": True
        }
    
    # List of stream URLs to resolve
    stream_urls = [
        "https://example.com/stream1",
        "https://example.com/stream2", 
        "https://example.com/stream3",
        "https://example.com/stream4"
    ]
    
    # Create tasks for concurrent execution
    tasks = [lambda url=stream_url: resolve_stream(url) for stream_url in stream_urls]
    
    # Run all stream resolutions concurrently
    with ThreadSafeOperation("Stream Resolution", timeout=15.0):
        results = run_concurrent(tasks, max_workers=4, timeout=10.0)
        
        # Process results
        successful_streams = [r for r in results if r is not None and r.get("resolved")]
        debug(f"Successfully resolved {len(successful_streams)} out of {len(stream_urls)} streams")
        
        return successful_streams

# Example 3: UI-safe operations
@ensure_main_thread
def example_ui_operation(title: str, message: str):
    """Example of a function that must run on the main thread"""
    from resources.lib.gui.dialog import dok
    return dok(title, message)

def example_background_with_ui_callback():
    """Example of background work with UI callback on main thread"""
    
    def background_work():
        """Do work in background"""
        time.sleep(3)
        return "Background work completed"
    
    def ui_callback(result: str):
        """Handle result on main thread"""
        if result:
            safe_notification("Success", result, time=3000)
        else:
            safe_notification("Error", "Background work failed", time=3000)
    
    # Start background work
    thread = run_in_background(background_work, timeout=10.0)
    
    # Wait for completion and handle result on main thread
    thread.join(timeout=5.0)
    
    # This would need to be called from main thread in real usage
    # ui_callback("Background work completed")

# Example 4: Thread monitoring
@monitor_thread
def example_monitored_function():
    """Example function with automatic thread monitoring"""
    debug("Starting monitored function")
    time.sleep(1)
    debug("Monitored function completed")
    return "success"

def example_thread_monitoring():
    """Example of using thread monitoring"""
    
    # Run a monitored function in background
    run_in_background(example_monitored_function)
    
    # Get thread information
    thread_info = get_thread_info()
    debug(f"Current thread info: {thread_info}")
    
    # Check thread health (would typically be done in service)
    from resources.lib.common.thread_monitor import get_thread_health_report
    health_report = get_thread_health_report()
    debug(f"Thread health: {'OK' if health_report['healthy'] else 'ISSUES'}")

# Example 5: Download with progress
def example_download_with_progress():
    """Example of a download operation with progress tracking"""
    
    def download_file(url: str, filename: str) -> bool:
        """Simulate file download with progress"""
        total_size = 100  # Simulate 100MB file
        downloaded = 0
        
        while downloaded < total_size:
            time.sleep(0.1)  # Simulate download time
            downloaded += 5   # Simulate 5MB chunks
            
            # Update progress (would use proper progress dialog in real usage)
            progress = int((downloaded / total_size) * 100)
            if progress % 20 == 0:  # Log every 20%
                debug(f"Download progress: {progress}%")
        
        return True
    
    # Start download in background
    with ThreadSafeOperation("File Download", timeout=30.0):
        thread = run_in_background(
            download_file,
            "https://example.com/file.mp4",
            "movie.mp4",
            timeout=25.0
        )
        
        # Could show progress dialog here while waiting
        thread.join()
        
        if thread.is_alive():
            debug("Download timed out")
            return False
        else:
            debug("Download completed")
            return True

# Example 6: Error handling in threads
def example_error_handling():
    """Example of proper error handling in background threads"""
    
    def risky_operation():
        """Function that might fail"""
        import random
        if random.random() < 0.5:
            raise Exception("Random failure occurred")
        return "Operation succeeded"
    
    # The run_in_background function automatically handles errors
    # and logs them without crashing the main thread
    thread = run_in_background(risky_operation, timeout=5.0)
    thread.join()
    
    # Check if thread completed successfully by checking if it's still alive
    # (it will die if an exception occurred)
    if not thread.is_alive():
        debug("Risky operation completed (success or failure)")

# Example 7: Cleanup and resource management
def example_cleanup():
    """Example of proper cleanup"""
    
    def long_running_task():
        """Task that might run for a while"""
        for i in range(10):
            time.sleep(1)
            debug(f"Long task progress: {i+1}/10")
    
    # Start task
    thread = run_in_background(long_running_task, timeout=15.0)
    
    # Simulate some other work
    time.sleep(3)
    
    # Clean up if needed (automatic with daemon threads)
    from resources.lib.common.threading_utils import cleanup_active_threads
    cleanup_active_threads(timeout=2.0)

if __name__ == "__main__":
    # Run examples (for testing purposes)
    debug("=== Threading Examples ===")
    
    debug("1. Background task example")
    example_background_task()
    
    debug("2. Concurrent streams example")
    example_concurrent_streams()
    
    debug("3. Thread monitoring example")
    example_thread_monitoring()
    
    debug("4. Download with progress example")
    example_download_with_progress()
    
    debug("5. Error handling example")
    example_error_handling()
    
    debug("6. Cleanup example")
    example_cleanup()
    
    debug("=== Examples completed ===") 