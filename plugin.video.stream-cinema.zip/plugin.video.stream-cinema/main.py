# -*- coding: utf-8 -*-
import os

# Only set log level once per session using environment variable check
if not os.environ.get('SC_LOG_LEVEL_SET'):
    try:
        import xbmc
        xbmc._set_log_level(1)
        os.environ['SC_LOG_LEVEL_SET'] = '1'
    except Exception:
        # Silently ignore errors during Kodi log level setup
        pass

# Optimize startup with lazy imports and reduced overhead
def main():
    try:
        # Only import timing if debug mode is active to reduce overhead
        debug_mode = os.getenv('KODI_DEBUG', '').lower() in ['1', 'true']
        
        if debug_mode:
            import time
            start = time.time()
        
        from resources.lib.streamcinema import Scinema
        Scinema().run()
        
        if debug_mode:
            end = time.time()
            from resources.lib.common.logger import info
            info('ALL took {:.2f}ms'.format((end - start) * 1000))
    except Exception:
        # Optimize error handling - only import when needed
        import traceback
        from resources.lib.common.logger import info
        info('-----------------------------------------------------------------')
        info('main error [{}]'.format(str(traceback.format_exc())))
        info('-----------------------------------------------------------------')

if __name__ == '__main__':
    main()
