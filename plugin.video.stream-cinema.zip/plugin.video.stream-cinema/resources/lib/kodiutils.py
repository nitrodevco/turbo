from __future__ import annotations
"""
Refactored utility helpers for the Stream Cinema add‑on.
────────────────────────────────────────────────────
Changes vs. legacy version
─────────────────────────
* Dropped all Python 2 compatibility code.
* Removed busy‑wait loops – now rely on ``xbmc.Monitor().waitForAbort``.
* Directly use modern Kodi APIs (`xbmcvfs.translatePath`,   
  `xbmcvfs.makeLegalFilename`, `SetClipboard`).
* Hardened URL helpers – no ad‑hoc hex encodings, no   
  attempt to sanitise arbitrary built‑ins (only whitelisted wrappers).
* UUID generation: one‑time ``uuid4`` persisted to add‑on settings;   
  avoids platform‑specific subprocess calls.
* Exception scopes narrowed; all errors are logged.

All public function names from the old module are preserved so the rest
of the plug‑in does not need to change.
"""

import json
import os
import sys
import time
import uuid
from base64 import b64encode
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode, urlparse, parse_qs

# Re-export urlencode for backward compatibility  
# Note: urlencode is imported from urllib.parse and available for import

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.common.logger import debug, info
from resources.lib.constants import ADDON_ID, SC

# ──────────────────────────────────────────
# Add‑on & paths
# ──────────────────────────────────────────
addon: xbmcaddon.Addon = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PROFILE: str = addon.getAddonInfo("profile")  # special://profile/addon_data/…

# ──────────────────────────────────────────
# Basic helpers
# ──────────────────────────────────────────

def translate_path(path: str) -> str:
    """Modern path translator (raises on failure)."""
    return xbmcvfs.translatePath(path)


def sleep(sleep_time: int) -> None:
    """Non‑busy sleep that cancels immediately when Kodi is shutting down."""
    xbmc.Monitor().waitForAbort(sleep_time / 1000.0)


# Settings ────────────────────────────────

def get_setting(key: str) -> str:
    """Get addon setting value with error handling."""
    try:
        return addon.getSetting(key)
    except Exception as e:
        debug(f"Failed to get setting '{key}': {str(e)}")
        return ""


def set_setting(key: str, value: str | bool | int) -> None:
    """Set addon setting value."""
    debug(f"set_setting {key} -> {value}")
    addon.setSetting(key, str(value))


def set_setting_as_bool(key: str, value: bool) -> None:
    """Set setting as boolean."""
    set_setting(key, value)


def get_setting_as_bool(key: str) -> bool:
    """Get setting as boolean."""
    return addon.getSettingBool(key)


def get_setting_as_int(key: str) -> Optional[int]:
    """Get setting as integer."""
    try:
        return addon.getSettingInt(key)
    except (RuntimeError, TypeError):
        # Handle text settings that contain numeric values
        v = addon.getSetting(key)
        if not v:
            return None
        try:
            return int(v)
        except (ValueError, TypeError):
            return None


# System settings ─────────────────────────

def get_system_debug() -> bool:
    """Get Kodi system debug setting."""
    result = jsonrpc(
        method='Settings.GetSettingValue',
        params=dict(setting="debug.showloginfo")
    )
    return result.get('result', {}).get('value', False)


def set_system_debug(new_val: bool) -> Dict[str, Any]:
    """Set Kodi system debug setting."""
    return jsonrpc(
        method='Settings.SetSettingValue', 
        params=dict(setting="debug.showloginfo", value=new_val)
    )


def set_update_addons(new_val: int) -> Dict[str, Any]:
    """Set addon update mode."""
    return jsonrpc(
        method='Settings.SetSettingValue', 
        params=dict(setting="addons.updatemode", value=new_val)
    )


def set_general_addonupdates(new_val: int) -> Dict[str, Any]:
    """Set general addon updates setting."""
    return jsonrpc(
        method='Settings.SetSettingValue', 
        params=dict(setting="general.addonupdates", value=new_val)
    )


# App info ────────────────────────────────

def get_app_name() -> str:
    """Get Kodi application name."""
    try:
        data = jsonrpc(method='Application.GetProperties', params=dict(properties=["name"]))
        if "result" in data and "name" in data["result"]:
            return data["result"]["name"]
    except Exception:
        debug('ERR app name: failed to get application name')
    return "Kodi"


# Info labels & system data ───────────────

def get_info_label(label: str) -> str:
    """Get Kodi info label."""
    return xbmc.getInfoLabel(label)


def get_kodi_version() -> str:
    """Get Kodi version."""
    return get_info_label('System.BuildVersion')


def get_screen_width() -> str:
    """Get screen width."""
    return get_info_label('System.ScreenWidth')


def get_screen_height() -> str:
    """Get screen height."""
    return get_info_label('System.ScreenHeight')


def get_system_platform() -> str:
    """Get system platform."""
    platform = "unknown"
    if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.android'):
        platform = "linux"
    elif xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
        platform = "android"
    elif xbmc.getCondVisibility('system.platform.uwp'):
        platform = "uwp"
    elif xbmc.getCondVisibility('system.platform.windows'):
        platform = "windows"
    elif xbmc.getCondVisibility('system.platform.osx'):
        platform = "osx"
    elif xbmc.getCondVisibility('system.platform.ios'):
        platform = "ios"
    return platform


# Device UUID ─────────────────────────────

_uuid_cache = None
_uuid_cache_time = 0


def get_uuid() -> str:
    """Stable per‑device identifier with caching to avoid repeated expensive system calls."""
    # pylint: disable=global-statement
    global _uuid_cache, _uuid_cache_time
    import time
    
    # Cache UUID for 1 hour to avoid repeated expensive system calls
    current_time = time.time()
    if _uuid_cache and (current_time - _uuid_cache_time) < 3600:
        return _uuid_cache
    
    _uuid_cache = _get_system_uuid()
    _uuid_cache_time = current_time
    return _uuid_cache


# Containers & built‑ins ──────────────────

def _safe_builtin(cmd: str) -> None:
    """Execute a *known* built‑in without allowing arbitrary input."""
    debug(f"exec builtin: {cmd}")
    xbmc.executebuiltin(cmd, wait=False)


def exec_build_in(cmd: str) -> None:
    """Legacy compatibility wrapper for _safe_builtin."""
    _safe_builtin(cmd)


def container_refresh() -> None:
    """Refresh current container."""
    debug('container refresh')
    _safe_builtin("Container.Refresh")


def container_update(url: str, replace: bool = False) -> None:
    """Update container with new URL."""
    if replace:
        debug(f'container replace {url}')
        _safe_builtin(f"Container.Update({url},replace)")
    else:
        debug(f'container update {url}')
        _safe_builtin(f"Container.Update({url})")


def run_plugin(url: str) -> None:
    """Run plugin with URL."""
    debug(f'run plugin {url}')
    _safe_builtin(SC.RUN_PLUGIN.format(url))


def set_clipboard(text: str) -> None:
    """Cross‑platform clipboard via Kodi builtin (v20+)."""
    _safe_builtin(f"SetClipboard({text})")


# URL utilities ───────────────────────────

_ALLOWED_QUERY_KEYS: set[str] = {
    "dtitle", "url", "action", "list", "cmd", "down", "play", "user", "force",
    "search-list", "search", "csearch", "search-remove", "search-edit", "tl", "id",
    "subtype", "title", "name", "imdb", "tvdb", "csfd", "trakt", "content", "tu",
    "page", "selectStream", "headers", "filename", "info"  # Added for download manager compatibility
}


def create_plugin_url(params: Dict[str, Any]) -> str:
    """Create plugin URL from parameters."""
    filtered: Dict[str, str] = {
        k: str(v) for k, v in params.items() 
        if k in _ALLOWED_QUERY_KEYS and v not in (None, "")
    }
    qs = urlencode(sorted(filtered.items()))
    return f"plugin://{ADDON_ID}/?{qs}" if qs else f"plugin://{ADDON_ID}/"


def params(url: str) -> Dict[str, str]:
    """Parse URL parameters - legacy compatibility."""
    return parse_query(url)


def parse_query(url: str) -> Dict[str, str]:
    """Parse query parameters from URL."""
    if not url or not isinstance(url, str):
        return {}
    
    try:
        parsed = urlparse(url)
        return {k: v[0] for k, v in parse_qs(parsed.query).items()}
    except Exception as e:
        debug(f'Error parsing URL query: {e}')
        return {}


# Skin helpers ────────────────────────────

def get_skin_name() -> str:
    """Get current skin directory name."""
    return xbmc.getSkinDir()


# File system helpers ─────────────────────

def make_legal_filename(path: str) -> str:
    """Make filename legal for filesystem."""
    return xbmcvfs.makeLegalFilename(path)


def mkdir(path: str) -> bool:
    """Create directory."""
    return xbmcvfs.mkdir(make_legal_filename(path))


def file_exists(path: str) -> bool:
    """Check if file exists."""
    return xbmcvfs.exists(path)


def file_put_contents(file: str, data: bytes) -> None:
    """Write data to file."""
    with open(file, 'wb') as f:
        f.write(data)


def file_get_contents(file: str) -> bytes:
    """Read data from file."""
    with open(file, 'rb') as f:
        return f.read()


# Misc helpers ────────────────────────────

def microtime() -> float:
    """Get current time in milliseconds."""
    return time.time() * 1000.0


def convert_bitrate(mbit: float, with_text: bool = True) -> str | float:
    """Convert bitrate to readable format."""
    if mbit == 0 or mbit is None:
        return "0.00 Mbps" if with_text else 0
    
    mbps = round(mbit / 1000000, 2)
    return f"{mbps:.2f} Mbps" if with_text else mbps


# ——————————————————————————————————————————
# Files & NFO helpers
# ——————————————————————————————————————————

def make_nfo_content(item: Dict[str, Any], typ: str = "movie") -> str:
    """Generate NFO content from item data."""
    lines: List[str] = []
    if SC.ITEM_UIDS in item:
        uids = item[SC.ITEM_UIDS]
        if "csfd" in uids:
            lines.append(f"https://www.csfd.cz/film/{uids['csfd']}")
        if "imdb" in uids:
            lines.append(f"https://www.imdb.com/title/tt{uids['imdb']}")
        if "tmdb" in uids:
            lines.append(f"https://www.themoviedb.org/{typ}/{uids['tmdb']}-")
        if "tvdb" in uids:
            lines.append(f"https://www.thetvdb.com/dereferrer/series/{uids['tvdb']}")
        if "trakt" in uids:
            lines.append(f"https://trakt.tv/{typ}/{uids['trakt']}")
    return "\n".join(lines)


# JSON‑RPC wrapper with error logging
# ───────────────────────────────────

def jsonrpc(**payload: Any) -> Dict[str, Any]:
    """Execute JSON-RPC call to Kodi with enhanced error handling."""
    try:
        if "id" not in payload:
            payload["id"] = 0
        if "jsonrpc" not in payload:
            payload["jsonrpc"] = "2.0"
        
        request = json.dumps(payload)
        response = xbmc.executeJSONRPC(request)
        data = json.loads(response)
        
        if "error" in data:
            error_info = data['error']
            debug(f"JSON-RPC error: {error_info}")
            # Log more detailed error information
            if isinstance(error_info, dict):
                debug(f"Error code: {error_info.get('code', 'unknown')}")
                debug(f"Error message: {error_info.get('message', 'unknown')}")
        
        return data
        
    except json.JSONDecodeError as e:
        debug(f"JSON-RPC response decode error: {str(e)}")
        return {"error": {"code": -1, "message": "Invalid JSON response"}}
    except Exception as e:
        debug(f"JSON-RPC execution error: {str(e)}")
        return {"error": {"code": -1, "message": str(e)}}


# Signal helpers (Up Next etc.)
# ─────────────────────────────

def upnext_signal(sender: str, next_info: Dict[str, Any]) -> None:
    """Send Up Next signal."""
    payload = [b64encode(json.dumps(next_info).encode()).decode()]
    notify(sender=f"{sender}.SIGNAL", message="upnext_data", data=payload)


def notify(sender: str, message: str, data: Any) -> bool:
    """Send notification via JSON-RPC."""
    debug(f"notify → sender={sender}, message={message}")
    result = jsonrpc(
        method="JSONRPC.NotifyAll",
        params=dict(sender=sender, message=message, data=data),
    )
    return result.get("result") == "OK"


# Settings UI helpers ─────────────────────

def open_settings(query: Optional[str] = None, addon_id: str = ADDON_ID) -> None:
    """Open addon settings dialog."""
    try:
        _safe_builtin(f'Addon.OpenSettings({addon_id})')
        if query:
            try:
                c, f = query.split('.')
                focus_id1 = int(c) + 100
                focus_id2 = int(f) + 200
                _safe_builtin(f'SetFocus({focus_id1})')
                _safe_builtin(f'SetFocus({focus_id2})')
            except (ValueError, AttributeError):
                pass
    except Exception as e:
        debug(f'Error opening settings: {e}')


# Debug helpers ───────────────────────────

def check_set_debug(toggle: bool = False) -> None:
    """Check or toggle system debug setting."""
    current = get_system_debug()
    if toggle:
        new_value = not current
        set_system_debug(new_value)
        
        from resources.lib.common.threading_utils import safe_dialog_ok
        from resources.lib.language import Strings
        
        if new_value:
            safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), Strings.txt(Strings.SYSTEM_DEBUG_ENABLED))
        else:
            # upload_log_file()  # Disabled for privacy protection
            safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), Strings.txt(Strings.SYSTEM_DEBUG_DISABLED))


# Legacy encoding functions (simplified) ──

def encode(s: str, encoding: str = 'utf-8', errors: str = 'strict') -> str:
    """Legacy encode function - now just returns the string."""
    return s


def decode(s: str, encoding: str = 'utf-8', errors: str = 'strict') -> str:
    """Legacy decode function - now just returns the string."""
    return s


def hexlify(value: str) -> str:
    """Convert string to hex representation."""
    try:
        return value.encode('utf-8').hex()
    except Exception:
        import binascii
        return binascii.hexlify(value.encode('utf-8')).decode('utf-8')


# ISP detection helpers ───────────────────

def get_isp() -> Optional[Dict[str, str]]:
    """Get ISP information - DISABLED for privacy."""
    debug("ISP detection disabled for privacy")
    return None


def copy2clip(txt: str) -> None:
    """Copy text to clipboard."""
    try:
        set_clipboard(txt)
    except Exception:
        debug('Failed to copy to clipboard using Kodi builtin')


def upload_log_file(name: Optional[str] = None) -> None:
    """Upload log file to pastebin - DISABLED for privacy."""
    debug("Log file upload disabled for privacy")
    return


# ----------------------------------------------------------------------------
# Placeholder implementations kept for API compatibility. They now log & skip.
# ----------------------------------------------------------------------------

def clean_textures() -> None:  # pragma: no cover
    """Clean textures - implementation moved to dedicated service module."""
    debug("clean_textures() called – implementation moved to dedicated service module.")


def update_addon() -> None:  # pragma: no cover
    """Update addon - implementation moved to updater module."""
    debug("update_addon() called – implementation moved to updater module.")
    try:
        set_general_addonupdates(0)
        set_update_addons(1)
        _safe_builtin('UpdateAddonRepos')
        _safe_builtin("UpdateLocalAddons")
    except Exception as e:
        debug(f'Error updating addon: {e}')


# Platform-specific UUID implementations
def _get_system_uuid() -> str:
    """Get platform-specific system UUID."""
    system_platform = get_system_platform()
    debug('SYSTEM PLATFORM: {}'.format(system_platform))
    
    # Use cached platform detection to avoid repeated calls
    uuid_func_map = {
        'windows': _get_windows_uuid,
        'android': _get_android_uuid,
        'linux': _get_linux_uuid,
        'osx': _get_macos_uuid,
    }
    
    uuid_func = uuid_func_map.get(system_platform, _get_fake_uuid)
    uuid_val = uuid_func()
    
    if uuid_val is None:
        uuid_val = _get_fake_uuid()
    
    debug('UUID: {}'.format(uuid_val))
    return uuid_val


def _get_windows_uuid() -> str:
    """Get Windows machine GUID from registry."""
    # pylint: disable=broad-except
    # pylint: disable=import-error  # Under linux pylint rightly complains
    uuid_value = None
    try:
        import winreg
        registry = winreg.HKEY_LOCAL_MACHINE
        address = 'SOFTWARE\\Microsoft\\Cryptography'
        keyargs = winreg.KEY_READ | winreg.KEY_WOW64_64KEY
        key = winreg.OpenKey(registry, address, 0, keyargs)
        value = winreg.QueryValueEx(key, 'MachineGuid')
        winreg.CloseKey(key)
        uuid_value = value[0].strip()
    except Exception:
        pass
    if not uuid_value:
        try:
            import subprocess
            output = subprocess.check_output(['vol', 'c:'])
            output = output.split()
            uuid_value = output[len(output) - 1:].strip()
        except Exception:
            pass
    return uuid_value


def _get_linux_uuid() -> str:
    """Get Linux machine ID."""
    # pylint: disable=broad-except
    import subprocess
    uuid_value = None
    try:
        uuid_value = subprocess.check_output(['cat', '/var/lib/dbus/machine-id']).strip().decode('utf-8')
    except Exception:
        pass
    if not uuid_value:
        try:
            # Fedora linux
            uuid_value = subprocess.check_output(['cat', '/etc/machine-id']).strip().decode('utf-8')
        except Exception:
            pass
    return uuid_value


def _get_android_uuid() -> str:
    """Get Android device properties as UUID."""
    # pylint: disable=broad-except
    import subprocess
    import re
    values = 'xxx'
    try:
        # Due to the new android security we cannot get any type of serials
        sys_prop = ['ro.product.board', 'ro.product.brand', 'ro.product.device', 'ro.product.locale',
                    'ro.product.manufacturer',
                    'ro.product.model', 'ro.product.platform',
                    'persist.sys.timezone', 'persist.sys.locale', 'net.hostname']
        # Warning net.hostname property starting from android 10 is deprecated return empty
        proc = subprocess.Popen(['/system/bin/getprop'], stdout=subprocess.PIPE)
        output_data = proc.communicate()[0].decode('utf-8')
        list_values = output_data.splitlines()
        for value in list_values:
            value_splitted = re.sub(r'\[|\]|\s', '', value).split(':')
            if value_splitted[0] in sys_prop:
                values += value_splitted[1]
    except Exception:
        pass
    return values.strip()


def _get_macos_uuid() -> str:
    """Get macOS hardware UUID."""
    # pylint: disable=broad-except
    import subprocess
    sp_dict_values = None
    try:
        proc = subprocess.Popen(
            ['/usr/sbin/system_profiler', 'SPHardwareDataType', '-detaillevel', 'full', '-xml'],
            stdout=subprocess.PIPE)
        output_data = proc.communicate()[0].decode('utf-8')
        if output_data:
            sp_dict_values = _parse_osx_xml_plist_data(output_data)
    except Exception as exc:
        debug('error on popen {}'.format(exc))
        pass
    if sp_dict_values:
        if 'UUID' in list(sp_dict_values.keys()):
            return sp_dict_values['UUID'].strip()
        if 'serialnumber' in list(sp_dict_values.keys()):
            return sp_dict_values['serialnumber'].strip()
    return None


def _parse_osx_xml_plist_data(data: str) -> Dict[str, str]:
    """Parse macOS system_profiler XML plist data."""
    import plistlib
    import re
    dict_values = {}
    try:
        xml_data = plistlib.loads(data.encode())
    except:
        xml_data = plistlib.readPlistFromString(data)
    items_dict = xml_data[0]['_items'][0]
    r = re.compile(r'.*UUID.*')  # Find to example "platform_UUID" key
    uuid_keys = list(filter(r.match, list(items_dict.keys())))
    if uuid_keys:
        dict_values['UUID'] = items_dict[uuid_keys[0]]
    if not uuid_keys:
        r = re.compile(r'.*serial.*number.*')  # Find to example "serial_number" key
        serialnumber_keys = list(filter(r.match, list(items_dict.keys())))
        if serialnumber_keys:
            dict_values['serialnumber'] = items_dict[serialnumber_keys[0]]
    return dict_values


def _get_fake_uuid() -> str:
    """Legacy fake UUID - now uses real uuid4."""
    return str(uuid.uuid4())


def execute_builtin(command, wait=False):
    """
    Execute a Kodi builtin command with enhanced security validation.
    
    Args:
        command (str): The builtin command to execute
        wait (bool): Whether to wait for command completion
    """
    if not isinstance(command, str):
        debug("Invalid command type - must be string")
        return False
        
    # Enhanced security validation
    command = command.strip()
    if not command:
        debug("Empty command provided")
        return False
        
    # Whitelist of safe builtin commands
    safe_commands = [
        'Container.Refresh', 'Container.Update', 'UpdateLibrary',
        'Notification', 'Dialog.Close', 'Player.', 'Playlist.',
        'System.', 'Skin.', 'Window.', 'Control.', 'SetFocus'
    ]
    
    # Check if command starts with a safe prefix
    if not any(command.startswith(safe_cmd) for safe_cmd in safe_commands):
        debug(f"Potentially unsafe command blocked: {command}")
        return False
    
    # Additional validation for file operations
    if any(dangerous in command.lower() for dangerous in ['runscript', 'system.exec', 'activatewindow(programs']):
        debug(f"Dangerous command blocked: {command}")
        return False
        
    _safe_builtin(command)
    return True