# -*- coding: utf-8 -*-

import traceback

import xbmcgui
import xbmcplugin
import xbmc
from json import dumps

from resources.lib.common.kodivideocache import set_kodi_cache_size
from resources.lib.debug import performance
from resources.lib.intro import intro
from resources.lib.kodiutils import params, container_refresh, urlencode, container_update, create_plugin_url, \
    exec_build_in, get_setting, update_addon, set_setting_as_bool, notify, get_setting_as_bool
from resources.lib.common.logger import info, debug
from resources.lib.common.lists import List, SCKODIItem
from resources.lib.constants import SORT_METHODS, SC, GUI, ADDON_ID
from resources.lib.api.sc import Sc
from resources.lib.gui import cur_win, home_win
from resources.lib.gui.dialog import dok, dinput, dselect
from resources.lib.gui.item import SCItem, get_history_item_name, list_hp, SCLDir, SCUpNext
from resources.lib.common.storage import Storage, KodiViewModeDb, preferred_lang_list
from resources.lib.language import Strings
from resources.lib.params import params
from resources.lib.services.next_episodes import NextEp
from resources.lib.system import SYSTEM_LANG_CODE


class Scinema:
    def __init__(self):
        self.args = params.args
        self.items_pinned = []
        self.items = []
        self.response = []
        self.succeeded = False
        self.update_listing = False
        self.cache_to_disc = False
        self.url = '/'
        self.payload = None
        self.storage = Storage('scinema')
        self.send_end = False
        self.listType = None

    def run(self):
        # Reset global state for each plugin call to follow Kodi's execution model
        try:
            from resources.lib.common.storage import reset_global_storage_state
            reset_global_storage_state()
        except Exception as e:
            debug('Global state reset error: {}'.format(str(e)))

        if SC.ITEM_URL in self.args:
            self.url = self.args.get(SC.ITEM_URL)

        if self.url == '/' and xbmc.Player().isPlayingVideo() and home_win.getProperty('{}.play'.format(ADDON_ID)):
            container_update('special://home', True)
            self.succeeded = False
            self.end_of_directory()
            return

        if SC.ITEM_URL in self.args and self.args.get(SC.ITEM_URL).startswith('http'):
            self.args.update({SC.ITEM_ACTION: SC.ACTION_PLAY_URL})

        info('Start: {} [{}]'.format(str(self.args), self.url))

        if 'title' in self.args:
            home_win.setProperty('SCTitle', self.args.get('title'))
        else:
            home_win.clearProperty('SCTitle')

        if SC.ACTION in self.args:
            exit_code = self.action()
            if exit_code is True:
                return
        elif 'play' in self.args:
            '''
            stara URL zo SC CS&SK pre play aby fungovala kniznica
            '''
            self.url = self.args.get('play')
            self.call_url_and_response()
        else:
            self.call_url_and_response()
        self.end()

    def action(self):
        action = self.args.get(SC.ITEM_ACTION)
        if action == SC.ACTION_PLAY_URL:
            self.play_url(self.args.get(SC.ITEM_URL))
            self.succeeded = True
        elif action == SC.ACTION_CMD:
            self.action_cmd()
        elif action == 'intro':
            intro(2, True)
        elif action == SC.ACTION_PIN:
            self.action_pin()
        elif action == SC.ACTION_CSEARCH:
            self.action_csearch()
        elif action == SC.ACTION_LAST:
            self.action_last()
        elif action == 'nextep':
            self.action_next_ep()
        elif action == 'update_nextep':
            self.action_update_next_ep()
            return True
        elif action == 'search_next_episodes':
            self.action_search_next_episodes()
        elif action == SC.ACTION_DEBUG:
            from resources.lib.kodiutils import check_set_debug

            check_set_debug(True)
        elif action == SC.ACTION_DOWNLOAD:
            self.url = self.args.get(SC.ITEM_DOWNLOAD)
            self.call_url_and_response()
        elif action == SC.ACTION_BUFFER:
            set_kodi_cache_size()
        elif action == SC.ACTION_ANDROID:
            self.action_android()
        elif action == SC.ACTION_ADD2HP:
            self.action_add2hp()
        elif action == SC.ACTION_DEL2HP:
            self.action_add2hp(True)
        elif action == SC.ACTION_ADD_CUSTOM_FILTER:
            self.action_add_custom_filter()
        elif action == SC.ACTION_DEL_CUSTOM_FILTER:
            self.action_add_custom_filter(True)
        elif action == SC.ACTION_REMOVE_FROM_LIST:
            self.action_remove_from_list()
        elif action == SC.ACTION_UPDATE_ADDON:
            update_addon()
        elif 'trakt.' in action:
            from resources.lib.trakt.Trakt import trakt
            trakt.action(action, self)
            return True
        elif action in ['add_to_library', 'add_to_library_sub']:
            lib = List(SC.ITEM_LIBRARY)
            lib.add(self.args.get(SC.ITEM_ID))
            if action == 'add_to_library_sub':
                sub = List(SC.ITEM_LIBRARY_SUB)
                sub.add(self.args.get(SC.ITEM_ID))
            container_refresh()
        elif action == 'remove_from_sub':
            lib = List(SC.ITEM_LIBRARY)
            lib.add(self.args.get(SC.ITEM_ID), True)
            if action == 'remove_from_sub':
                sub = List(SC.ITEM_LIBRARY_SUB)
                sub.add(self.args.get(SC.ITEM_ID), True)
            container_refresh()
        elif action == 'autocomplet':
            from resources.lib.services.autocomplete import Autocomplete
            Autocomplete(self.args)
            return True
        elif action == SC.ACTION_DEL_PREFERRED_LANGUAGE:
            del preferred_lang_list[self.args.get(SC.ITEM_ID)]
            container_refresh()
            return
        elif action == SC.ACTION_SET_PREFERRED_LANGUAGE:
            lang_list = Sc.get('/Lang/{}'.format(self.args.get(SC.ITEM_ID)))
            debug('parametre: {} / langs: {}'.format(self.args, lang_list))
            from resources.lib.common.threading_utils import safe_dialog_select
            ret = safe_dialog_select(lang_list, Strings.txt(Strings.CONTEXT_ADD_PREF_LANG))
            if ret > -1:
                st = preferred_lang_list
                st[self.args.get(SC.ITEM_ID)] = lang_list[ret]
                debug('znovelene: {} / {}'.format(ret, st[self.args.get(SC.ITEM_ID)]))
                container_refresh()
            return
        else:
            info('Neznama akcia: {}'.format(action))
        return False

    def action_remove_from_list(self):
        st = List(self.args[SC.ITEM_PAGE])
        st.add(self.args[SC.ITEM_ID], True)
        container_refresh()
        pass

    def action_android(self):
        st = List('android')
        st.add(self.args)

    def action_add2hp(self, remove=False):
        st = list_hp
        del self.args[SC.ACTION]
        if remove is False:
            label = dinput('Zadaj vlastny nazov', self.args[SC.ITEM_ID])
            if label == '':
                label = self.args[SC.ITEM_ID]
            self.args[SC.ITEM_ID] = label

        st.add(self.args, remove_only=remove)
        if remove is True:
            container_refresh()

    def action_add_custom_filter(self, remove=False):
        if SC.ITEM_PAGE in self.args:
            st = List(SC.TXT_CUSTOM_FORMAT.format(self.args[SC.ITEM_PAGE]))
        else:
            st = List(SC.TXT_CUSTOM_FORMAT.format(self.url))

        cfg = {
            SC.ITEM_URL: '',
            SC.ITEM_TITLE: '',
        }
        if remove is False:
            label = dinput('Zadaj nazov polozky')
            if label == '':
                label = self.args[SC.ITEM_ID]
            cfg[SC.ITEM_TITLE] = label

            url = dinput('Zadaj url pre [B]plugin[/B] z https://stream-cinema.online/filter', '')
            if url == '':
                return False
            cfg[SC.ITEM_URL] = url
        else:
            cfg.update({
                SC.ITEM_URL: self.args[SC.ITEM_URL],
                SC.ITEM_TITLE: self.args[SC.ITEM_TITLE],
            })

        st.add(cfg, remove_only=remove)
        if remove is True:
            container_refresh()

    def action_last(self):
        lid = get_history_item_name(self.args.get(SC.ITEM_ID))
        st = List(lid)
        if len(st.get()) > 0:
            self.url = '/Last'
            self.payload = {"ids": dumps(st.get())}
            self.call_url_and_response()
        else:
            if SC.ITEM_WIDGET not in self.args:
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.EMPTY_HISTORY_H1), Strings.txt(Strings.EMPTY_HISTORY_L1))

    def action_next_ep(self):
        st = NextEp().get()
        if len(st) > 0:
            self.url = '/Last?nextep=1'
            self.payload = dict(ids=dumps(st))
            self.call_url_and_response()
        else:
            pass

    def action_update_next_ep(self):
        st = NextEp()
        st.update_items()

    def action_cmd(self):
        url = self.args.get('url')
        if url.startswith('cmd://'):
            cmd = url[6:]
            
            # SECURITY: Comprehensive command validation with parameter checking
            # Define allowed commands with their EXACT permitted parameters
            allowed_commands = {
                # Navigation commands - no parameters
                'Action(Back)': True,
                'Container.Refresh': True,
                # Addon management - no parameters to prevent injection
                'UpdateAddonRepos': True,
                'UpdateLocalAddons': True,
            }
            
            # SECURITY: Strictly allowed Container.Update parameters (EXACT MATCH ONLY)
            safe_container_targets = [
                'special://home',
                'special://home,replace',
                'plugin://' + ADDON_ID + '/',  # Only root of our plugin
                'plugin://' + ADDON_ID,       # Root without trailing slash
            ]
            
            # SECURITY: Strictly allowed Addon.OpenSettings parameters
            safe_addon_settings = [
                ADDON_ID,  # Only our addon's settings
            ]
            
            # SECURITY: Block command chaining attempts
            if ';' in cmd or '&&' in cmd or '||' in cmd or '\n' in cmd or '\r' in cmd:
                info('SECURITY: Blocked command chaining attempt: {}'.format(cmd))
                return
            
            # SECURITY: Validate full command syntax with STRICT parameter checking
            cmd_validated = False
            
            # Check if it's a simple allowed command (inherently safe)
            if cmd in allowed_commands:
                cmd_validated = True
                
            # Check parameterized commands with STRICT validation
            elif '(' in cmd and cmd.endswith(')'):
                base_cmd = cmd.split('(')[0]
                params_str = cmd[len(base_cmd)+1:-1]  # Extract parameter string
                
                # SECURITY: Apply Kodi built-in check to parameters only (avoid false positives)
                kodi_builtins = [
                    'runscript', 'runplugin', 'runaddon', 'playmedia', 'sendclick',
                    'activatewindow', 'system.', 'xbmc.', 'executebuiltin', 'extract',
                    'eval', 'exec', 'import', '__', 'subprocess', 'os.system', 'popen'
                ]
                params_lower = params_str.lower()
                for builtin in kodi_builtins:
                    if builtin in params_lower:
                        info('SECURITY: Blocked Kodi built-in in parameters: {}'.format(builtin))
                        return
                
                # STRICT Container.Update validation - EXACT MATCH ONLY
                if base_cmd == 'Container.Update':
                    if params_str in safe_container_targets:
                        cmd_validated = True
                    else:
                        info('SECURITY: Blocked unsafe Container.Update target: {}'.format(params_str))
                        return  # Immediate exit on validation failure
                        
                # STRICT Addon.OpenSettings validation - EXACT MATCH ONLY  
                elif base_cmd == 'Addon.OpenSettings':
                    if params_str in safe_addon_settings:
                        cmd_validated = True
                    else:
                        info('SECURITY: Blocked unsafe Addon.OpenSettings target: {}'.format(params_str))
                        return  # Immediate exit on validation failure
                        
                # Reject any other parameterized commands not explicitly handled
                else:
                    info('SECURITY: Blocked unknown parameterized command: {}'.format(base_cmd))
                    return  # Immediate exit for unknown commands
                    
            # Reject any other command structures not explicitly handled
            else:
                info('SECURITY: Blocked unrecognized command structure: {}'.format(cmd))
                return  # Immediate exit for unrecognized structures
                
            # SECURITY: Final validation check (should be True at this point)
            if not cmd_validated:
                info('SECURITY: Blocked unauthorized command: {}'.format(cmd))
                return
                
            # SECURITY: Additional length check to prevent buffer overflow attempts
            if len(cmd) > 200:
                info('SECURITY: Blocked overly long command: {}'.format(cmd[:50] + '...'))
                return
                
            info('CMD: {}'.format(cmd))
            exec_build_in(cmd)
            self.send_end = True

    # action_force_select_stream() removed - was empty and unused

    def action_pin(self):
        pinned = self.get_pinned()
        if pinned and self.args.get(SC.ITEM_ID) in pinned:
            info('remove')
            del pinned[self.args.get(SC.ITEM_ID)]
        else:
            info('add')
            pinned.update({self.args.get(SC.ITEM_ID): True})
        self.set_pinned(pinned)
        container_refresh()

    def action_csearch(self):
        self.succeeded = True
        self.end_of_directory()
        _id = self.args.get(SC.ITEM_ID)
        home_win.setProperty('SC.search', '{}'.format(_id))
        search = dinput('', '', xbmcgui.INPUT_TYPE_TEXT)
        home_win.clearProperty('SC.search')
        info('search string: {}'.format(search))
        if search == '':
            exec_build_in('Action(Back)')
            return
        query = {'search': search, SC.ITEM_ID: _id}
        if _id.startswith('search-people'):
            query.update({'ms': '1'})
        st = List(_id)
        st.add(search)
        debug('SEARCH: _ID "{}" search for "{}" people "{}"'.format(_id, search, 1 if 'ms' in query else 0))
        url = '/Search/{}?{}'.format(_id, urlencode(query))
        info('search url: {}'.format(url))
        self.url = url
        self.call_url()
        if 'msgERROR' in self.response.get('system', {}):
            self.msg_error()
            exec_build_in('Action(Back)')
            return
        plugin_url = create_plugin_url({'url': url})
        container_update(plugin_url)
        return

    def action_search_next_episodes(self):
        NextEp().run(True)

    def msg_error(self):
        if SC.ITEM_WIDGET in self.args:
            debug('Mame error hlasku, ale sme z widgetu, tak ju nezobrazujeme')
            return

        if 'msgERROR' in self.response.get('system', {}):
            debug('ERR REPOSNSE: {}'.format(self.response))
            # Fix: Safe access to nested data to prevent AttributeError
            system_data = self.response.get('system', {})
            data = system_data.get('msgERROR') if system_data else None
            if isinstance(data, dict):
                lang = SYSTEM_LANG_CODE
                i18n = data.get('i18n', {})
                if lang not in i18n:
                    debug('err pre jazyk {} nemame, tak nastavujem cs'.format(lang))
                    lang = SC.DEFAULT_LANG
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), '{}'.format(data['i18n'][lang]))
                pass
            else:
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), '{}'.format(data))
        else:
            debug('ERROR response: {}'.format(self.response))
            from resources.lib.common.threading_utils import safe_dialog_ok
            safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), Strings.txt(Strings.SYSTEM_API_ERROR_L1))

    def pinned_key(self):
        return SC.TXT_PINNED.format(self.url)

    def get_pinned(self):
        pinned = self.storage.get(self.pinned_key())
        if not pinned:
            pinned = {}
        return pinned

    def set_pinned(self, data):
        info('new pined {} for {}'.format(data, self.pinned_key()))
        self.storage[self.pinned_key()] = data

    def call_url_and_response(self):
        self.call_url()
        self.parse_response()

    def call_url(self):
        try:
            if self.payload is not None:
                debug('POST DATA: {}'.format(self.payload))
                self.response = Sc.post(self.url, data=self.payload)
            else:
                self.response = Sc.get(self.url)
        except Exception as e:
            # More specific error handling with fallback
            debug('CALL URL ERR: {}'.format(traceback.format_exc()))
            self.response = {
                'system': {
                    'msgERROR': {
                        'i18n': {
                            'cs': 'Chyba při načítání dat: {}'.format(str(e)),
                            'sk': 'Chyba pri načítaní dát: {}'.format(str(e)),
                            'en': 'Error loading data: {}'.format(str(e))
                        }
                    }
                }
            }

    def parse_response(self):
        if SC.ITEM_SYSTEM in self.response:
            self.system()

        if SC.ITEM_MENU in self.response:
            self.list()
        elif SC.ITEM_STRMS in self.response:
            return self.play()
        else:
            self.msg_error()

    def pinned_hp(self):
        st = list_hp
        for itm in st.get():
            info('HP item: {}'.format(itm))
            item = SCItem({'type': SC.ITEM_HPDIR, 'title': itm.get(SC.ITEM_ID), 'url': itm.get(SC.ITEM_URL)})
            if item.visible:
                info('Pridavam item na HP: {}'.format(itm.get(SC.ITEM_ID)))
                item.li().setProperty('SpecialSort', GUI.TOP)
                self.items_pinned.append(item.get())

    def pinned_custom(self):
        st = List(SC.TXT_CUSTOM_FORMAT.format(self.url))
        for itm in st.get():
            debug('custom item: {}'.format(itm))
            cfg = {
                SC.ITEM_TYPE: SC.ITEM_CUSTOM_FILTER,
                SC.ITEM_TITLE: itm.get(SC.ITEM_TITLE),
                SC.ITEM_URL: itm.get(SC.ITEM_URL),
                'self_url': self.url,
            }
            item = SCItem(cfg)
            if item.visible:
                item.li().setProperty('SpecialSort', GUI.TOP)
                self.items_pinned.append(item.get())

    def list(self):
        self.succeeded = True
        pinned = self.get_pinned()
        hidden = self.storage.get('h-{}'.format(self.url))
        self.pinned_custom()
        if self.url == '/':
            info('Mame HP, skontrolujeme pripnute polozky')
            self.pinned_hp()

        # Pre-allocate lists for better memory efficiency
        menu_items = self.response.get(SC.ITEM_MENU, [])
        if not menu_items:
            return
            
        for i in menu_items:
            item = SCItem(i)

            if item.visible:
                # Cache the URL once to avoid repeated dictionary lookups
                item_url = i.get(SC.ITEM_URL)
                
                # info('pin {} {}'.format(pinned, item_url))
                if pinned is not None and item_url and pinned.get(item_url):
                    item.li().setProperty('SpecialSort', GUI.TOP)
                    info('TOP {}'.format(item.li().getProperty('SpecialSort')))
                    self.items_pinned.append(item.get())
                    item.visible = False

                if hidden is not None and hidden.get(item.li().getLabel()):
                    item.visible = False

            if item.visible:
                self.items.append(item.get())

    def play(self):
        """
        Refactored play method using new unified player and download manager.
        
        This method now leverages Kodi's native capabilities for both playback and downloads,
        eliminating custom threading and HTTP retry logic.
        """
        try:
            item = SCItem(self.response)
            url, li, status, selected = item.get()
            
            # Check if we got valid values (not None) - indicates error/cancellation
            if url is None or li is None:
                debug('Play failed - url or li is None (likely user cancelled or error occurred)')
                self.succeeded = False
                self.end_of_directory()
                return
            
            # Handle download action using new download manager
            if SC.ACTION in self.args and SC.ACTION_DOWNLOAD in self.args[SC.ACTION]:
                self._handle_download_action(url, selected)
                return
            
            # Handle playback using new unified player
            self._handle_playback_action(url, li, selected)
            
        except Exception as e:
            # Provide specific error handling for playback issues
            info("Playback error: {}".format(str(e)))
            info("Full traceback: {}".format(str(traceback.format_exc())))
            
            # Show user-friendly error message if not in widget context
            if SC.ITEM_WIDGET not in self.args:
                try:
                    from resources.lib.common.threading_utils import safe_dialog_ok
                    safe_dialog_ok(Strings.txt(Strings.RESOLVE_ERROR_H1), 
                        'Playback error: {}'.format(str(e)))
                except:
                    # Fallback if dialog fails
                    pass
                    
            self.end_of_directory()
    
    def _handle_download_action(self, url: str, selected: dict) -> None:
        """
        Handle download action using Kodi's native download manager.
        
        Args:
            url: The resolved stream URL
            selected: Selected stream information dictionary
        """
        try:
            from resources.lib.download_manager import StreamCinemaDownloadManager, create_download_headers
            from resources.lib.api.kraska import Kraska
            
            if selected is None:
                debug('Download failed - selected stream is None')
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.RESOLVE_ERROR_H1), Strings.txt(Strings.RESOLVE_ERROR_L1))
                return
            
            # Extract filename from stream info
            filename = selected.get('stream_info', {}).get('filename')
            if filename is None:
                # Generate filename from title and quality if not available
                title = self.response.get('info', {}).get('title', 'stream')
                quality = selected.get('quality', 'unknown')
                filename = "{}_{}".format(title, quality)
                # Add appropriate extension
                if not filename.endswith(('.mkv', '.mp4', '.avi')):
                    filename += '.mkv'
            
            # Create download headers with authentication
            headers = create_download_headers()
            
            # Add Kraska token if available
            try:
                kr = Kraska()
                token = kr.get_token()
                if token:
                    headers['Authorization'] = 'Bearer {}'.format(token)
            except Exception as e:
                debug('Could not get Kraska token for download: {}'.format(str(e)))
            
            # Get title for display
            display_title = self.response.get('info', {}).get('title', filename)
            
            # Get thumbnail for display
            thumbnail = None
            art = self.response.get('art', {})
            if isinstance(art, dict):
                thumbnail = art.get('thumb') or art.get('poster')
            
            # Initialize download manager and add download
            download_manager = StreamCinemaDownloadManager()
            success = download_manager.add_download(
                download_url=url,
                filename=filename,
                custom_headers=headers,
                title=display_title,
                thumbnail=thumbnail
            )
            
            if success:
                info("Download initiated successfully: {}".format(filename))
                # Optionally show downloads window
                # download_manager.show_downloads_window()
            else:
                debug("Download initiation failed")
                
        except Exception as e:
            error_msg = "Download handling failed: {}".format(str(e))
            info(error_msg)
            debug("Full traceback: {}".format(traceback.format_exc()))
            
            from resources.lib.common.threading_utils import safe_dialog_ok
            safe_dialog_ok(
                Strings.txt(Strings.RESOLVE_ERROR_H1),
                "Download failed: {}".format(str(e))
            )
    
    def _handle_playback_action(self, url: str, li: xbmcgui.ListItem, selected: dict) -> None:
        """
        Handle playback action using modern player.
        
        Args:
            url: The resolved stream URL
            li: The configured ListItem
            selected: Selected stream information dictionary
        """
        try:
            from resources.lib.player import StreamCinemaPlayer, create_stream_headers
            from resources.lib.api.kraska import Kraska
            
            debug('----------------------------------------------------------------------------------------------------')
            debug('play url: {}'.format(self.url))
            debug('play selected: {}'.format(dumps(selected) if selected is not None else 'None'))
            debug('----------------------------------------------------------------------------------------------------')
            
            # Extract metadata from response for new player
            metadata = self._extract_playback_metadata(selected)
            
            # Create stream headers with authentication
            headers = create_stream_headers()
            
            # Add Kraska token if available
            try:
                kr = Kraska()
                token = kr.get_token()
                if token:
                    headers['Authorization'] = 'Bearer {}'.format(token)
            except Exception as e:
                debug('Could not get Kraska token for playback: {}'.format(str(e)))
            
            # Store selected item info for other components
            if selected is not None:
                self.response['strms'] = selected
            home_win.setProperty('SC.play_item', dumps(self.response))
            
            # Initialize modern player
            player = StreamCinemaPlayer()
            
            # Get title from metadata
            title = metadata.get('title', 'Stream Cinema')
            
            # Get video info and art from metadata
            video_info = {}
            art = {}
            
            # Extract video info (excluding art which is handled separately)
            for key, value in metadata.items():
                if key != 'art' and key != 'stream_info':
                    video_info[key] = value
            
            # Extract art
            if 'art' in metadata and isinstance(metadata['art'], dict):
                art = metadata['art']
            
            # Use modern API
            success = player.play_stream(
                handle=params.handle,
                url=url,
                title=title,
                headers=headers,
                video_info=video_info,
                art=art
            )
            
            if success:
                # Plugin context - setResolvedUrl was called
                self.succeeded = True
                self.cache_to_disc = False
                self.end_of_directory()
            else:
                debug('Playback initiation failed')
                self.succeeded = False
                self.end_of_directory()
                
        except Exception as e:
            error_msg = "Playback handling failed: {}".format(str(e))
            info(error_msg)
            debug("Full traceback: {}".format(traceback.format_exc()))
            
            self.succeeded = False
            self.end_of_directory()
    
    def _extract_playback_metadata(self, selected: dict) -> dict:
        """
        Extract metadata from response for playback.
        
        Args:
            selected: Selected stream information dictionary
            
        Returns:
            dict: Metadata dictionary for the player
        """
        metadata = {}
        
        # Extract info section
        if 'info' in self.response:
            info_data = self.response['info']
            if isinstance(info_data, dict):
                metadata.update(info_data)
        
        # Extract art section
        if 'art' in self.response:
            art_data = self.response['art']
            if isinstance(art_data, dict):
                metadata['art'] = art_data
        
        # Extract cast information
        if 'cast' in self.response:
            metadata['cast'] = self.response['cast']
        
        # Extract unique IDs
        if 'unique_ids' in self.response:
            metadata['unique_ids'] = self.response['unique_ids']
        
        # Add stream-specific information
        if selected and isinstance(selected, dict):
            if 'stream_info' in selected:
                metadata['stream_info'] = selected['stream_info']
            
            # Add quality and language info as properties
            if 'quality' in selected:
                metadata['quality'] = selected['quality']
            if 'linfo' in selected:
                metadata['language_info'] = selected['linfo']
        
        # Ensure we have at least a title
        if 'title' not in metadata:
            metadata['title'] = 'Stream Cinema'
        
        return metadata

    def play_url(self, url, li=None):
        """
        Modern play_url method using new unified player.
        
        Args:
            url: Stream URL to play
            li: Optional ListItem (will be created if not provided)
        """
        info('playUrl: {} / {}'.format(url, li))
        
        try:
            from resources.lib.player import StreamCinemaPlayer
            
            # Get title from ListItem if available
            title = 'Stream Cinema'
            if li is not None:
                title = li.getLabel() or title
            
            # Initialize modern player
            player = StreamCinemaPlayer()
            
            # Use modern API - get handle from params
            success = player.play_stream(
                handle=params.handle,
                url=url,
                title=title
            )
            
            if success:
                info('Modern playback initiated: {}'.format(title))
            else:
                debug('Modern playback failed: {}'.format(title))
                
        except Exception as e:
            error_msg = 'Modern play_url failed: {}'.format(str(e))
            info(error_msg)
            debug('Full traceback: {}'.format(traceback.format_exc()))

    def end_of_directory(self):
        if self.send_end:
            return
        self.send_end = True

        info('endOfDirectory s: {} u: {} c: {}'.format(self.succeeded, self.update_listing, self.cache_to_disc))
        xbmcplugin.endOfDirectory(params.handle, succeeded=self.succeeded, updateListing=self.update_listing,
                                  cacheToDisc=self.cache_to_disc)

    def end(self):
        if self.send_end:
            return

        if not self.items:
            self.succeeded = False
            # dok('ERROR', 'Nastala chyba...')

        # Use addDirectoryItems with batch operations for better performance
        if self.items_pinned:
            xbmcplugin.addDirectoryItems(params.handle, self.items_pinned)
        if self.items:
            xbmcplugin.addDirectoryItems(params.handle, self.items)
        self.end_of_directory()
        if SC.ITEM_SYSTEM in self.response:
            self.system_after()
            
        # Clear references to help with garbage collection
        self.items.clear()
        self.items_pinned.clear()
        if isinstance(self.response, list):
            self.response.clear()
        else:
            self.response = {}
        
        # Note: Download thread cleanup no longer needed as downloads are handled by Kodi's native system

    # notify() method removed - was disabled and unused

    def system(self):
        # if 'filter' in self.response:
        #     self.notify(self.response.get('filter', {}))
        # else:
        #     self.notify({})

        data = self.response.get(SC.ITEM_SYSTEM, {})
        if 'setContent' in data:
            xbmcplugin.setContent(params.handle, data['setContent'])

        if 'setPluginCategory' in data:
            xbmcplugin.setPluginCategory(params.handle, data['setPluginCategory'])

        if 'addSortMethod' in data:
            # info('add sort method {}'.format(SORT_METHODS[data['addSortMethod']]))
            xbmcplugin.addSortMethod(params.handle, SORT_METHODS[data['addSortMethod']])

        if 'addSortMethods' in data:
            for method in data['addSortMethods']:
                # info('add sort method {}'.format(SORT_METHODS[method]))
                try:
                    if method in SORT_METHODS:
                        xbmcplugin.addSortMethod(params.handle, SORT_METHODS[method])
                except:
                    pass

        if 'SetSortMethod' in data:
            #method = SORT_METHODS[int(data.get('SetSortMethod'))]
            # info('set sort method {}'.format(method))
            #xbmc.executebuiltin('Container.SetSortMethod(%d)' % method)
            pass

        if 'setPluginFanart' in data:
            tmp = data.get('setPluginFanart')
            image = tmp.get('image', None)
            color1 = tmp.get('color1', None)
            xbmcplugin.setPluginFanart(params.handle, image=image, color1=color1)

        if 'addCustomFilter' in data:
            item = SCItem({
                'type': 'add_custom_filter',
                'title': '[B]+[/B]   ADD',
                SC.ITEM_ACTION: SC.ACTION_ADD_CUSTOM_FILTER
            })
            item.li().setProperty('SpecialSort', GUI.BOTTOM)
            self.items.append(item.get())

        if 'listType' in data:
            params.args.update({'listType': data['listType']})
            self.listType = data['listType']

    def system_after(self):
        data = self.response.get(SC.ITEM_SYSTEM, {})
        if 'setContent' in data:  # and settings.get_setting_bool('gui.views.enabled'):
            xbmcplugin.setContent(params.handle, data['setContent'])
            # view_mode = data["setContent"].lower()
            # view_code = settings.get_setting_int('gui.views.{0}'.format(view_mode))
            # if view_code > 0:
            #     xbmc.executebuiltin("Container.SetViewMode(%d)" % view_code)

        if 'SetSortMethod' in data:
            #method = SORT_METHODS[int(data.get('SetSortMethod'))]
            #xbmc.executebuiltin('Container.SetSortMethod(%d)' % method)
            pass

        if SC.ITEM_FOCUS in data:
            try:
                control = cur_win.getControl(cur_win.getFocusId())
                control.selectItem(int(data[SC.ITEM_FOCUS]))
            except:
                pass

        check_last_key = '{}.last_series'.format(ADDON_ID)
        if 'checkLast' in data and get_setting_as_bool('stream.autoplay.episode'):
            check_last = data['checkLast']
            stop = home_win.getProperty('{}.stop'.format(ADDON_ID))
            debug('Mame check last data: {} / {}'.format(stop, check_last))
            item_id = int(check_last.get('id', 0))
            ki = SCKODIItem(int(item_id))
            last_ep = ki.get_last_ep()
            if item_id > 0 and last_ep:
                win_last_series = home_win.getProperty(check_last_key)
                home_win.setProperty(check_last_key, str(item_id))
                debug('last {} cur {}'.format(win_last_series, item_id))
                if win_last_series == '' or win_last_series != str(item_id):
                    debug('last ep: {}'.format(last_ep))
                    try:
                        data = Sc.up_next(item_id, last_ep[0], last_ep[1])
                        d = SCUpNext(data)
                        # Fix: Safe access to nested data to prevent AttributeError
                        d_data = d.get()
                        play_info = d_data.get('play_info') if d_data else None
                        debug('NEXT EP: {}'.format(play_info))
                        cmd = 'PlayMedia({})'.format(create_plugin_url(play_info))
                        if stop is None or stop == '':
                            debug('play: {}'.format(cmd))
                            exec_build_in(cmd)
                    except:
                        debug('chyba: {}'.format(traceback.format_exc()))
                        pass
        else:
            home_win.clearProperty(check_last_key)
        # upraceme po sebe
        home_win.clearProperty('{}.stop'.format(ADDON_ID))


# Legacy classes removed - functionality replaced by new unified player system
