from time import time

import xbmc

from resources.lib.api.sc import Sc
from resources.lib.common.lists import SCKODIItem
from resources.lib.common.logger import debug
from resources.lib.common.storage import Storage
from resources.lib.constants import ADDON_ID
from resources.lib.gui import get_cond_visibility
from resources.lib.gui.dialog import dprogressgb
from resources.lib.gui.item import SCUpNext
from resources.lib.services.Monitor import monitor
from resources.lib.services.SCPlayer import player
from resources.lib.services.Settings import settings


class NextEp:

    def __init__(self):
        self.list = Storage('nextep')
        # dal som to sem natvrdo, aby sa oneskoril sync o 10 minut po starte
        last_run = settings.get_setting_as_int('system.next_ep.last_run')
        if last_run is None:
            self.last_run = time()
        else:
            self.last_run = last_run
        # Cache skip list to avoid repeated computation
        self._skip_list_cache = None
        self._skip_list_cache_time = 0

    def run(self, force=False):
        now = time()
        if not player.isPlayback() and (force or self.last_run + (3600 * 3) < now):
            if self.update_items():
                self.last_run = now
                settings.set_setting('system.next_ep.last_run', '{}'.format(int(now)))

    def update_items(self):
        query = 'select item_key, item_value from storage where item_key like ? and item_value like ?'
        search = '{}-%'.format(SCKODIItem.ITEM_NAME)
        # debug('search: {}'.format(search))
        res = self.list._db.execute(query, search, '%"last_ep"%').fetchall()
        total = len(res)
        
        # Early exit if no items to process
        if total == 0:
            debug('NEXTEP: No items to process')
            return True
        
        skip_list = self.get()
        debug('NEXTEP: {} z {} ({})'.format(len(skip_list), total, total - len(skip_list)))
        
        # Convert to set for O(1) lookup instead of O(n)
        skip_set = set(skip_list)
        
        # Early exit if all items are already processed
        if len(skip_set) >= total:
            debug('NEXTEP: All items already processed, skipping update')
            return True
        
        from resources.lib.common.threading_utils import safe_dialog_progress
        dialog = safe_dialog_progress()
        dialog.create('Next Ep in progress')
        pos = 0
        batch_updates = {}  # Batch database updates
        
        for i in res:
            if monitor.abortRequested() or player.isPlayback():
                dialog.close()
                return False
            pos += 1
            _, item_id = i[0].split('-')
            
            # Use set lookup for O(1) performance instead of O(n)
            if item_id in skip_set:
                debug('ITEM {} uz ma nextep, nepotrebujeme update'.format(item_id))
                continue
                
            # Update progress every 10 items instead of every item to reduce overhead
            if pos % 10 == 0 or pos == total:
                dialog.update(int(pos / total * 100), message='Processing item {}/{}'.format(pos, total))
            
            item = SCKODIItem(item_id)
            last_ep = item.get_last_ep()
            
            try:
                debug('last {}x{}'.format(last_ep[0], last_ep[1]))
                info = Sc.up_next(item_id, last_ep[0], last_ep[1])
                if 'error' in info or ('info' in info and info.get('info') is None):
                    debug('nemame data k next EP')
                    continue
                new = {
                    's': last_ep[0],
                    'e': last_ep[1],
                    't': int(time()),
                }
                cur = self.list.get(item_id)
                if cur is None or (cur and str(cur.get('e')) != str(new.get('e'))):
                    debug('nextep update {} -> {}'.format(item_id, last_ep))
                    # Batch the update instead of immediate write
                    batch_updates[item_id] = new
                else:
                    debug('nezmenene {} -> {}'.format(item_id, last_ep))
            except Exception as e:
                debug('Error processing serial {}: {}'.format(item_id, str(e)))
                debug('Removing serial from list due to error')
                # Batch the deletion
                batch_updates[item_id] = None

        # Apply all batched updates at once for better performance
        if batch_updates:
            debug('Applying {} batch updates efficiently'.format(len(batch_updates)))
            try:
                # Separate updates and deletions for more efficient processing
                updates = {k: v for k, v in batch_updates.items() if v is not None}
                deletions = [k for k, v in batch_updates.items() if v is None]
                
                # Bulk update using dictionary update for better performance
                if updates:
                    self.list._data.update(updates)
                
                # Handle deletions efficiently
                for item_id in deletions:
                    if item_id in self.list._data:
                        del self.list._data[item_id]
                
                # Single save operation for all changes
                self.list.save()
                
                # Clear cache since we made updates
                self._skip_list_cache = None
                debug('Successfully applied {} updates and {} deletions'.format(len(updates), len(deletions)))
                
            except Exception as e:
                debug('Batch update error: {}, falling back to individual updates'.format(str(e)))
                # Fallback to individual updates if bulk method fails
                for item_id, update_data in batch_updates.items():
                    try:
                        if update_data is None:
                            if item_id in self.list._data:
                                del self.list[item_id]
                        else:
                            self.list[item_id] = update_data
                    except Exception as e2:
                        debug('Individual update error for {}: {}'.format(item_id, str(e2)))
                # Clear cache since we made updates
                self._skip_list_cache = None

        dialog.close()
        debug('LIST NEXT EP: {}'.format(self.list._data))
        return True

    def get(self):
        # Cache the skip list computation for 5 minutes
        now = time()
        if (self._skip_list_cache is not None and 
            (now - self._skip_list_cache_time) < 300):  # 5 minutes cache
            return self._skip_list_cache
            
        tmp = {}
        for k in self.list._data.items():
            if k[1]['t'] is not None:
                tmp.update({k[0]: k[1]})
            else:
                debug('ERR ITEM: {}'.format(k))

        debug('GET NEXT EP: {}'.format(tmp))
        ret = [k[0] for k in sorted(tmp.items(), key=lambda x: x[1]['t'], reverse=True)]
        
        # Cache the result
        self._skip_list_cache = ret
        self._skip_list_cache_time = now
        
        return ret
