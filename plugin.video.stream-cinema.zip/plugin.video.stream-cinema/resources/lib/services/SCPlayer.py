import traceback
import re
from datetime import datetime, timedelta as td
from json import loads
from time import time

from xbmc import Player, Monitor

from resources.lib.common.storage import Storage
from resources.lib.services.Settings import settings
from resources.lib.api.sc import Sc
from resources.lib.common.lists import SCKODIItem
from resources.lib.common.logger import debug
from resources.lib.constants import ADDON, ADDON_ID, SC
from resources.lib.gui import home_win, get_cond_visibility as gcv
from resources.lib.gui.item import SCUpNext
from resources.lib.gui.skip import Skip
from resources.lib.kodiutils import upnext_signal


class SCPlayer(Player):
    # Pre-compile regex for better performance
    _id_pattern = re.compile(r'id=(\d+)')
    
    def __init__(self):
        self.settings = settings
        self.win = home_win
        self.current_time = 0
        self.item = None
        self.is_my_plugin = False
        self.movie = None
        self.my_id = None
        self.total_time = 0
        self.ids = {}
        self.watched = False
        self.up_next = False
        self.skipped_item = None
        self.skip_button = None
        self.skip_time_start = False
        self.skip_time_end = False
        self.skip_start = False
        
        # Cache frequently read settings for performance
        self._cached_show_skip_button = None
        self._settings_cache_time = 0
        self._settings_cache_ttl = 5  # Cache for 5 seconds
        
        # Add stop flag for graceful shutdown
        self._stop_requested = False

    def onPlayBackStarted(self):
        self.onAVStarted()

    def set_item(self, item=None):
        self.up_next = False
        self.skip_start = False
        # self.item = item
        # Ensure window reference is available (fix for AttributeError when self.win is None)
        if self.win is None:
            self.win = home_win
        json_data = self.win.getProperty('SC.play_item')
        debug('set_item json_data: {}'.format(json_data))
        if not json_data:
            return
        try:
            item_data = loads(json_data)
        except (ValueError, TypeError):
            debug('Invalid JSON data in SC.play_item')
            return
            
        self.item = item_data.get('info')
        debug('ITEM: {}'.format(self.item.get('unique_ids') if self.item else None))
        # Safe access to nested data
        strms_data = item_data.get('strms') if item_data else None
        linfo = strms_data.get('linfo') if strms_data else None
        ids = self.win.getProperty('{}.ids'.format(ADDON_ID))
        debug('Raw ids property: {}'.format(ids))
        self.win.clearProperty('{}.ids'.format(ADDON_ID))
        try:
            self.ids = loads(ids) if ids else {}
        except (ValueError, TypeError) as e:
            debug('Error parsing ids JSON: {}'.format(str(e)))
            self.ids = {}
        self.my_id = self.ids.get('sc') if self.ids.get('sc') else None
        debug('my ids: {} | my_id: {}'.format(self.ids, self.my_id))
        
        # Fallback: Try to extract ID from other sources if my_id is None
        if self.my_id is None:
            debug('my_id is None, trying fallback methods...')
            # Try to get ID from item data unique_ids
            if self.item and self.item.get('unique_ids'):
                unique_ids = self.item.get('unique_ids', {})
                debug('Available unique_ids: {}'.format(unique_ids))
                # Look for possible SC ID in unique_ids
                for key, value in unique_ids.items():
                    if 'sc' in key.lower() or 'stream' in key.lower():
                        self.my_id = value
                        debug('Found fallback ID from unique_ids: {}'.format(self.my_id))
                        break
            
            # If still None, try to extract from URL pattern if available
            if self.my_id is None and self.getPlayingFile():
                playing_file = self.getPlayingFile()
                debug('Playing file: {}'.format(playing_file))
                # Try to extract ID from URL pattern using pre-compiled regex
                id_match = self._id_pattern.search(playing_file)
                if id_match:
                    self.my_id = id_match.group(1)
                    debug('Extracted ID from URL: {}'.format(self.my_id))
        
        if self.my_id is not None:
            if self.skipped_item is not False and self.skipped_item != self.my_id:
                self.skipped_item = False
            self.win.setProperty('{}.play'.format(ADDON_ID), '1')
            try:
                all_item_data = loads(self.win.getProperty(SC.SELECTED_ITEM))
            except (ValueError, TypeError):
                all_item_data = {}
            if SC.NOTIFICATIONS in all_item_data:
                if SC.SKIP_START in all_item_data.get(SC.NOTIFICATIONS, {}):
                    notification = all_item_data.get(SC.NOTIFICATIONS, {})
                    self.skip_time_start = notification.get(SC.SKIP_START, False)
                    self.skip_time_end = notification.get(SC.SKIP_END, False)
                    debug('NOTIFICATIONS set SKIP TIME: {}s to {}s'.format(td(seconds=self.skip_time_start), td(seconds=self.skip_time_end)))
            debug('je to moj plugin')
            self.is_my_plugin = True
            # Fix: self.item is already the 'info' object, not a dict containing 'info'
            series = self.item.get('season') if self.item else None
            episode = self.item.get('episode') if self.item else None
            self.movie = SCKODIItem(self.my_id, series=series, episode=episode, trakt=self.ids.get('trakt'))
            self.movie.scrobble(self.percent_played(), SCKODIItem.SCROBBLE_START)
            audio = self.getAvailableAudioStreams()
            if len(audio) == 1:
                debug('Nemame na vyber, mame len jednu audio stopu')
                return

            if linfo:
                audio = linfo
            debug('AvailableAudioStreams {}'.format(len(audio)))
            lang1 = settings.get_setting('stream.lang1').lower()
            lang2 = settings.get_setting('stream.lang2').lower()
            if Sc.parental_control_is_active():
                lang1 = settings.get_setting('parental.control.lang1').lower()
                lang2 = settings.get_setting('parental.control.lang2').lower()

            plf = Storage(SC.ITEM_PREFERRED_LANG)
            plf.load(True)
            debug('PREF LANGS: {} / {}'.format(self.my_id, plf.data))
            force_lang = plf.get(self.my_id)
            force = False
            if force_lang is not None:
                lang = force_lang.lower()
                debug('mame force lang {}'.format(force_lang))
                force = self.try_audio(lang, audio)

            if force is False and self.try_audio(lang1, audio) is False:
                self.try_audio(lang2, audio)

    def try_audio(self, lang, streams):
        if lang == 'sk':
            language_list = ['slo', 'sk', 'slk', 'SK']
        elif lang == 'cz':
            language_list = ['cze', 'cz', 'ces', 'CZ']
        elif lang == 'en':
            language_list = ['eng', 'en', 'EN']
        else:
            debug("iny jazyk {}".format(lang))
            language_list = [lang.lower(), lang.upper()]

        for i in language_list:
            if i in streams:
                debug("mame audio: {} pre jazyk {}".format(i, lang))
                stream_number = streams.index(i)
                self.setAudioStream(stream_number)
                # dnotify(lang, '', time=1000, sound=False)
                return True
        return False

    def onAVStarted(self):
        debug('player onAVStarted')
        # Kodi fires onAVStarted only when A/V is locked, so we can set item directly
        self.set_item()

    def onAVChange(self):
        debug('player onAVChange')
        if self.is_my_plugin is True:
            debug('moj plugin')

    def onPlayBackEnded(self):
        debug('player onPlayBackEnded')
        self.end_playback()

    def onPlayBackStopped(self):
        debug('player onPlayBackStopped')
        self.end_playback()

    def onPlayBackError(self):
        debug('player onPlayBackError')
        self.end_playback()

    def onPlayBackPaused(self):
        debug('player onPlayBackPaused')
        self.end_playback()

    def onPlayBackResumed(self):
        debug('player onPlayBackResumed')
        if self.movie is not None:
            self.movie.scrobble(self.percent_played(), SCKODIItem.SCROBBLE_START)

    def onQueueNextItem(self):
        debug('player onQueueNextItem')

    def onPlayBackSpeedChanged(self, speed):
        debug('player onPlayBackSpeedChanged {}'.format(speed))

    def onPlayBackSeek(self, time, seekOffset):
        debug('player onPlayBackSeek {} {}'.format(time, seekOffset))

    def onPlayBackSeekChapter(self, chapter):
        debug('player onPlayBackSeekChapter {}'.format(chapter))

    def clean(self):
        debug('player SCPlayer Clean')
        # MEMORY LEAK FIX: Break circular references before clearing
        # Store references we need to clean
        skip_button_ref = self.skip_button
        movie_ref = self.movie
        
        # Clear window properties first to prevent memory leaks
        try:
            # Ensure window reference is available before clearing properties
            if self.win is None:
                self.win = home_win
            self.win.clearProperty('{}.play'.format(ADDON_ID))
            self.win.clearProperty('SC.play_item')
            self.win.clearProperty(SC.SELECTED_ITEM)
            self.win.clearProperty('{}.ids'.format(ADDON_ID))
            self.win.clearProperty('{}.stop'.format(ADDON_ID))
            self.win.clearProperty('{}.last_series'.format(ADDON_ID))
        except:
            pass  # Window might be invalid during shutdown
        
        # Cleanup skip button if it exists
        try:
            if skip_button_ref:
                if hasattr(skip_button_ref, 'close'):
                    skip_button_ref.close()
                if hasattr(skip_button_ref, 'cleanup'):
                    skip_button_ref.cleanup()
        except:
            pass
        
        # Cleanup movie tracking object
        try:
            if movie_ref:
                # Clear any references the movie object might hold
                if hasattr(movie_ref, 'cleanup'):
                    movie_ref.cleanup()
        except:
            pass
        
        # Reset all instance variables to free memory
        self.current_time = 0
        self.ids = {}
        self.is_my_plugin = False
        self.item = None
        self.movie = None
        self.my_id = None
        self.up_next = False
        self.total_time = 0
        self.watched = False
        self.skip_time_start = False
        self.skip_time_end = False
        self.skip_start = False
        self.skipped_item = None
        
        # Clear cached settings
        self._cached_show_skip_button = None
        self._settings_cache_time = 0
        # Note: Not clearing self.skip_button reference to allow reuse in background service
        # The background service continues running and needs access to skip_button
        
        # Note: Not clearing self.win reference to allow reuse in subsequent playback sessions
        # This prevents AttributeError when onPlayBackStarted is called after clean()
        
        # Force garbage collection for better memory management
        import gc
        gc.collect()

    def end_playback(self):
        self.set_watched()
        self.clean()

    def percent_played(self):
        try:
            return self.current_time / self.total_time * 100
        except (ZeroDivisionError, TypeError, AttributeError):
            return 0

    def set_watched(self):
        if self.is_my_plugin:
            # Ensure window reference is available (fix for AttributeError when self.win is None)
            if self.win is None:
                self.win = home_win
            self.win.setProperty('{}.stop'.format(ADDON_ID), '1')
            percent_played = self.percent_played()

            self.movie.scrobble(percent_played, SCKODIItem.SCROBBLE_STOP)

            if percent_played > 80:
                play_count = self.movie.get_play_count()
                play_count = int(play_count) + 1 if play_count is not None else 1
                debug('playcount {}'.format(play_count))
                d = datetime.fromtimestamp(time())
                self.movie.set_play_count(play_count, True)
                self.movie.set_last_played(d.strftime('%Y-%m-%d %H:%M:%S'))
            if 3 < percent_played < 80:
                debug('watched {}'.format(self.current_time))
                self.movie.set_watched(self.current_time)

    def check_up_next(self, percent_played):
        # Check if UpNext is enabled in settings
        upnext_enabled = settings.get_setting_as_bool('upnext_enabled')
        if not upnext_enabled:
            return False
            
        return gcv('System.hasAddon(service.upnext)') and self.item and self.item.get(
            'episode') is not None and self.up_next is False

    def send_up_next(self):
        try:
            # Check if we have required data before proceeding
            if self.my_id is None:
                debug('send_up_next: my_id is None, cannot fetch up next')
                return
                
            # Fix: self.item is already the 'info' object, not a dict containing 'info'
            series = self.item.get('season') if self.item else None
            episode = self.item.get('episode') if self.item else None
            
            if series is None or episode is None:
                debug('send_up_next: Missing series ({}) or episode ({}), cannot fetch up next'.format(series, episode))
                return
                
            url = '/upNext/{}/{}/{}'.format(self.my_id, series, episode)
            debug('upnext call {}'.format(url))
            data = Sc.get(url)
            if 'info' in data:
                debug('Mame next item: {}'.format(data))
                d = SCUpNext(data)
                # sleep(3 * 1000)
                upnext_signal(ADDON_ID, d.get())
        except Exception as e:
            debug('send_up_next ERR: {}'.format(str(e)))
            debug('send_up_next traceback: {}'.format(traceback.format_exc()))

    def run(self):
        debug('START player bg service')
        m = Monitor()
        self.skip_button = Skip("SkipButton.xml", ADDON.getAddonInfo('path'), "default", "1080i")

        try:
            # Use adaptive timeout: shorter when playing, longer when idle
            while not m.abortRequested() and not self._stop_requested:
                try:
                    # Check if we're playing and determine appropriate timeout
                    is_playing = self.isPlayback()
                    timeout = 0.25 if is_playing else 1.0  # 250ms when playing, 1s when idle
                    
                    if m.waitForAbort(timeout):
                        break
                        
                    self.periodical_check()
                except Exception as e:
                    debug('player bg service ERR: {}'.format(str(e)))
                    debug('player bg service traceback: {}'.format(traceback.format_exc()))
        finally:
            # Cleanup Monitor instance to prevent memory leak
            try:
                if hasattr(self.skip_button, 'cleanup'):
                    self.skip_button.cleanup()
            except:
                pass
            debug('END player bg service')

    def getTime1(self):  # type: () -> float
        try:
            return self.getTime()
        except RuntimeError:
            # Player not active or playback stopped
            return 0

    def isPlayingVideo1(self):  # type: () -> bool
        try:
            return self.isPlayingVideo()
        except RuntimeError:
            # Player not active
            return False
    
    def _get_cached_skip_button_setting(self):
        """Cache frequently read skip button setting for better performance"""
        current_time = time()
        if (self._cached_show_skip_button is None or 
            current_time - self._settings_cache_time > self._settings_cache_ttl):
            self._cached_show_skip_button = settings.get_setting_as_bool('plugin.show.skip.button')
            self._settings_cache_time = current_time
        return self._cached_show_skip_button

    def periodical_check(self):
        # KODI OPTIMIZATION: Re-initialize skip button if it's None (fallback protection)
        if self.skip_button is None:
            try:
                self.skip_button = Skip("SkipButton.xml", ADDON.getAddonInfo('path'), "default", "1080i")
                debug('Re-initialized skip_button in periodical_check')
            except Exception as e:
                debug('Failed to re-initialize skip_button: {}'.format(str(e)))
                return
                
        if self.skip_button and self.skip_button.is_button_visible is True:
            debug('rusim SKIP button Notification')
            self.skip_button.close()
            self.skip_button.set_visibility()

        if not self.isPlayback() or self.is_my_plugin is False:
            return

        # PERFORMANCE OPTIMIZATION: Cache expensive player calls once per tick with error handling
        try:
            current_time = self.getTime()
            total_time = self.getTotalTime()
        except RuntimeError:
            # KODI OPTIMIZATION: Player not active or playback stopped
            debug('Player not active during periodical_check')
            return
        except Exception as e:
            # STREAMING OPTIMIZATION: Handle other player errors gracefully
            debug('Player error during periodical_check: {}'.format(str(e)))
            return
        
        # PERFORMANCE: Store for other methods that need them
        self.current_time = current_time
        self.total_time = total_time
        
        # KODI OPTIMIZATION: Only perform expensive operations when necessary
        if abs(current_time - getattr(self, '_last_current_time', 0)) < 1.0:
            return  # Skip if time hasn't changed significantly
        
        self._last_current_time = current_time
        
        # STREAMING OPTIMIZATION: Check for buffering issues
        try:
            # PERFORMANCE: Monitor playback health
            if hasattr(self, '_last_position_check'):
                time_diff = current_time - self._last_position_check
                if time_diff > 5.0 and current_time == getattr(self, '_last_position', 0):
                    debug('Potential buffering detected - position unchanged for {}s'.format(time_diff))
            
            self._last_position = current_time
            self._last_position_check = current_time
            
        except Exception as e:
            debug('Error in buffering check: {}'.format(str(e)))
        
        # KODI OPTIMIZATION: Continue with existing periodical check logic
        # Calculate percent_played once and reuse
        try:
            percent_played = (current_time / total_time * 100) if total_time > 0 else 0
        except (ZeroDivisionError, TypeError, AttributeError) as e:
            debug('Percent calculation error: {}'.format(str(e)))
            percent_played = 0

        # Cache the setting to avoid reading it twice per cycle
        show_skip_button = self._get_cached_skip_button_setting()
        
        if show_skip_button and self.isSkipTime(current_time):
            debug('skip: {} / {} / {}'.format(self.skipped_item, self.my_id, self.skip_start))
            if self.skipped_item == self.my_id and self.skip_start is False:
                self.skipStart()
            else:
                if self.skip_button:
                    # UI THREAD SAFETY FIX: Use main-thread safe method
                    import xbmc
                    xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.stream-cinema/script.py,show_skip,{})'.format(self.my_id))
        elif show_skip_button:
            if self.skip_button and self.skip_button.is_button_visible is True:
                debug('rusim SKIP button Notification')
                self.skip_button.close()
                self.skip_button.set_visibility()

        # debug('self.watched: {} {}'.format(self.watched, percent_played))
        if percent_played >= 80 and not self.watched:
            self.set_watched()
            self.watched = True
        if self.check_up_next(percent_played):
            debug('Mame upnext nainstalovane')
            try:
                self.send_up_next()
            except:
                pass
            self.up_next = True

    def isSkipTime(self, current_time=None):
        if self.skip_time_start is False or self.skip_time_end is False:
            return False

        # Use passed parameter or fall back to instance variable for backward compatibility
        time_to_check = current_time if current_time is not None else self.current_time
        return self.skip_time_start <= time_to_check < self.skip_time_end - 5

    def skipStart(self):
        self.skipped_item = self.my_id
        self.skip_start = True
        self.seekTime(self.skip_time_end)

    def isPlayback(self):  # type: () -> bool
        try:
            return self.isPlaying() and self.isPlayingVideo() and self.getTime() >= 0
        except RuntimeError:
            # Player not active
            return False

    def stop(self):
        """Stop the player background service gracefully"""
        debug('SCPlayer stop() called')
        # Set a flag that the run() method can check
        self._stop_requested = True
        
        # Clean up current playback state
        try:
            self.clean()
        except:
            pass  # Ignore errors during shutdown


player = SCPlayer()
