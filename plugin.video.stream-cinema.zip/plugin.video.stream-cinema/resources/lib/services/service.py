import traceback
import time
import threading

from resources.lib.api.kraska import Kraska
from resources.lib.common.android import AndroidTv
from resources.lib.common.logger import debug
from resources.lib.constants import ADDON, ADDON_ID
from resources.lib.gui.dialog import dtextviewer
from resources.lib.kodiutils import set_setting, get_uuid, get_setting, exec_build_in, get_setting_as_bool, \
    update_addon, clean_textures
from resources.lib.services.Monitor import monitor
from resources.lib.services.SCPlayer import player
from resources.lib.services.next_episodes import NextEp
from resources.lib.api.sc import Sc


class Service:
    next_ep = None
    monitor = None
    player = None
    trakt = None
    atv = None
    _last_check = 0  # Track last check time for efficiency
    _last_cleanup = 0  # Track periodic cleanup
    _cleanup_called = False  # Prevent multiple cleanup calls

    def __init__(self):
        # Use try-catch to handle potential addon context issues
        try:
            set_setting('system.ver', ADDON.getAddonInfo('version'))
        except:
            pass  # Ignore if addon context is invalid
        
        try:
            get_uuid()
        except:
            pass  # Ignore if addon context is invalid
            
        try:
            if get_setting('androidtv.path'):
                self.atv = AndroidTv()
        except Exception as e:
            debug('AndroidTV initialization error: {}'.format(str(e)))
            self.atv = None
        
        # Cleanup will be handled by the main loop monitoring abortRequested

    def run(self):
        debug('START SERVICE....................................................................')
        
        def _background_init():
            """Run expensive initialization tasks in background to avoid blocking main thread"""
            try:
                # Network-dependent operations that could block
                if get_setting('kraska.user'):
                    kra = Kraska()
                    kra.check_user()
                
                kr = Kraska()
                if kr.username and kr.password:
                    kr.login()
                
                # Texture cleanup can be I/O intensive
                clean_textures()
            except Exception as e:
                debug('Background initialization error: {}'.format(str(e)))
        
        try:
            # Fast, non-blocking initialization
            last_changelog = get_setting('system.changelog')
            
            # Quick version check without blocking operations
            if last_changelog != ADDON.getAddonInfo('version'):
                debug('SYSTEM.CHANGELOG: {}'.format(ADDON.getAddonInfo('changelog')))
                set_setting('system.changelog', '{}'.format(ADDON.getAddonInfo('version')))
                # Show changelog in non-blocking way if needed
                try:
                    if get_setting_as_bool('system.show.changelog'):
                        dtextviewer('', ADDON.getAddonInfo('changelog'))
                except (TypeError, Exception):
                    # Setting doesn't exist, skip changelog display
                    pass

            # Non-blocking UI operations
            try:
                if get_setting_as_bool('system.autoexec'):
                    try:
                        exec_build_in('ActivateWindow(videos,plugin://{})'.format(ADDON_ID))
                    except:
                        pass
            except (TypeError, Exception):
                # Setting doesn't exist, skip autoexec
                pass

            # Initialize NextEp service
            self.next_ep = NextEp()
            
            # Offload network and I/O operations to background thread
            from resources.lib.common.threading_utils import run_in_background
            run_in_background(_background_init, thread_name="Service-BackgroundInit")
            
            # Quick addon update check (non-blocking)
            try:
                update_addon()
            except Exception as e:
                debug('Addon update check error: {}'.format(str(e)))
        except Exception as e:
            debug('Error during service initialization: {}'.format(str(e)))
            debug('Initialization traceback: {}'.format(traceback.format_exc()))

        # MEMORY LEAK FIX: Track player thread for cleanup
        from resources.lib.common.threading_utils import run_in_background
        self._player_thread = run_in_background(player.run, thread_name="SCPlayer-Monitor")

        # FIX: Dynamic sleep based on activity, not blind scaling
        base_interval = 5000    # 5 seconds base
        idle_interval = 15000   # 15 seconds when idle
        streaming_interval = 3000  # 3 seconds during streaming
        
        try:
            while not monitor.abortRequested():
                # FIX: Define check_interval outside try block to prevent UnboundLocalError
                current_time = time.time()
                
                # FIX: Smart interval based on system state
                if self._is_streaming_active():
                    check_interval = streaming_interval
                else:
                    # Check if player is active with error handling
                    try:
                        is_playing = player.isPlayback()
                    except (RuntimeError, AttributeError):
                        # Player not active or method not available
                        is_playing = False
                    
                    if is_playing:  # Any playback active - use player not monitor
                        check_interval = base_interval
                    else:
                        check_interval = idle_interval
                
                try:
                    if current_time - self._last_check >= check_interval / 1000:
                        self.periodical_check()
                        self._periodic_cleanup()  # FIX: Add periodic cleanup
                        
                        # Run watchdog check every 5 minutes for critical component monitoring
                        if not hasattr(self, '_last_watchdog_check'):
                            self._last_watchdog_check = 0
                        if current_time - self._last_watchdog_check >= 300:  # 5 minutes
                            self._watchdog_check()
                            self._thread_health_check()
                            self._last_watchdog_check = current_time
                            
                        self._last_check = current_time
                except Exception as e:
                    debug('periodical_check error: {}'.format(str(e)))
                    debug('error traceback: {}'.format(traceback.format_exc()))
                
                # Use Monitor.waitForAbort() for responsive shutdown instead of sleep()
                if monitor.waitForAbort(check_interval / 1000.0):
                    break
        finally:
            # MEMORY LEAK FIX: Ensure player thread is properly terminated
            try:
                if hasattr(self, '_player_thread') and self._player_thread.is_alive():
                    # Signal player to stop if it has a stop method
                    if hasattr(player, 'stop'):
                        player.stop()
                    # Give thread time to clean up
                    self._player_thread.join(timeout=2.0)
            except:
                pass
            
            # Cleanup when monitor requests abort (safer than atexit)
            self.cleanup()

    def _is_streaming_active(self):
        """Check if streaming is currently active"""
        # Always return False since we removed telemetry tracking
        return False
    
    def _periodic_cleanup(self):
        """Periodic cleanup to prevent memory leaks"""
        current_time = time.time()
        
        # Only run cleanup every 10 minutes
        if current_time - self._last_cleanup < 600:
            return
            
        debug('Running periodic cleanup...')
        self._last_cleanup = current_time
        
        try:
            # Cleanup database connections (if available)
            try:
                from resources.lib.common.storage import Sqlite
                if hasattr(Sqlite, 'cleanup_connections_older_than'):
                    Sqlite.cleanup_connections_older_than(300)  # 5 minutes
            except:
                pass
            
            # Monitor and log resource usage for 24-hour stability
            try:
                import gc
                import threading
                
                object_count = len(gc.get_objects())
                thread_count = threading.active_count()
                
                debug('Resource monitoring - Objects: {}, Threads: {}'.format(object_count, thread_count))
                
                # Force garbage collection if object count is high
                if object_count > 50000:  # Threshold check
                    debug('High object count detected, forcing garbage collection...')
                    gc.collect()
                    new_count = len(gc.get_objects())
                    debug('Garbage collection completed: {} -> {} objects'.format(object_count, new_count))
                
                # Warn about high thread count
                if thread_count > 20:
                    debug('Warning: High thread count detected: {}'.format(thread_count))
                    
            except Exception as e:
                debug('Resource monitoring error: {}'.format(str(e)))
                
        except Exception as e:
            debug('Periodic cleanup error: {}'.format(str(e)))

    def periodical_check(self):
        if monitor.can_check():
            try:
                player.periodical_check()
            except Exception as e:
                debug('player periodical_check err: {}'.format(str(e)))
                debug('player periodical_check traceback: {}'.format(traceback.format_exc()))

            try:
                monitor.periodical_check()
            except:
                debug('monitor err: {}'.format(traceback.format_exc()))
                pass

            try:
                if self.atv:
                    self.atv.run()
            except:
                debug('android tv err: {}'.format(traceback.format_exc()))
                pass

            if get_setting('trakt.user'):
                try:
                    from resources.lib.trakt.Trakt import trakt
                    trakt.check_trakt()
                except:
                    debug('trakt err: {}'.format(traceback.format_exc()))
                    pass

            try:
                self.next_ep.run()
            except:
                debug('nextep err: {}'.format(traceback.format_exc()))
                pass

    def cleanup(self):
        """Comprehensive cleanup to prevent memory leaks - safe for shutdown"""
        # Prevent multiple cleanup calls with thread-safe check
        import threading
        if hasattr(self, '_cleanup_lock'):
            cleanup_lock = self._cleanup_lock
        else:
            cleanup_lock = threading.Lock()
            self._cleanup_lock = cleanup_lock
            
        with cleanup_lock:
            if self._cleanup_called:
                return
            self._cleanup_called = True
        
        debug('Starting comprehensive service cleanup...')
        
        try:
            # Cleanup Monitor callbacks
            if monitor:
                try:
                    monitor.cleanup()
                except:
                    pass  # Ignore errors during shutdown
            
            # Cleanup Player
            if player:
                try:
                    player.clean()
                except:
                    pass  # Ignore errors during shutdown
            
            # Cleanup database connections - don't rely on addon context
            try:
                from resources.lib.common.storage import Sqlite, cleanup_all_storage_caches
                Sqlite.cleanup_all_connections()
                cleanup_all_storage_caches()
            except:
                pass  # Ignore errors during shutdown
            
            # Cleanup API caches
            try:
                if hasattr(Sc, 'cache') and Sc.cache:
                    Sc.cache.close()
            except:
                pass  # Ignore errors during shutdown
            
            # Cleanup threading resources
            try:
                from resources.lib.common.threading_utils import cleanup_all_threading
                cleanup_all_threading()
            except:
                pass  # Ignore errors during shutdown
            
            # Force garbage collection
            try:
                import gc
                gc.collect()
            except:
                pass  # Ignore errors during shutdown
            
            debug('Service cleanup complete')
        except Exception as e:
            # Don't use debug() here as it might access addon context
            try:
                debug('Error during service cleanup: {}'.format(str(e)))
            except:
                pass  # Completely ignore if even debug fails

    def _watchdog_check(self):
        """Watchdog to monitor critical component health for 24-hour stability"""
        try:
            # Check if player thread is still alive
            if hasattr(self, '_player_thread') and self._player_thread:
                if not self._player_thread.is_alive():
                    debug('WATCHDOG: Player thread died, restarting...')
                    from resources.lib.common.threading_utils import run_in_background
                    self._player_thread = run_in_background(player.run, thread_name="SCPlayer-Monitor")
            
            # Check if NextEp service is responsive
            if self.next_ep:
                try:
                    # Simple health check - ensure the object is still valid
                    if not hasattr(self.next_ep, 'run'):
                        debug('WATCHDOG: NextEp service corrupted, reinitializing...')
                        from resources.lib.services.next_episodes import NextEp
                        self.next_ep = NextEp()
                except Exception as e:
                    debug('WATCHDOG: NextEp check error: {}'.format(str(e)))
                    
        except Exception as e:
            debug('WATCHDOG: Check error: {}'.format(str(e)))
    
    def _thread_health_check(self):
        """Check thread health and log any issues"""
        try:
            from resources.lib.common.thread_monitor import get_thread_health_report, log_thread_summary
            
            health_report = get_thread_health_report()
            
            if not health_report['healthy']:
                debug('THREAD HEALTH: Issues detected')
                for issue in health_report['issues']:
                    debug(f'THREAD HEALTH ISSUE: {issue}')
                
                # Log detailed thread summary when issues are detected
                log_thread_summary()
            
            if health_report['warnings']:
                for warning in health_report['warnings']:
                    debug(f'THREAD HEALTH WARNING: {warning}')
            
            # Log thread count for monitoring
            debug(f'THREAD HEALTH: {health_report["thread_count"]} active threads')
            
        except Exception as e:
            debug('THREAD HEALTH: Check error: {}'.format(str(e)))


service = Service()
