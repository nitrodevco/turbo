# -*- coding: utf-8 -*-

import datetime
import json
import time
import traceback

from resources.lib.common.cache import SimpleCache, use_cache
from resources.lib.common.logger import debug, info
from resources.lib.constants import BASE_URL, API_VERSION, SC, ADDON
from resources.lib.kodiutils import get_uuid, get_skin_name, get_setting_as_bool, get_setting_as_int, get_setting, \
    file_put_contents, translate_path, file_exists, file_get_contents
from resources.lib.system import user_agent, Http, SYSTEM_LANG_CODE

try:
    # Python 3
    from urllib.parse import urlparse, parse_qs
except ImportError:
    # Python 2
    from urlparse import urlparse, parse_qs


class Sc:
    RATING_MAP = {
        "0": 0,
        "1": 6,
        "2": 12,
        "3": 15,
        "4": 18,
    }

    cache = SimpleCache()
    static_cache = {}  # Simplified - static cache disabled

    @staticmethod
    def get(path, params=None, ttl=None):
        # KODI OPTIMIZATION: Ensure cache state is properly initialized for each plugin call
        if not hasattr(Sc, '_cache_initialized'):
            Sc._reset_cache_state()
            Sc._cache_initialized = True
            
        Sc.load_static_cache()  # Just initializes empty cache

        sorted_values, url = Sc.prepare(params, path)
        
        # PERFORMANCE FIX: Optimize cache key generation - use hash for large param sets
        if len(str(sorted_values)) > 200:
            import hashlib
            param_hash = hashlib.md5(str(sorted_values).encode()).hexdigest()
            key = '{}{}{}'.format(ADDON.getAddonInfo('version'), url, param_hash)
        else:
            key = '{}{}{}'.format(ADDON.getAddonInfo('version'), url, sorted_values)
        
        debug('CALL {} PARAMS {} KEY {}'.format(url, sorted_values, key))
        start = time.time()
        ret = Sc.cache.get(key)
        if ret is None:
            start = time.time()
            
            # KODI OPTIMIZATION: Add compression support for better performance
            headers = Sc.headers()
            headers['Accept-Encoding'] = 'gzip, deflate'
            
            # STREAMING OPTIMIZATION: Add connection pooling and timeout for Kodi
            try:
                # PERFORMANCE: Use session for connection pooling
                if not hasattr(Http, '_session'):
                    import requests
                    Http._session = requests.Session()
                    # KODI OPTIMIZATION: Configure connection pool for streaming
                    adapter = requests.adapters.HTTPAdapter(
                        pool_connections=10,
                        pool_maxsize=20,  # Increased for better streaming performance
                        max_retries=3,
                        pool_block=False  # Don't block on pool exhaustion
                    )
                    Http._session.mount('http://', adapter)
                    Http._session.mount('https://', adapter)
                    
                    # STREAMING OPTIMIZATION: Set session-level optimizations
                    Http._session.headers.update({
                        'User-Agent': 'Kodi/20.0 (compatible; Stream Cinema)',
                        'Accept': 'application/json, text/plain, */*',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Cache-Control': 'no-cache',
                        'Connection': 'keep-alive'
                    })
                
                # PERFORMANCE: Set reasonable timeout to prevent hanging in Kodi
                res = Http._session.get(url, headers=headers, params=sorted_values, 
                                       timeout=(5.0, 30.0),  # (connect, read) timeouts
                                       stream=False)  # Don't stream for API calls
                end = time.time()
                res.raise_for_status()
                
                # KODI OPTIMIZATION: Handle compressed responses
                if res.headers.get('content-encoding') in ['gzip', 'deflate']:
                    debug('Received compressed response, size: {} bytes'.format(len(res.content)))
                
                ret = res.json()
                
                # STREAMING OPTIMIZATION: Cache successful responses with TTL
                cache_ttl = ttl if ttl is not None else 300  # 5 minutes default
                Sc.cache.set(key, ret, cache_ttl)
                
                debug('API call completed in {:.2f}s, cached for {}s'.format(end - start, cache_ttl))
                
            except requests.exceptions.Timeout:
                debug('API request timed out')
                return None
            except requests.exceptions.ConnectionError:
                debug('API connection error')
                return None
            except requests.exceptions.RequestException as e:
                debug('API request failed: {}'.format(str(e)))
                return None
            except Exception as e:
                debug('Unexpected API error: {}'.format(str(e)))
                return None
        else:
            debug('Cache hit for key: {}'.format(key))
        
        return ret

    @staticmethod
    def prepare(params, path):
        url = BASE_URL + path
        o = urlparse(url)
        query = parse_qs(o.query)
        url = o._replace(query=None).geturl()
        p = Sc.default_params(query)
        # debug('p: {}'.format(p))
        query.update(p)
        if params is not None:
            query.update(params)
        sorted_values = sorted(query.items(), key=lambda val: val[0])
        # debug('sorted: {}'.format(sorted_values))
        return sorted_values, url

    @staticmethod
    def post(path, **kwargs):
        sorted_values, url = Sc.prepare(path=path, params={})
        start = time.time()
        
        # Add compression support for POST requests
        headers = Sc.headers()
        headers['Accept-Encoding'] = 'gzip, deflate'
        
        res = Http.post(url, params=sorted_values, headers=headers, **kwargs)
        end = time.time()
        debug('POST took {0:.2f}ms'.format((end - start) * 1000))
        try:
            return res.json()
        except ValueError:
            # Handle malformed JSON gracefully
            debug('Invalid JSON response from POST {}'.format(url))
            return {'error': 'Invalid JSON response'}

    @staticmethod
    def default_params(query):
        # Cache frequently computed params to avoid repeated function calls
        if not hasattr(Sc, '_cached_default_params'):
            Sc._cached_default_params = {
                'ver': API_VERSION,
                'uid': get_uuid(),
                'skin': get_skin_name(),
                'lang': SYSTEM_LANG_CODE,
            }
            Sc._cached_params_time = time.time()
        
        # Refresh cached params every 5 minutes
        if time.time() - Sc._cached_params_time > 300:
            Sc._cached_default_params.update({
                'uid': get_uuid(),
                'skin': get_skin_name(),
            })
            Sc._cached_params_time = time.time()
        
        # Start with cached params
        params = Sc._cached_default_params.copy()
        
        # Only compute expensive settings when needed
        parental_control = Sc.parental_control_is_active()
        
        # Batch setting lookups for better performance
        settings_batch = {}
        if get_setting_as_bool('stream.dubed') or (parental_control and get_setting_as_bool('parental.control.dubed')):
            settings_batch['dub'] = 1

        if not parental_control and get_setting_as_bool('stream.dubed.titles'):
            settings_batch.update({'dub': 1, "tit": 1})

        if parental_control:
            settings_batch["m"] = Sc.RATING_MAP.get(get_setting('parental.control.rating'))

        if get_setting_as_bool('plugin.show.genre'):
            settings_batch['gen'] = 1

        if 'HDR' not in query:
            settings_batch['HDR'] = 0 if get_setting_as_bool('stream.exclude.hdr') else 1

        if 'DV' not in query:
            settings_batch['DV'] = 0 if get_setting_as_bool('stream.exclude.dolbyvision') else 1

        if get_setting_as_bool('plugin.show.old.menu'):
            settings_batch['old'] = 1

        # Apply all settings at once
        params.update(settings_batch)
        return params

    @staticmethod
    def parental_control_is_active():
        now = datetime.datetime.now()
        hour_start = get_setting_as_int('parental.control.start')
        hour_now = now.hour
        hour_end = get_setting_as_int('parental.control.end')
        return get_setting_as_bool('parental.control.enabled') and hour_start <= hour_now <= hour_end

    @staticmethod
    def headers(token=True):
        headers = {
            'User-Agent': user_agent(),
            'X-Uuid': get_uuid(),
        }
        if token:
            headers['X-AUTH-TOKEN'] = Sc.get_auth_token()
        return headers

    @staticmethod
    def get_auth_token(force = False):
        token = ''
        if force is False:
            token = ADDON.getSetting('system.auth_token')

        if token == '' or token is None or token == 'None' or token is False:
            from resources.lib.api.kraska import Kraska

            kr = Kraska()
            if kr.get_token():
                found = kr.list_files(filter=SC.BCK_FILE)
                if len(found.get('data', [])) == 1:
                    for f in found.get('data', []):
                        try:
                            url = kr.resolve(f.get('ident'))
                            data = Http.get(url)
                            if len(data.text) == 32:
                                token = data.text
                                ADDON.setSetting('system.auth_token', token)
                                return token
                        except Exception as e:
                            debug('error get auth token: {}'.format(traceback.format_exc()))
                else:
                    debug('backup file not found {}'.format(SC.BCK_FILE))

            path = '/auth/token'
            sorted_values, url = Sc.prepare(path=path, params={})
            res = Http.post(url, params=sorted_values, headers=Sc.headers(False))
            res.raise_for_status()
            ret = res.json()
            if 'error' in ret:
                debug('error get auth token: {}'.format(ret))
                return None
            if 'token' not in ret:
                debug('error get auth token: {}'.format(ret))
                return None
            token = ret['token']
            ADDON.setSetting('system.auth_token', token)
            try:
                kr.upload(token, SC.BCK_FILE)
            except Exception as e:
                pass
        else:
            debug('auth token from settings {}'.format(token))
        return token

    @staticmethod
    def up_next(id, s, e):
        url = '/upNext/{}/{}/{}'.format(id, s, e)
        try:
            data = Sc.get(url, ttl=3600)
        except:
            data = {'error': 'error'}
        return data

    @staticmethod
    def save_cache(ret, key, ttl=None):
        ttl = 3600 if ttl is None else ttl

        if SC.ITEM_SYSTEM in ret and 'TTL' in ret[SC.ITEM_SYSTEM]:
            ttl = int(ret[SC.ITEM_SYSTEM]['TTL'])

        debug('SAVE TO CACHE {} / {}'.format(ttl, key))
        Sc.cache.set(key, ret, expiration=datetime.timedelta(seconds=ttl))

    # static_cache_local_name() and static_cache_filename() removed - static cache disabled

    # download_menu() removed - was disabled and unused

    # download_menu_bg() removed - was disabled and used custom threading

    @staticmethod
    def _reset_cache_state():
        """Reset cache state for each plugin call to avoid persistence issues"""
        # Reset cached parameters that might become stale across plugin calls
        if hasattr(Sc, '_cached_default_params'):
            delattr(Sc, '_cached_default_params')
        if hasattr(Sc, '_cached_params_time'):
            delattr(Sc, '_cached_params_time')

    @staticmethod
    def load_static_cache():
        # Static cache disabled - just initialize empty cache
        Sc.static_cache = {}
