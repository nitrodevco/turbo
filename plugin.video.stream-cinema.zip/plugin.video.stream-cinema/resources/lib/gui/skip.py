import xbmcgui
import weakref
from resources.lib.common.logger import debug


class Skip(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        self._callback_ref = None  # Use weak reference to prevent memory leaks
        self.is_visible = False

    @property
    def is_button_visible(self):
        return self.is_visible

    def onInit(self):  # type: () -> None
        self.setFocus(self.getControl(3001))

    def onClick(self, control_id):
        debug('SKIP onclick: ' + str(control_id))
        if control_id == 3001:
            # Safely call callback using weak reference
            if self._callback_ref is not None:
                callback = self._callback_ref()
                if callback is not None:
                    callback()
                else:
                    debug('Skip callback was garbage collected')

    def onAction(self, action):  # type: (Action) -> None
        # if action ==
        debug("action: {}".format(action.getId()))
        pass

    def set_visibility(self):
        self.is_visible = not self.is_visible

    def show_with_callback(self, callback):
        # Store weak reference to callback to prevent memory leaks
        if callback is not None:
            try:
                self._callback_ref = weakref.ref(callback)
            except TypeError:
                # Callback is not a bound method, store directly (but this might cause leaks)
                self._callback_ref = lambda: callback
        else:
            self._callback_ref = None
            
        if self.is_button_visible is False:
            self.show()
            self.set_visibility()

    def cleanup(self):
        """Cleanup method to prevent memory leaks"""
        debug('Cleaning up Skip dialog...')
        self._callback_ref = None
        if self.is_visible:
            try:
                self.close()
            except:
                pass
        self.is_visible = False
        debug('Skip dialog cleanup complete')

