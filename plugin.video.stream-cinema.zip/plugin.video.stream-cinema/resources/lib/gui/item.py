import re
import time
from json import dumps, loads

import xbmc
import xbmcvfs
from xbmcgui import ListItem


from resources.lib.api.kraska import Kraska, ResolveException
from resources.lib.api.sc import Sc
from resources.lib.common.lists import List, SCKODIItem
from resources.lib.common.logger import info, debug
from resources.lib.common.storage import preferred_lang_list
from resources.lib.constants import ADDON_ID, SC, GUI
from resources.lib.debug import try_catch
from resources.lib.gui import get_cond_visibility as gcv, home_win
from resources.lib.kodiutils import create_plugin_url, convert_bitrate, get_setting_as_bool, get_setting_as_int, \
    get_setting, get_info_label, get_system_platform, decode, make_nfo_content, translate_path, make_legal_filename, \
    microtime, get_isp
from resources.lib.language import Strings
from resources.lib.params import params
from resources.lib.services.Settings import settings
from resources.lib.system import SYSTEM_LANG_CODE

list_item = ListItem
list_hp = List('HP')


def parental_history():
    return get_setting_as_bool('parental.control.enabled')  # and get_setting_as_bool('parental.control.history')


def get_history_item_name(item):
    return 'p-{}'.format(item) if parental_history() else item


class SCItem:
    def __init__(self, data):
        self.item = None
        self.visible = False
        if SC.ITEM_TYPE in data:
            self.item_by_type(data)
        elif SC.ITEM_STRMS in data:
            info('PLAY ITEM')
            self.item = SCPlayItem(data)
        else:
            info('Neznama polozka {}'.format(str(data)))

    def item_by_type(self, data):
        item_type = data.get(SC.ITEM_TYPE, None)
        if item_type == SC.ITEM_DIR:
            self.item = SCDir(data)
        elif item_type == SC.ITEM_VIDEO:
            self.item = SCVideo(data)
        elif item_type == SC.ITEM_HPDIR:
            self.item = SCHPDir(data)
        elif item_type == SC.ITEM_CUSTOM_FILTER:
            self.item = SCCustomFilterDir(data)
        elif item_type == SC.ITEM_CMD:
            self.item = SCCmd(data)
        elif item_type == SC.ITEM_ACTION:
            self.item = SCAction(data)
        elif item_type == SC.ITEM_NEXT:
            self.item = SCNext(data)
        elif item_type == 'ldir':
            self.item = SCLDir(data)
        elif item_type == 'add_custom_filter':
            self.item = SCAction(data)
        else:
            info('Nepodporovana polozka {} {}'.format(item_type, data))

        try:
            self.visible = self.item.visible()
        except AttributeError as e:
            # Item doesn't have visible() method or item is None
            debug('Item visibility check failed: {}'.format(str(e)))
            self.visible = True  # Default to visible
        except Exception as e:
            # Log unexpected errors but don't crash
            debug('Unexpected error in visibility check: {}'.format(str(e)))
            self.visible = True  # Default to visible

    def li(self):
        return self.item.item

    def get(self):
        if self.item is None:
            return None, None, False, None
        item_result = self.item.get()
        # All get() methods now return 4 values consistently
        return item_result


class SCBaseItem:
    def __init__(self, data, debug=False):
        self.item = list_item()
        self.data = data
        self.info_set = False
        self.info = {}
        self.debug = debug

        if SC.ITEM_TITLE in data:
            title_value = data.get(SC.ITEM_TITLE)
            if title_value is not None and str(title_value).strip() != '' and str(title_value) != 'None':
                self.item.setLabel(str(title_value))

        if SC.ITEM_URL in data:
            url = create_plugin_url(data)
            self.item.setPath(url)

        if SC.ITEM_ART in data:
            self.set_art()
        elif SC.ITEM_I18N_ART in data:
            self.set_i18n_art()

        if SC.ITEM_INFO in data:
            self.set_info()
        elif SC.ITEM_I18N_INFO in data:
            self._set_info(self.i18n_info({}))

        if 'cast' in data:
            self.set_cast()

        if 'unique_ids' in data:
            self.set_unique_ids()

        if 'stream_info' in data:
            self.set_stream_info()

    @try_catch('set_stream_info')
    def set_stream_info(self):
        stream_info = self.data.get('stream_info')
        # Fix #7: Properly iterate over stream_info dictionary items
        for key, value in stream_info.items():
            if key in ['video', 'audio', 'subtitle']:
                try:
                    # Use new InfoTagVideo API (Kodi 20+)
                    info_tag = self.item.getVideoInfoTag()
                    if key == 'video':
                        # Convert video stream dictionary to xbmc.VideoStreamDetail object
                        if isinstance(value, dict):
                            try:
                                video_stream = xbmc.VideoStreamDetail(
                                    width=int(value.get('width', 0)),
                                    height=int(value.get('height', 0)),
                                    aspect=float(value.get('aspect', 0.0)),
                                    duration=int(value.get('duration', 0)),
                                    codec=str(value.get('codec', '')),
                                    stereomode=str(value.get('stereomode', '')),
                                    language=str(value.get('language', '')),
                                    hdrtype=str(value.get('hdrtype', ''))
                                )
                                info_tag.addVideoStream(video_stream)
                            except (ValueError, TypeError) as e:
                                debug('Failed to create VideoStreamDetail: {}'.format(str(e)))
                                # Log error but don't fall back - require modern Kodi
                        else:
                            # If it's already a VideoStreamDetail object, use it as-is
                            info_tag.addVideoStream(value)
                    elif key == 'audio':
                        # Convert audio stream dictionary to xbmc.AudioStreamDetail object
                        if isinstance(value, dict):
                            try:
                                audio_stream = xbmc.AudioStreamDetail(
                                    channels=int(value.get('channels', 2)),
                                    codec=str(value.get('codec', '')),
                                    language=str(value.get('language', ''))
                                )
                                info_tag.addAudioStream(audio_stream)
                            except (ValueError, TypeError) as e:
                                debug('Failed to create AudioStreamDetail: {}'.format(str(e)))
                                # Log error but don't fall back - require modern Kodi
                        else:
                            # If it's already an AudioStreamDetail object, use it as-is
                            info_tag.addAudioStream(value)
                    elif key == 'subtitle':
                        # Convert subtitle stream dictionary to xbmc.SubtitleStreamDetail object
                        if isinstance(value, dict):
                            try:
                                subtitle_stream = xbmc.SubtitleStreamDetail(
                                    language=str(value.get('language', ''))
                                )
                                info_tag.addSubtitleStream(subtitle_stream)
                            except (ValueError, TypeError) as e:
                                debug('Failed to create SubtitleStreamDetail: {}'.format(str(e)))
                                # Log error but don't fall back - require modern Kodi
                        else:
                            # If it's already a SubtitleStreamDetail object, use it as-is
                            info_tag.addSubtitleStream(value)
                except (AttributeError, TypeError) as e:
                    debug('Failed to set stream info using new API: {}'.format(str(e)))
                    # Log error but don't fall back - require modern Kodi

        if 'fvideo' in stream_info:
            debug('FVIDEO: {}'.format(stream_info['fvideo']))
            self.item.setProperty('video', stream_info['fvideo'])

        if 'faudio' in stream_info:
            self.item.setProperty('audio', stream_info['faudio'])

    @try_catch('set_unique_ids')
    def set_unique_ids(self):
        unique_ids = self.data.get('unique_ids')
        if unique_ids:
            # Use new InfoTagVideo API (Kodi 20+) - no fallbacks
            info_tag = self.item.getVideoInfoTag()
            info_tag.setUniqueIDs(unique_ids)

    @try_catch('set_cast')
    def set_cast(self):
        cast = self.data.get('cast', [])
        if cast:
            # Use new InfoTagVideo API (Kodi 20+) - no fallbacks
            info_tag = self.item.getVideoInfoTag()
            # Convert cast dictionaries to xbmc.Actor objects
            actor_objects = []
            for actor_data in cast:
                if isinstance(actor_data, dict):
                    try:
                        actor = xbmc.Actor(
                            str(actor_data.get('name', '')),
                            str(actor_data.get('role', '')),
                            int(actor_data.get('order', 0)),
                            str(actor_data.get('thumbnail', ''))
                        )
                    except (ValueError, TypeError) as e:
                        debug('Failed to create Actor object: {}'.format(str(e)))
                        # Create a basic actor with just the name
                        actor = xbmc.Actor(str(actor_data.get('name', '')))
                    actor_objects.append(actor)
                else:
                    # If it's already an Actor object, use it as-is
                    actor_objects.append(actor_data)
            info_tag.setCast(actor_objects)

    @try_catch('set_art')
    def set_art(self):
        self.item.setArt(self.data.get(SC.ITEM_ART, {}))

    @try_catch('set_i18n_art')
    def set_i18n_art(self):
        i18n = self.data.get(SC.ITEM_I18N_ART)
        lang = SYSTEM_LANG_CODE
        if lang not in i18n:
            debug('jazyk {} nemame, tak nastavujem cs'.format(lang))
            lang = SC.DEFAULT_LANG
        # debug('jazyk {}'.format(lang))
        self.item.setArt(i18n.get(lang))

    @try_catch('_set_info')
    def _set_info(self, item_info):
        if self.debug:
            debug('set_info {}'.format(item_info))
        self.info.update(item_info)
        try:
            if SC.ITEM_TITLE in item_info:
                title_value = item_info.get(SC.ITEM_TITLE)
                if title_value is not None and str(title_value).strip() != '' and str(title_value) != 'None':
                    title = '{}'.format(title_value)
                    self.item.setLabel(title)

            # Fix: Create a copy to avoid mutating dictionary during iteration
            info_copy = item_info.copy()
            
            if self.data.get('play'):
                # Handle null/None title by using otitle or epname as fallback
                current_title = info_copy.get(SC.ITEM_TITLE)
                debug('TITLE DEBUG: current_title={}, otitle={}, epname={}'.format(
                    current_title, info_copy.get('otitle'), info_copy.get('epname')))
                
                # Only override i18n title if it's null/None/empty or if we have epname (episodes)
                if current_title is None or current_title == 'None' or str(current_title).strip() == '':
                    # Title is null/empty, use fallbacks
                    if 'otitle' in info_copy and info_copy['otitle']:
                        info_copy[SC.ITEM_TITLE] = info_copy.pop('otitle')
                        debug('TITLE DEBUG: Used otitle as fallback: {}'.format(info_copy[SC.ITEM_TITLE]))
                    elif 'epname' in info_copy and info_copy['epname']:
                        info_copy[SC.ITEM_TITLE] = info_copy.pop('epname')
                        debug('TITLE DEBUG: Used epname as fallback: {}'.format(info_copy[SC.ITEM_TITLE]))
                else:
                    # Title exists (likely from i18n), only override for episodes
                    if 'epname' in info_copy and info_copy['epname']:
                        info_copy[SC.ITEM_TITLE] = info_copy.pop('epname')
                        debug('TITLE DEBUG: Used epname over existing title: {}'.format(info_copy[SC.ITEM_TITLE]))
                    # Don't override i18n title with otitle unless title was null
                    debug('TITLE DEBUG: Keeping existing title (likely i18n): {}'.format(current_title))
                    # Clean up unused otitle
                    info_copy.pop('otitle', None)
            else:
                info_copy.pop('epname', None)
                info_copy.pop('otitle', None)

            for key, value in info_copy.items():
                # debug('set info {} {}'.format(key, value))
                self.item.setProperty(key, '{}'.format(value))

            if info_copy.get('mediatype', '') == 'season' and info_copy.get('episode'):
                item = SCKODIItem(self.data.get(SC.ITEM_ID))
                data = item.data
                total_episodes = info_copy.get('episode')
                watched = len(data.get('series:{}'.format(info_copy.get('season')), {}))
                debug('Mame seriu {} s {}/{} epizodami'.format(info_copy.get('season'), watched, total_episodes))
                if watched >= total_episodes:
                    info_copy['playcount'] = '1'

            try:
                # Use new InfoTagVideo API (Kodi 20+)
                info_tag = self.item.getVideoInfoTag()
                
                # Map common video info fields to InfoTagVideo setters
                if 'title' in info_copy and info_copy['title'] is not None and str(info_copy['title']).strip() != '' and str(info_copy['title']) != 'None':
                    final_title = str(info_copy['title'])
                    debug('TITLE DEBUG: Setting InfoTagVideo title to: {}'.format(final_title))
                    info_tag.setTitle(final_title)
                else:
                    debug('TITLE DEBUG: Skipping InfoTagVideo title - invalid value: {}'.format(info_copy.get('title')))
                if 'originaltitle' in info_copy:
                    info_tag.setOriginalTitle(str(info_copy['originaltitle']))
                if 'plot' in info_copy:
                    info_tag.setPlot(str(info_copy['plot']))
                if 'year' in info_copy:
                    try:
                        info_tag.setYear(int(info_copy['year']))
                    except (ValueError, TypeError):
                        pass
                if 'rating' in info_copy:
                    try:
                        info_tag.setRating(float(info_copy['rating']))
                    except (ValueError, TypeError):
                        pass
                if 'duration' in info_copy:
                    try:
                        info_tag.setDuration(int(info_copy['duration']))
                    except (ValueError, TypeError):
                        pass
                if 'genre' in info_copy:
                    if isinstance(info_copy['genre'], list):
                        info_tag.setGenres(info_copy['genre'])
                    else:
                        info_tag.setGenres([str(info_copy['genre'])])
                if 'director' in info_copy:
                    if isinstance(info_copy['director'], list):
                        info_tag.setDirectors(info_copy['director'])
                    else:
                        info_tag.setDirectors([str(info_copy['director'])])
                if 'writer' in info_copy:
                    if isinstance(info_copy['writer'], list):
                        info_tag.setWriters(info_copy['writer'])
                    else:
                        info_tag.setWriters([str(info_copy['writer'])])
                if 'studio' in info_copy:
                    if isinstance(info_copy['studio'], list):
                        info_tag.setStudios(info_copy['studio'])
                    else:
                        info_tag.setStudios([str(info_copy['studio'])])
                if 'country' in info_copy:
                    if isinstance(info_copy['country'], list):
                        info_tag.setCountries(info_copy['country'])
                    else:
                        info_tag.setCountries([str(info_copy['country'])])
                if 'mpaa' in info_copy:
                    info_tag.setMpaa(str(info_copy['mpaa']))
                if 'mediatype' in info_copy:
                    info_tag.setMediaType(str(info_copy['mediatype']))
                if 'playcount' in info_copy:
                    try:
                        info_tag.setPlaycount(int(info_copy['playcount']))
                    except (ValueError, TypeError):
                        pass
                if 'lastplayed' in info_copy:
                    info_tag.setLastPlayed(str(info_copy['lastplayed']))
                if 'dateadded' in info_copy:
                    info_tag.setDateAdded(str(info_copy['dateadded']))
                if 'premiered' in info_copy:
                    info_tag.setPremiered(str(info_copy['premiered']))
                if 'trailer' in info_copy:
                    info_tag.setTrailer(str(info_copy['trailer']))
                if 'tagline' in info_copy:
                    info_tag.setTagLine(str(info_copy['tagline']))
                    
                # TV Show specific fields
                if 'season' in info_copy:
                    try:
                        info_tag.setSeason(int(info_copy['season']))
                    except (ValueError, TypeError):
                        pass
                if 'episode' in info_copy:
                    try:
                        info_tag.setEpisode(int(info_copy['episode']))
                    except (ValueError, TypeError):
                        pass
                if 'tvshowtitle' in info_copy:
                    info_tag.setTvShowTitle(str(info_copy['tvshowtitle']))
                if 'aired' in info_copy:
                    info_tag.setFirstAired(str(info_copy['aired']))
                    
            except AttributeError as e:
                debug('Failed to set video info using new API: {}'.format(str(e)))
                # Log error but don't fall back - require modern Kodi
            self.item.setProperty('original_title', info_copy.get('originaltitle'))
            # Update the original item_info with any changes made to info_copy
            item_info.update(info_copy)
            self.info_set = True
        except Exception as e:
            import traceback
            info('-----------------------------------------------------------------')
            info('set info error [{}]'.format(str(traceback.format_exc())))
            info('-----------------------------------------------------------------')

    @try_catch('set_info')
    def set_info(self):
        item_info = self.data.get(SC.ITEM_INFO, {})
        if SC.ITEM_I18N_INFO in self.data:
            item_info = self.i18n_info(item_info)
        self._set_info(item_info)

    @try_catch('i18n_info')
    def i18n_info(self, item_info={}):
        i18n = self.data.get(SC.ITEM_I18N_INFO)
        lang = SYSTEM_LANG_CODE
        if lang not in i18n:
            debug('jazyk {} nemame, tak nastavujem cs'.format(lang))
            lang = SC.DEFAULT_LANG
        item_info.update(i18n.get(lang))
        return item_info

    @try_catch('get')
    def get(self):
        if self.info_set is False:
            self._set_info({SC.MEDIA_TYPE: SC.MEDIA_TYPE_VIDEO})
        return self.item.getPath(), self.item, True, None

    @try_catch('visible')
    def visible(self):
        visible = True
        if SC.ITEM_VISIBLE in self.data:
            visible = gcv(self.data.get(SC.ITEM_VISIBLE))

        return visible


class SCStreamSelect(SCBaseItem):
    def __init__(self, data):
        SCBaseItem.__init__(self, data)
        label2 = ''
        strm_nfo = data.get('stream_info', {})
        titulky = True if [x for x in strm_nfo.get('langs', "") if '+tit' in x] else False

        if 'bitrate' in data:
            label2 += 'bitrate: [B]{}[/B]'.format(convert_bitrate(int(data.get('bitrate'))))
        if 'linfo' in data:
            label2 += '   audio: [B][UPPERCASE]{}[/UPPERCASE][/B]'.format(', '.join(data['linfo']))
            if titulky:
                label2 += ', [B]+tit[/B]'

        if 'grp' in strm_nfo:
            label2 += '   grp: [B]{}[/B]'.format(strm_nfo['grp'])

        if 'src' in strm_nfo:
            label2 += '   src: [B]{}[/B]'.format(strm_nfo['src'])

        if 'video' in strm_nfo and 'aspect' in strm_nfo['video'] and 'ratio' in strm_nfo['video']:
            label2 += '   asp: [B]{}[/B]'.format(strm_nfo['video']['ratio'])

        if SC.ITEM_URL in data:
            url = data.get(SC.ITEM_URL)
            self.item.setPath(url)
        if SC.ITEM_PROVIDER in data:
            self.item.setProperty(SC.ITEM_PROVIDER, data.get(SC.ITEM_PROVIDER))
        if SC.ITEM_SUBS in data:
            self.item.setProperty(SC.ITEM_SUBS, data.get(SC.ITEM_SUBS))
        if SC.ITEM_ID in data:
            # Fix #6: Use SC.ITEM_ID constant consistently
            self.item.setProperty(SC.ITEM_ID, data.get(SC.ITEM_ID))
        self.item.setLabel2(label2)


class SCLDir(SCBaseItem):
    def __init__(self, data):
        SCBaseItem.__init__(self, data)
        if SC.ITEM_URL in data:
            url = self.translate_path(data[SC.ITEM_URL])
            self.item.setPath(url)

    def translate_path(self, path):
        import re
        found = re.search(r'sc://(?P<typ>[^\(]+)\((?P<param1>[^\s,\)]+)\)', path)
        if found and found.group('typ') == 'config':
            path = make_legal_filename(translate_path(get_setting(found.group('param1'))))
        return path


class SCDir(SCBaseItem):
    build_ctx = True

    def __init__(self, data):
        SCBaseItem.__init__(self, data)
        self.lib = List(SC.ITEM_LIBRARY)
        item_id = self.data.get(SC.ITEM_ID)
        if item_id and item_id in self.lib.get():
            label = "[COLOR red]*[/COLOR] {0}".format(self.item.getLabel())
            self.item.setLabel(label)

        if SC.ITEM_URL in data:
            url = create_plugin_url(data)
            self.item.setPath(url)
        if self.build_ctx:
            self.make_ctx()

    def make_ctx(self):
        context_menu = []

        if 'listType' in params.args:
            context_menu.append([Strings.txt(Strings.CONTEXT_REMOVE), 'RunPlugin({})'.format(create_plugin_url({
                SC.ACTION: SC.ACTION_REMOVE_FROM_LIST,
                SC.ITEM_ID: self.data.get(SC.ITEM_ID),
                SC.ITEM_PAGE: get_history_item_name(self.data.get('lid'))
            }))])

        # Fix #5: Remove dead code (was disabled with 'if 0')
        # Fix #1: Use proper SC.ITEM_ID instead of URL as ID

        if params.args.get('url'):
            # Fix: Use consistent ID for pinning (use actual item ID, not URL)
            context_menu.append((Strings.txt(Strings.CONTEXT_PIN_UNPIN), 'RunPlugin({})'.format(create_plugin_url({
                SC.ITEM_ACTION: SC.ACTION_PIN,
                SC.ITEM_URL: self.data.get(SC.ITEM_URL),
                SC.ITEM_ID: self.data.get(SC.ITEM_ID)
            }))))

            if get_system_platform() == 'android':
                context_menu.append(
                    (Strings.txt(Strings.CONTEXT_ADD_TO_ANDROID_TV), 'RunPlugin({})'.format(create_plugin_url({
                        SC.ITEM_ACTION: SC.ACTION_ANDROID,
                        SC.ITEM_URL: self.data.get(SC.ITEM_URL),
                        SC.ITEM_ID: self.data.get(SC.ITEM_ID),
                        SC.ITEM_TITLE: self.item.getLabel()
                    }))))

            context_menu.append((Strings.txt(Strings.CONTEXT_PIN_TO_HP), 'RunPlugin({})'.format(create_plugin_url({
                SC.ITEM_ACTION: SC.ACTION_ADD2HP,
                SC.ITEM_URL: self.data.get(SC.ITEM_URL),
                SC.ITEM_ID: self.data.get(SC.ITEM_ID),
                SC.ITEM_TITLE: self.item.getLabel()
            }))))

        if get_setting_as_bool('stream.autoselect'):
            # debug('data: {}'.format(self.data))
            mediatype = self.data.get(SC.ITEM_INFO, {}).get('mediatype')
            if mediatype == 'tvshow' or mediatype == 'movie':
                item_id = self.data.get(SC.ITEM_ID)
                st = preferred_lang_list
                if st.get(item_id) is not None:
                    context_menu.append((Strings.txt(Strings.CONTEXT_DEL_PREF_LANG).format(st[item_id]),
                                         'RunPlugin({})'.format(create_plugin_url({
                                             SC.ITEM_ACTION: SC.ACTION_DEL_PREFERRED_LANGUAGE,
                                             SC.ITEM_ID: self.data.get(SC.ITEM_ID)
                                         }))))
                else:
                    context_menu.append(
                        (Strings.txt(Strings.CONTEXT_ADD_PREF_LANG), 'RunPlugin({})'.format(create_plugin_url({
                            SC.ITEM_ACTION: SC.ACTION_SET_PREFERRED_LANGUAGE,
                            SC.ITEM_ID: self.data.get(SC.ITEM_ID)
                        }))))

        if context_menu:
            self.item.addContextMenuItems(context_menu)


class SCHPDir(SCDir):
    def __init__(self, data):
        SCDir.__init__(self, data)

    def make_ctx(self):
        context_menu = [(Strings.txt(Strings.CONTEXT_REMOVE), 'RunPlugin({})'.format(create_plugin_url({
            SC.ITEM_ACTION: SC.ACTION_DEL2HP,
            SC.ITEM_URL: self.data.get(SC.ITEM_URL),
            SC.ITEM_ID: self.item.getLabel()
        })))]

        self.item.addContextMenuItems(context_menu)


class SCCustomFilterDir(SCDir):
    def __init__(self, data):
        SCDir.__init__(self, data)

    def make_ctx(self):
        context_menu = [('Remove custom item', 'RunPlugin({})'.format(create_plugin_url({
            SC.ITEM_ACTION: SC.ACTION_DEL_CUSTOM_FILTER,
            SC.ITEM_URL: self.data.get(SC.ITEM_URL),
            SC.ITEM_TITLE: self.item.getLabel(),
            SC.ITEM_PAGE: self.data.get('self_url')
        })))]

        self.item.addContextMenuItems(context_menu)


class SCNext(SCDir):
    def __init__(self, data):
        self.build_ctx = False
        SCDir.__init__(self, data)
        self.item.setProperty('SpecialSort', GUI.BOTTOM)


class SCNFO(SCBaseItem):
    ITEMS_XML = [
        'title',
        'originaltitle',
        'sorttitle',
        'plot',
        'runtime',
        'mpaa',
        'genre',
        'country',
        'director',
        'year',
        'studio',
        'trailer',
        'dateadded',
    ]

    XML_ITEM = '\n<{0}>{1}</{0}>'
    XML_ACTOR = '<actor><name>{name:}</name><role>{role:}</role><order>{order:}</order><thumb>{thumbnail:}</thumb></actor>'
    XML_THUMB = '<thumb aspect="{0}">{1}</thumb>'
    XML_MOVIE = '<movie>{}</movie>'
    DEFAULT_ACTOR = {'name': '', 'role': '', 'order': '', 'thumbnail': ''}

    def __init__(self, data):
        SCBaseItem.__init__(self, data)

    def xml(self):
        out = []

        for pos, item in enumerate(self.info):
            if item in self.ITEMS_XML:
                if isinstance(self.info[item], list):
                    out.append(self.XML_ITEM.format(decode(item), ' / '.join(self.info[item])))
                else:
                    out.append(self.XML_ITEM.format(decode(item), decode(self.info[item])))

        for actor in self.data.get('cast', {}):
            d = self.DEFAULT_ACTOR.copy()
            d.update(actor)
            out.append(self.XML_ACTOR.format(**d))

        i18n = self.data.get(SC.ITEM_I18N_ART)
        if i18n:  # Check if i18n exists
            lang = SYSTEM_LANG_CODE
            if lang not in i18n:
                lang = SC.DEFAULT_LANG

            art = i18n.get(lang)
            if art:  # Check if art exists
                for pos, item in enumerate(art):
                    out.append(self.XML_THUMB.format(item, art[item]))

        return decode(self.XML_MOVIE.format(''.join(out)))

    def nfo(self):
        typ = self.data.get(SC.ITEM_INFO, {}).get('mediatype', 'movie')
        typ = typ if typ == 'movie' else 'tvshow'
        return make_nfo_content(self.data, typ)


class SCVideo(SCBaseItem):
    def __init__(self, data):
        trakt = data['unique_ids']['trakt'] if 'unique_ids' in data and 'trakt' in data['unique_ids'] else None
        self.movie = SCKODIItem(data.get(SC.ITEM_ID), series=data.get('info', {}).get('season'),
                                episode=data.get('info', {}).get('episode'), trakt=trakt)
        internal_info = {}
        play_count = self.movie.get_play_count()
        if play_count is not None and int(play_count) > 0:
            internal_info.update({'playcount': play_count})
        last_played = self.movie.get_last_played()
        if last_played:
            internal_info.update({'lastplayed': last_played})
        if internal_info != {}:
            # debug('update info: {}'.format(internal_info))
            data.get(SC.ITEM_INFO).update(internal_info)

        SCBaseItem.__init__(self, data)
        self.set_properties()
        self.gen_context()

    def get(self):
        if self.info_set is False:
            self._set_info({SC.MEDIA_TYPE: SC.MEDIA_TYPE_VIDEO})
        return self.item.getPath(), self.item, False, None

    def set_properties(self):
        self.item.setContentLookup(False)
        self.item.setProperty('IsPlayable', 'true')
        item_info = self.data.get(SC.ITEM_INFO, {})
        if 'duration' in item_info:
            duration = item_info.get('duration')
            resume_time = self.movie.get(self._key('watched'))
            # Ensure duration is a valid positive number to prevent division by zero
            try:
                duration = float(duration) if duration is not None else 0
            except (ValueError, TypeError):
                duration = 0
                
            if resume_time and duration > 0 and 0 < resume_time < duration:
                try:
                    info_tag = self.item.getVideoInfoTag()
                    info_tag.setResumePoint(float(resume_time), float(duration))
                except Exception as e:
                    debug('Error setting resume point: {}'.format(str(e)))

    def gen_context(self):
        menu = []

        if 'listType' in params.args:
            menu.append([Strings.txt(Strings.CONTEXT_REMOVE), 'RunPlugin({})'.format(create_plugin_url({
                SC.ACTION: SC.ACTION_REMOVE_FROM_LIST,
                SC.ITEM_ID: self.data.get(SC.ITEM_ID),
                SC.ITEM_PAGE: get_history_item_name(self.data.get('lid'))
            }))])

        if get_setting('download.path'):
            menu.append([Strings.txt(Strings.CONTEXT_DOWNLOAD), 'RunPlugin({})'.format(create_plugin_url({
                SC.ACTION: SC.ACTION_DOWNLOAD,
                SC.ACTION_DOWNLOAD: self.data.get(SC.ITEM_URL),
            }))])

        menu.append([Strings.txt(Strings.CONTEXT_SELECT_STREAM), 'PlayMedia({})'.format(create_plugin_url({
            SC.ACTION_SELECT_STREAM: '1',
            SC.ITEM_URL: self.data.get(SC.ITEM_URL),
        }))])

        if get_setting_as_bool('stream.autoselect'):
            mediatype = self.data.get(SC.ITEM_INFO, {}).get('mediatype')
            if mediatype == 'tvshow' or mediatype == 'movie':
                item_id = self.data.get(SC.ITEM_ID)
                st = preferred_lang_list
                if st.get(item_id) is not None:
                    menu.append((Strings.txt(Strings.CONTEXT_DEL_PREF_LANG).format(st[item_id]),
                                 'RunPlugin({})'.format(create_plugin_url({
                                     SC.ITEM_ACTION: SC.ACTION_DEL_PREFERRED_LANGUAGE,
                                     SC.ITEM_ID: self.data.get(SC.ITEM_ID)
                                 }))))
                else:
                    menu.append((Strings.txt(Strings.CONTEXT_ADD_PREF_LANG), 'RunPlugin({})'.format(create_plugin_url({
                        SC.ITEM_ACTION: SC.ACTION_SET_PREFERRED_LANGUAGE,
                        SC.ITEM_ID: self.data.get(SC.ITEM_ID)
                    }))))

        if self.data.get(SC.ITEM_INFO, {}).get('trailer'):
            menu.append(['Trailer', 'PlayMedia({})'.format(self.data.get(SC.ITEM_INFO, {}).get('trailer'))])

        self.item.addContextMenuItems(items=menu)

    def _key(self, name):
        nfo = self.data.get(SC.ITEM_INFO)
        if 'season' in nfo:
            return '{}:{}:{}'.format(name, nfo.get('season'), nfo.get('episode'))
        return name


class SCCmd(SCBaseItem):
    def __init__(self, data):
        data.update({SC.ACTION: SC.CMD})
        SCBaseItem.__init__(self, data)


class SCAction(SCBaseItem):
    def __init__(self, data):
        SCBaseItem.__init__(self, data)
        self.item.setPath(create_plugin_url(data))


class SCPlayItem(SCBaseItem):
    QUALITY_LIST = {
        'SD': 1,
        '720p': 2,
        '1080p': 3,
        '3D-SBS': 3,
        '4K': 4,
        '8K': 5
    }

    def __init__(self, data, resolve=True):
        self.input = data
        self.streams = []
        self.selected = None
        self.params = params.args
        self.hls = '#EXTM3U\n'
        self.resolved_successfully = False
        item_info = self.input.get(SC.ITEM_INFO)
        item_info.update({'play': True})

        SCBaseItem.__init__(self, item_info, debug=True)
        if resolve:
            try:
                result = self.resolve()
                self.resolved_successfully = result is not None and result is not False
            except Exception as e:
                debug('Resolution failed with exception: {}'.format(str(e)))
                self.resolved_successfully = False

    @try_catch('get')
    def get(self):
        """
        Get playback information for the resolved stream.
        
        This method now returns data compatible with the new unified player system.
        The actual playback is handled by the StreamCinemaPlayer class.
        
        Returns:
            tuple: (url, listitem, success, selected_stream_info)
        """
        # If resolution failed, return None values to indicate failure
        if not self.resolved_successfully:
            debug('SCPlayItem.get() - resolution failed, returning None values')
            return None, None, False, None
        
        # Return the resolved URL and ListItem for the new player system
        return self.item.getPath(), self.item, True, self.selected

    @try_catch('build_hls')
    def build_hls(self):
        kr = Kraska()
        # Fix: Use list for efficient string building instead of +=
        hls_parts = ['#EXTM3U']
        
        # Fix: Generate unique filename to avoid concurrent write conflicts
        import os
        import tempfile
        temp_name = 'input_{}.m3u8'.format(os.getpid())
        
        for pos, s in enumerate(self.streams):
            # Fix #2: Use SC.ITEM_IDENT constant instead of 'xxx'
            ident = s.get(SC.ITEM_IDENT)
            if not ident:
                debug('Warning: Stream missing identifier, skipping: {}'.format(s))
                continue
            debug('STREAM: {} => {}'.format(ident, s))
            url = kr.resolve(ident)
            sinfo = s.get('stream_info', {}).get('video', {})
            hls_parts.append('#EXT-X-STREAM-INF:BANDWIDTH={},RESOLUTION={}x{}'.format(
                s.get('bitrate', 0),
                sinfo.get('width', 0),
                sinfo.get('height', 0)
            ))
            hls_parts.append(url)
        
        self.hls = '\n'.join(hls_parts) + '\n'
        debug('HLS: {}'.format(self.hls))
        
        # Store filename for later cleanup
        self.hls_filename = make_legal_filename('special://profile/{}'.format(temp_name))
        with xbmcvfs.File(self.hls_filename, 'w') as fs:
            fs.write(self.hls)
        
        # Clean up old HLS files (older than 1 hour)
        self._cleanup_old_hls_files()

    def _cleanup_old_hls_files(self):
        """Clean up old temporary HLS playlist files"""
        try:
            import os
            profile_path = translate_path('special://profile/')
            current_time = time.time()
            
            # List all files in profile directory
            for filename in os.listdir(profile_path):
                if filename.startswith('input_') and filename.endswith('.m3u8'):
                    filepath = os.path.join(profile_path, filename)
                    try:
                        # Remove files older than 1 hour
                        if current_time - os.path.getmtime(filepath) > 3600:
                            xbmcvfs.delete(filepath)
                            debug('Cleaned up old HLS file: {}'.format(filename))
                    except Exception as e:
                        debug('Failed to clean up {}: {}'.format(filename, str(e)))
        except Exception as e:
            debug('HLS cleanup failed: {}'.format(str(e)))

    @try_catch('speedtest')
    def speedtest(self, isp, ident='15VFNFJrCKHn'):
        from resources.lib.common.threading_utils import run_concurrent, ThreadSafeOperation
        
        kr = Kraska()
        url = kr.resolve(ident)
        smin = 999999999
        smax = 0
        durmin = 999999999
        hosts = ['b01', 's01', 'v01', 't01']
        
        def test_host(host):
            """Test speed for a single host"""
            try:
                u = re.sub(r':\/\/([^.]+)', '://{}'.format(host), url)
                debug('speedtest URL {}'.format(u))
                s, dur = self.calculate_speed(u)
                debug('speedtest host {} speed: {}'.format(host, convert_bitrate(s)))
                return host, s, dur
            except Exception as e:
                debug('StreamSpeedWorker error for host {}: {}'.format(host, str(e)))
                return host, 0, 0
        
        # Create tasks for concurrent execution
        tasks = [lambda h=host: test_host(h) for host in hosts]
        
        # Run speed tests concurrently with proper timeout and error handling
        with ThreadSafeOperation("Speed Test", timeout=30.0):
            results = run_concurrent(tasks, max_workers=4, timeout=25.0)
            
            # Process results
            for result in results:
                if result is not None:
                    h, s, dur = result
                    if s > 0:  # Valid speed result
                        smin = min(s, smin)
                        smax = max(s, smax)
                        durmin = min(dur, durmin)
                        isp.update({h: s})
                        
                        # Early exit if we find a very fast host (>50 Mbps)
                        if s > 50 * 1000000:  # 50 Mbps
                            debug('Found fast host {}, using early exit optimization'.format(h))
                            break
        
        debug('min/max {}/{}'.format(convert_bitrate(smin), convert_bitrate(smax)))
        debug('res: {}'.format(isp))
        try:
            st = Sc.post('/Stats/speedtest', json=isp)
            debug('Speed stats: {}'.format(st))
        except:
            pass
        speed = smin
        settings.set_setting('stream.adv.speedtest', speed)
        settings.set_setting('stream.adv.speedtest.asn', isp.get('a', 'N/A'))
        settings.set_setting('stream.adv.speedtest.last', int(time.time()))
        return (smin, smax, durmin)

    @try_catch('calculate_speed')
    def calculate_speed(self, url):
        from resources.lib.system import Http
        # Fix #3: Use context manager to ensure response is properly closed
        try:
            with Http.get(url, stream=True) as r:
                # Optimize chunk size and limit test duration for speed
                chunk = 8 * 1024 * 1024  # Larger 8MB chunks for better throughput measurement
                # Fix #4: Use consistent time units (seconds throughout)
                max_test_duration = 10  # 10 seconds max test duration
                start = microtime()
                bytes_downloaded = 0
                
                for data in r.iter_content(chunk):
                    bytes_downloaded += len(data)
                    current_time = microtime()
                    elapsed_seconds = (current_time - start) / 1000.0
                    
                    # Early exit if we have enough data or test is taking too long
                    if elapsed_seconds > max_test_duration or bytes_downloaded > (50 * 1024 * 1024):  # 50MB max
                        break
                        
                end = microtime()
                dur = (end - start) / 1000.0  # Duration in seconds
                speed = int(bytes_downloaded / dur * 8) if dur > 0 else 0
                return (speed, dur)  # bps, seconds
        except Exception as e:
            debug('Error in calculate_speed: {}'.format(str(e)))
            # Return zero speed on error
            return (0, 0)

    @try_catch('ISP')
    def isp(self):
        return get_isp()

    @try_catch('filter')
    def filter(self):
        # Check if we have any streams to filter
        if not self.streams:
            debug('No streams available to filter')
            return
            
        speedtest_last = get_setting_as_int('stream.adv.speedtest.last')
        now = time.time()
        force = True if speedtest_last is None or (speedtest_last + (24 * 3600 * 2)) < now else False

        isp = self.isp()
        asn = settings.get_setting('stream.adv.speedtest.asn')
        
        # Fix: Handle None ISP data gracefully
        if isp is not None:
            asn_changed = str(isp.get('a')) != str(asn)
            isp_asn = isp.get('a')
        else:
            asn_changed = False
            isp_asn = 'N/A'
            debug('ISP detection disabled, skipping ASN comparison')
        
        wrong_speed = settings.get_setting_as_int('stream.adv.speedtest') < 1
        debug('Force: {} ASN: {} / {} [{}] / SPEED: {} [{}]'.format(force, asn, isp_asn, asn_changed,
                                                                    settings.get_setting_as_int('stream.adv.speedtest'),
                                                                    wrong_speed))
        
        # Only run speedtest if ISP data is available and conditions are met
        if isp is not None and (force is True or (get_setting_as_int('stream.max.bitrate') == 100 and (asn_changed or wrong_speed))):
            smin, smax, dur = self.speedtest(isp)
            debug('smin {} / smax {} / dur {}'.format(smin, smax, dur))

        # @todo autoselect / filtrovanie nechcenych streamov
        if not get_setting_as_bool('stream.autoselect') \
                or SC.ACTION_SELECT_STREAM in self.params or SC.ACTION_DOWNLOAD in self.params:
            debug('nieje autoselect, alebo je vynuteny vyber streamu alebo download')
            return

        if get_setting_as_bool('stream.autoselect'):
            # Safety check for empty streams
            if not self.streams:
                debug('No streams available for autoselect')
                return

            lang1 = get_setting('stream.lang1').lower()
            lang2 = get_setting('stream.lang2').lower()
            if Sc.parental_control_is_active():
                lang1 = get_setting('parental.control.lang1').lower()
                lang2 = get_setting('parental.control.lang2').lower()

            score = {pos: 0 for pos, s in enumerate(self.streams)}
            for pos, s in enumerate(self.streams):
                debug('-----------------------------------------------------------------------------------------------')
                debug('stream: bitrate: {} quality: {} lang: {}'.format(s.get('bitrate', 0), s.get('quality', 'N/A'),
                                                                        s.get('linfo', 'N/A')))
                self.video_score(score, pos, s)

                stream_info = s.get('stream_info', {})
                linfo = s.get('linfo', [])
                if lang1 in linfo:
                    score = self.audio_score(lang1, pos, score, stream_info, 3)
                elif lang2 in linfo:
                    score = self.audio_score(lang2, pos, score, stream_info, 1)
                else:
                    debug('Nemame primarny, ani sekundarny jazyk')

                debug('-----------------------------------------------------------------------------------------------')
                debug('final score: {}'.format(score[pos]))

            # Always sort and select - remove the conditional that could leave self.selected as None
            score = {k: v for k, v in sorted(score.items(), key=lambda item: item[1], reverse=True)}
            score_keys = list(score.keys())
            if not score_keys:
                debug('No streams scored, cannot autoselect')
                return
            sel = score_keys[0]
            debug('score: {} / {}'.format(score, sel))
            self.selected = self.streams[sel]
            self.streams = [self.selected]
            return

        debug('autoselect nic nevybral, tak nechame usera vybrat')

    def video_score(self, score, pos, s):
        megabit = 1e6
        speed = settings.get_setting_as_int('stream.adv.speedtest')
        if speed > 0:
            debug('set max_bitrate from speedtest: {}Mbps'.format(int(speed * 0.8 / megabit)))
            max_bitrate = int(speed * 0.8)
        else:
            max_bitrate = get_setting_as_int('stream.max.bitrate') * megabit
        debug('video max_bitrate: {}'.format(max_bitrate))

        quality = s.get('quality', 'SD')
        max_quality = get_setting('stream.max.quality')
        
        debug('qualita {} vs {} | {} >= {}'.format(quality, max_quality, 
               self.QUALITY_LIST.get(max_quality, 'N/A'), self.QUALITY_LIST.get(quality, 'N/A')))
        if quality in self.QUALITY_LIST:
            if max_quality == '-':
                score[pos] += self.QUALITY_LIST[quality]
                debug('quality point 1: {} / {}'.format(self.QUALITY_LIST[quality], score[pos]))
            elif max_quality in self.QUALITY_LIST and self.QUALITY_LIST[max_quality] >= self.QUALITY_LIST[quality]:
                w = self.QUALITY_LIST[max_quality] - (self.QUALITY_LIST[max_quality] - self.QUALITY_LIST[quality] - 1)
                score[pos] += w
                debug('quality point 2: {} / {}'.format(w, score[pos]))
            else:
                debug('nehodnotime rozlisenie 1')
        else:
            debug('nehodnotime rozlisenie 2')

        bitrate = int(s.get('bitrate', 0))
        if max_bitrate >= 100 * megabit:
            score[pos] += 1
            debug('vsetky bitrate su dobre, bitrate {} / {}'.format(bitrate, score[pos]))
        elif bitrate < max_bitrate:
            score[pos] += 1
            debug('nizsi bitrate {} < {} / {}'.format(bitrate, max_bitrate, score[pos]))
        else:
            score[pos] -= 10
            debug('prilis velky bitrate {} > {} / {}'.format(bitrate, max_bitrate, score[pos]))

        stream_info = s.get('stream_info', {})
        video = stream_info.get('video', {})
        vcodec = video.get('codec')

        if get_setting_as_bool('stream.adv'):
            # Fix #8: Parse codec lists properly
            blacklist_codecs = set(codec.strip() for codec in get_setting('stream.adv.blacklist.codec').split(',') if codec.strip())
            whitelist_codecs = set(codec.strip() for codec in get_setting('stream.adv.whitelist.codec').split(',') if codec.strip())
            
            if vcodec in blacklist_codecs:
                score[pos] -= 10
                debug('blacklist codec {} / {}'.format(vcodec, score[pos]))

            if vcodec in whitelist_codecs:
                score[pos] += 1
                debug('whitelist codec {} / {}'.format(vcodec, score[pos]))

            if get_setting_as_bool('stream.adv.exclude.3d') and '3D' in quality:
                score[pos] -= 10
                debug('penalize 3D content {}'.format(score[pos]))

            if get_setting_as_bool('stream.adv.exclude.hdr') and stream_info.get('HDR'):
                score[pos] -= 10
                debug('penalize HDR content {}'.format(score[pos]))

            if get_setting_as_bool('stream.adv.prefer.hdr') and stream_info.get('HDR'):
                score[pos] += 1
                debug('prefer HDR {}'.format(score[pos]))

        return score

    def audio_score(self, lang1, pos, score, stream_info, weight=3):
        if get_setting_as_bool('stream.adv') and 'streams' in stream_info:
            # Fix: Use SC.ITEM_ID constant consistently
            force_lang = preferred_lang_list.get(self.data.get(SC.ITEM_ID))
            # Fix: Create a copy of score to avoid mutating during iteration
            ascore = {}
            for apos, stream_data in enumerate(stream_info['streams']):
                ascore[apos] = 0
                acodec, channels, lang = stream_data
                lang = lang.lower()

                if force_lang is not None and force_lang.lower() == lang:
                    ascore[apos] += 1000
                    debug('FORCE lang: {}'.format(force_lang.lower()))

                debug(' - lang {}/{}'.format(lang, lang1))
                # Fix #8: Parse codec lists properly
                whitelist_codecs = set(codec.strip() for codec in get_setting('stream.adv.whitelist.codec').split(',') if codec.strip())
                blacklist_codecs = set(codec.strip() for codec in get_setting('stream.adv.blacklist.codec').split(',') if codec.strip())
                
                if acodec in whitelist_codecs:
                    debug(' - audio whitelist acodec {}'.format(acodec))
                    ascore[apos] += 1

                if acodec in blacklist_codecs:
                    debug(' - audio blacklist acodec {}'.format(acodec))
                    ascore[apos] -= 10

                if lang == lang1:
                    if get_setting_as_bool('stream.adv.audio.channels'):
                        # Fix: Correct channel weighting logic (5.1, 7.1 should get bonus)
                        if channels > 3:
                            weight = weight + (channels - 3)
                    debug(' - audio adv prefered lang {} => {}'.format(lang1, weight))
                    ascore[apos] += weight
            ascore = {k: v for k, v in sorted(ascore.items(), key=lambda item: item[1], reverse=True)}
            ascore_keys = list(ascore.keys())
            if ascore_keys:
                sel = ascore_keys[0]
                score[pos] += ascore[sel]
                debug('audio score: {} -> {} / {}'.format(ascore, sel, score[pos]))
            else:
                debug('No audio streams scored')
        else:
            score[pos] += weight
            debug('audio basic prefered lang {} => {} / {}'.format(lang1, weight, score[pos]))

        return score

    def resolve(self):
        data = self.data
        data.pop(SC.ITEM_URL, None)  # Safe removal - won't crash if key doesn't exist
        self.streams = self.input.get(SC.ITEM_STRMS)
        
        # Check if we have any streams to work with
        if not self.streams:
            debug('No streams available in input data')
            return None
            
        self.filter()

        items = []
        matrix = []
        for s in self.streams:
            debug('ideme vytvorit listItems zo streamov')
            s.update(data)
            itm = SCStreamSelect(s)
            x = itm.get()
            title_items = [
                '[B]{}[/B] - '.format(s.get(SC.ITEM_LANG)),
                '[B]{}[/B] '.format(s.get(SC.ITEM_QUALITY)),
                '{} '.format(s.get(SC.ITEM_SIZE)),
                '{}{}'.format(s.get(SC.ITEM_VIDEO_INFO), s.get(SC.ITEM_AUDIO_INFO)),
            ]
            matrix.append(title_items)
            items.append(x[1])
        # matrix = make_table(matrix)
        # info('matrix: {}'.format(matrix))
        for i, itm in enumerate(items):
            itm.setProperty('old_title', itm.getLabel())
            itm.setLabel(' '.join(matrix[i]))

        if len(items) > 1 or SC.ACTION_SELECT_STREAM in self.params or SC.ACTION_DOWNLOAD in self.params:
            if not items:
                debug('No items available for selection')
                return None
            from resources.lib.common.threading_utils import safe_dialog_select
            pos = safe_dialog_select(items, heading=items[0].getProperty('old_title'), use_details=True)
            # info('post: {} | {}'.format(pos, json.dumps(self.data)))
            # Fix #9: Handle all cancel values properly (None, -1, False)
            if pos is None or pos < 0 or pos is False:
                # User cancelled selection - return gracefully without crashing
                debug('Stream selection cancelled by user')
                return None
            res = items[pos]
            self.selected = self.streams[pos]
        elif len(items) == 1:
            res = items[0]
            # Safety check: ensure self.streams is not empty before accessing [0]
            if self.streams and self.selected is None:
                self.selected = self.streams[0]
            elif not self.streams:
                debug('Warning: self.streams is empty but items has 1 element - data inconsistency')
                return None
        else:
            debug('No streams available for selection')
            return None

        url = res.getPath()
        # info('vybrany stream: {} / {}'.format(res.getPath(), self.selected))
        if res.getProperty(SC.ITEM_PROVIDER) == SC.PROVIDER:
            resp = Sc.get(res.getPath())
            kr = Kraska()
            try:
                ident = resp.get(SC.ITEM_IDENT)
                debug('ideme resolvovat ident {} na kra.sk'.format(ident))
                url = kr.resolve(ident)
            except ResolveException as e:
                debug('ResolveException: {}'.format(str(e)))
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.RESOLVE_ERROR_H1), Strings.txt(Strings.RESOLVE_ERROR_L1))
                return None
            except Exception as e:
                debug('Resolve error: {}'.format(str(e)))
                # Show user-friendly error for unexpected resolve errors
                from resources.lib.common.threading_utils import safe_dialog_ok
                safe_dialog_ok(Strings.txt(Strings.RESOLVE_ERROR_H1), 
                    'Stream resolution failed: {}'.format(str(e)))
                return None
            if res.getProperty(SC.ITEM_SUBS):
                debug('subor ma titulky, tak ich natahujem')
                part = res.getProperty(SC.ITEM_SUBS).split('/file/')
                self.item.setSubtitles([kr.resolve(part[1])])
            else:
                info('nemame titulky')

        info('resolve: {}'.format(url))
        if 'lid' in data:
            lid = 'p-{}'.format(data.get('lid')) if parental_history() else data.get('lid')
            st = List(lid, max_items=20)
            st.add(res.getProperty(SC.ITEM_ID))
        self.item.setPath(url)
        self.item.setLabel(res.getProperty('original_title'))
        # home_win.setProperty('SC-lite-item', '{}'.format(res.getProperty(SC.ITEM_ID)))
        home_win.setProperty(SC.SELECTED_ITEM, '{}'.format(dumps(self.selected)))

        # Fix: Safe access to nested data to prevent AttributeError
        item_info = self.input.get(SC.ITEM_INFO, {})
        if 'unique_ids' in item_info:
            unique_ids = item_info.get('unique_ids')
            home_win.setProperty('script.trakt.ids', '{}'.format(dumps(unique_ids)))
            home_win.setProperty('{}.ids'.format(ADDON_ID), '{}'.format(dumps(unique_ids)))
        
        # Return success to indicate resolution completed successfully
        return True


class SCUpNext:
    def __init__(self, data):
        self.data = data
        self.out = {}
        self.play_item = SCPlayItem(data, resolve=False)
        self.build()

    def build_cur(self):
        tvshowid = self.data.get('info', {}).get('id')
        return dict(
            episodeid='{}-{}-{}'.format(tvshowid, get_info_label('VideoPlayer.Season'), get_info_label('VideoPlayer'
                                                                                                       '.Episode')),
            tvshowid=tvshowid,
            title=get_info_label('Player.Title'),
            art={
                'tvshow.fanart': get_info_label('ListItem.Art(tvshow.fanart)'),
                'tvshow.poster': get_info_label('ListItem.Art(tvshow.poster)'),
            },
            season=get_info_label('VideoPlayer.Season'),
            episode=get_info_label('VideoPlayer.Episode'),
            showtitle=get_info_label('VideoPlayer.TVShowTitle'),
            plot=get_info_label('VideoPlayer.Plot'),
            playcount=0,
            rating=0,
            firstaired='',
        )

    def build(self):
        item = self.play_item.item
        tvshowid = self.data.get('info', {}).get('id')
        next_episode = dict(
            episodeid='{}-{}-{}'.format(tvshowid, item.getProperty('season'), item.getProperty('episode')),
            tvshowid=tvshowid,
            title=item.getLabel(),
            art={
                'thumb': item.getArt('thumb'),
                'tvshow.clearart': item.getArt('clearart'),
                'tvshow.clearlogo': item.getArt('clearlogo'),
                'tvshow.fanart': item.getArt('fanart'),
                'tvshow.poster': item.getArt('poster'),
            },
            season=item.getProperty('season'),
            episode=item.getProperty('episode'),
            showtitle=item.getProperty('showtitle'),
            plot=item.getProperty('plot'),
            playcount=0,
            rating=0,
            firstaired='',
            # runtime=''
        )
        play_info = {
            SC.ITEM_URL: '{}'.format(self.data.get('info', {}).get(SC.ITEM_URL))
        }
        # Check if auto-play is enabled in settings
        auto_play = settings.get_setting_as_bool('upnext_auto_play')
        
        self.out = dict(
            current_episode=self.build_cur(),
            next_episode=next_episode,
            # play_url=item.getPath()
            play_info=play_info,
            auto_play=auto_play
        )
        selected_item = home_win.getProperty(SC.SELECTED_ITEM)
        debug('selected_item: {}'.format(selected_item))
        if selected_item:
            try:
                selected_item = loads(selected_item)
            except (ValueError, TypeError) as e:
                # Handle invalid JSON or empty string
                debug('Failed to parse selected_item JSON: {} - {}'.format(str(e), selected_item))
                selected_item = None

            debug('CURRENT: {}'.format(selected_item))

            if selected_item:  # Additional safety check after JSON parsing
                notifications = selected_item.get(SC.NOTIFICATIONS, {})
                if SC.SKIP_END_TITLES in notifications and notifications.get(SC.SKIP_END_TITLES) is not None:
                    self.out.update({'notification_offset': notifications.get(SC.SKIP_END_TITLES, None)})
                else:
                    # Use notification time from settings if no specific offset is set
                    notification_time = settings.get_setting_as_int('upnext_notification_time')
                    if notification_time > 0:
                        self.out.update({'notification_offset': notification_time})
        debug('next_info: {}'.format(self.out))
        pass

    def get(self):
        return self.out
