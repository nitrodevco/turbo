# -*- coding: utf-8 -*-
"""
Stream Cinema Download Manager

This module provides proper streaming and download functionality following Kodi best practices.
Uses xbmcplugin.setResolvedUrl for streaming and integrates with Kodi's native download capabilities.

For downloads, this leverages Kodi's built-in context menu "Download" option and proper
ListItem configuration rather than custom HTTP download implementations.

Compatible with all Kodi versions using official Python API methods.
"""

import os
import sys
import traceback
from typing import Optional, Dict, Any, List
from urllib.parse import quote_plus, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.common.logger import debug, info
from resources.lib.kodiutils import get_setting, make_legal_filename
from resources.lib.language import Strings
from resources.lib.common.threading_utils import safe_dialog_ok, safe_notification


class StreamCinemaDownloadManager:
    """
    Modern Kodi-compliant streaming and download manager.
    
    This class handles:
    - Proper streaming via xbmcplugin.setResolvedUrl
    - Download integration through Kodi's native context menus
    - ListItem configuration for optimal playback and download support
    """
    
    def __init__(self):
        """Initialize the download manager."""
        self.addon_name = "Stream Cinema"
    
    def create_playable_listitem(self, url: str, title: str, 
                                custom_headers: Optional[Dict[str, str]] = None,
                                video_info: Optional[Dict[str, Any]] = None,
                                art: Optional[Dict[str, str]] = None,
                                enable_download: bool = True) -> xbmcgui.ListItem:
        """
        Create a properly configured ListItem for streaming/downloading with Kodi optimizations.
        
        Args:
            url: The stream URL
            title: Display title for the item
            custom_headers: Optional HTTP headers for the stream
            video_info: Optional video metadata (duration, plot, etc.)
            art: Optional artwork dictionary (thumb, fanart, etc.)
            enable_download: Whether to add download context menu
            
        Returns:
            xbmcgui.ListItem: Configured ListItem ready for streaming/downloading
        """
        try:
            # LIBREELEC DETECTION: Check for LibreELEC system for optimizations
            is_libreelec = self._is_libreelec_system()
            
            # Create ListItem with proper path
            listitem = xbmcgui.ListItem(label=title)
            
            # KODI OPTIMIZATION: Configure stream URL with headers
            if custom_headers:
                formatted_url = self._format_url_with_headers(url, custom_headers, is_libreelec)
            else:
                formatted_url = url
            
            listitem.setPath(formatted_url)
            
            # STREAMING OPTIMIZATION: Set as playable content
            listitem.setProperty('IsPlayable', 'true')
            
            # LIBREELEC + 1GBIT OPTIMIZATION: Enhanced properties for high-speed streaming
            if is_libreelec:
                # PERFORMANCE: Set 1Gbit-specific properties
                listitem.setProperty('Network.Bandwidth', '1000000000')  # 1Gbit hint
                listitem.setProperty('Network.BufferSize', '16777216')   # 16MB buffer
                listitem.setProperty('Network.Timeout', '10')            # Fast timeout for 1Gbit
                listitem.setProperty('StreamQuality', 'high')            # Prefer high quality
                
                # HARDWARE ACCELERATION: Enable all decoders on LibreELEC
                listitem.setProperty('VideoDecoderHWAccel', 'auto')
                listitem.setProperty('AllowHWAccel', 'true')
                listitem.setProperty('PreferHWDecoding', 'true')
            else:
                # Standard properties for other systems
                listitem.setProperty('Network.Bandwidth', '0')  # Auto-detect
                listitem.setProperty('Network.Timeout', '30')
            
            # KODI OPTIMIZATION: Set video information if provided
            if video_info:
                # Use modern setInfo method with proper video info
                clean_info = self._clean_video_info(video_info)
                listitem.setInfo('video', clean_info)
                
                # PERFORMANCE: Set additional properties based on content type
                if clean_info.get('mediatype') == 'movie':
                    listitem.setProperty('IsMovie', 'true')
                elif clean_info.get('mediatype') == 'episode':
                    listitem.setProperty('IsEpisode', 'true')
                    
                # STREAMING OPTIMIZATION: Handle live content
                if video_info.get('live', False):
                    listitem.setProperty('IsLive', 'true')
                    if is_libreelec:
                        # LIBREELEC LIVE: Reduced buffering for 1Gbit
                        listitem.setProperty('LiveDelay', '2')  # Very low delay
                    else:
                        listitem.setProperty('LiveDelay', '10')
            else:
                # FALLBACK: Set basic video info
                listitem.setInfo('video', {
                    'title': title,
                    'mediatype': 'video',
                    'plot': f"Stream: {title}"
                })
            
            # KODI OPTIMIZATION: Set artwork if provided
            if art:
                listitem.setArt(art)
            
            # ADAPTIVE STREAMING: Configure inputstream.adaptive if needed
            if self._is_adaptive_stream(url):
                listitem.setProperty('inputstream', 'inputstream.adaptive')
                
                # LIBREELEC ADAPTIVE: Enhanced settings for 1Gbit
                if is_libreelec:
                    listitem.setProperty('inputstream.adaptive.max_bandwidth', '100000000')  # 100Mbps
                    listitem.setProperty('inputstream.adaptive.min_bandwidth', '2000000')    # 2Mbps
                    listitem.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive-auto')
                    listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                
                # STREAMING OPTIMIZATION: Detect stream type
                if '.m3u8' in url.lower():
                    listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                elif '.mpd' in url.lower():
                    listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # DOWNLOAD OPTIMIZATION: Add context menu for downloads if enabled
            if enable_download:
                context_menu = []
                
                # KODI OPTIMIZATION: Create download action with proper parameters
                download_params = {
                    'action': 'download',
                    'url': url,
                    'title': title
                }
                
                # PERFORMANCE: Add headers to download parameters if present
                if custom_headers:
                    # Encode headers for URL parameters
                    headers_str = self._encode_headers_for_url(custom_headers)
                    download_params['headers'] = headers_str
                
                download_url = f"plugin://plugin.video.stream-cinema/?{urlencode(download_params)}"
                context_menu.append(('Download', f'RunPlugin({download_url})'))
                
                # LIBREELEC OPTIMIZATION: Add quality selection for 1Gbit users
                if is_libreelec and self._is_adaptive_stream(url):
                    quality_params = download_params.copy()
                    quality_params['action'] = 'select_quality'
                    quality_url = f"plugin://plugin.video.stream-cinema/?{urlencode(quality_params)}"
                    context_menu.append(('Select Quality', f'RunPlugin({quality_url})'))
                
                # STREAMING OPTIMIZATION: Add stream info option
                info_params = {
                    'action': 'info',
                    'url': url,
                    'title': title
                }
                info_url = f"plugin://plugin.video.stream-cinema/?{urlencode(info_params)}"
                context_menu.append(('Stream Info', f'RunPlugin({info_url})'))
                
                listitem.addContextMenuItems(context_menu)
            
            # LARGE FILE OPTIMIZATION: Detect file size and configure streaming accordingly
            estimated_size_gb = self._estimate_file_size_gb(url, custom_headers)
            if estimated_size_gb > 0:
                debug(f"Detected file size: {estimated_size_gb:.1f}GB - configuring large file streaming")
                self._configure_large_file_streaming(listitem, estimated_size_gb, url, video_info)
            else:
                # KODI OPTIMIZATION: Configure advanced properties for better performance
                self._configure_advanced_properties(listitem, url, video_info)
            
            # PERFORMANCE: Set MIME type for better codec detection
            mime_type = self._determine_mime_type(url, video_info)
            if mime_type:
                listitem.setMimeType(mime_type)
            
            # KODI OPTIMIZATION: Enable subtitle support
            listitem.setProperty('SupportsSubtitles', 'true')
            
            debug(f"Created optimized ListItem for: {title} (LibreELEC: {is_libreelec}, Size: {estimated_size_gb:.1f}GB)")
            return listitem
            
        except Exception as e:
            error_msg = f"Failed to create ListItem: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            # FALLBACK: Return basic ListItem
            listitem = xbmcgui.ListItem(label=title)
            listitem.setPath(url)
            listitem.setProperty('IsPlayable', 'true')
            return listitem
    
    def _is_libreelec_system(self) -> bool:
        """
        Detect if running on LibreELEC system.
        
        Returns:
            bool: True if running on LibreELEC
        """
        try:
            if xbmc.getCondVisibility('System.Platform.Linux'):
                system_name = xbmc.getInfoLabel('System.FriendlyName').lower()
                build_version = xbmc.getInfoLabel('System.BuildVersion').lower()
                
                return (
                    'libreelec' in system_name or
                    'libreelec' in build_version or
                    xbmc.getCondVisibility('System.HasAddon(service.libreelec.settings)')
                )
            return False
        except:
            return False
    
    def _get_available_memory_mb(self) -> int:
        """
        Get available system memory in MB.
        
        Returns:
            int: Available memory in MB, or 2048 if detection fails
        """
        try:
            # Use existing memory detection from kodivideocache
            free_mem_str = xbmc.getInfoLabel('System.FreeMemory')
            if 'MB' in free_mem_str:
                # Kodi reports in binary MB (MiB)
                free_mem = int(free_mem_str.replace('MB', '').strip())
                debug(f"Detected available memory: {free_mem} MB")
                return free_mem
            else:
                # Assume bytes, convert to MB
                free_mem = int(free_mem_str) / (1024 * 1024)
                debug(f"Detected available memory: {int(free_mem)} MB")
                return int(free_mem)
        except (ValueError, TypeError):
            debug('Error detecting available memory, defaulting to 2048 MB')
            return 2048  # Default to 2GB if detection fails
    
    def _estimate_file_size_gb(self, url: str, headers: Optional[Dict[str, str]] = None) -> float:
        """
        Estimate file size in GB using HEAD request.
        
        Args:
            url: URL to check
            headers: Optional HTTP headers
            
        Returns:
            float: Estimated file size in GB, or 0 if unknown
        """
        try:
            import urllib.request
            
            # Create request with headers
            req = urllib.request.Request(url, headers=headers or {})
            req.get_method = lambda: 'HEAD'
            
            with urllib.request.urlopen(req, timeout=10) as response:
                content_length = response.headers.get('Content-Length')
                if content_length:
                    size_bytes = int(content_length)
                    size_gb = size_bytes / (1024 * 1024 * 1024)
                    debug(f"Detected file size: {size_gb:.2f} GB")
                    return size_gb
                    
        except Exception as e:
            debug(f"Could not determine file size: {str(e)}")
        
        return 0.0  # Unknown size
    
    def _download_large_file_chunked(self, url: str, local_path: str, 
                                   headers: Optional[Dict[str, str]] = None,
                                   title: str = "Download") -> bool:
        """
        Download large files using chunked approach to prevent memory exhaustion.
        
        Args:
            url: URL to download
            local_path: Local file path to save to
            headers: Optional HTTP headers
            title: Title for progress display
            
        Returns:
            bool: True if download succeeded
        """
        try:
            import urllib.request
            import time
            
            # LARGE FILE OPTIMIZATION: Use larger chunks for better performance
            CHUNK_SIZE = 8 * 1024 * 1024  # 8MB chunks for large files
            PROGRESS_UPDATE_INTERVAL = 2.0  # Update progress every 2 seconds
            
            debug(f"Starting chunked download: {title}")
            
            # Create request with optimized headers
            download_headers = headers.copy() if headers else {}
            
            # PERFORMANCE: Add connection optimization headers
            if 'Connection' not in download_headers:
                download_headers['Connection'] = 'keep-alive'
            if 'Accept-Encoding' not in download_headers:
                download_headers['Accept-Encoding'] = 'gzip, deflate'
            if 'User-Agent' not in download_headers:
                download_headers['User-Agent'] = 'Stream Cinema Kodi Addon (Large File Download)'
            
            req = urllib.request.Request(url, headers=download_headers)
            
            # Show progress dialog
            progress = xbmcgui.DialogProgress()
            progress.create("Downloading Large File", f"Downloading: {title}")
            
            try:
                with urllib.request.urlopen(req, timeout=30) as response:
                    total_size = int(response.headers.get('Content-Length', 0))
                    
                    # MEMORY MANAGEMENT: Check if we have enough space
                    if total_size > 0:
                        size_gb = total_size / (1024 * 1024 * 1024)
                        available_memory = self._get_available_memory_mb()
                        
                        if size_gb > 20 and available_memory < 4096:  # Large file on low-memory system
                            debug(f"Large file ({size_gb:.1f}GB) detected on low-memory system ({available_memory}MB)")
                            # Use smaller chunks to reduce memory pressure
                            CHUNK_SIZE = 2 * 1024 * 1024  # 2MB chunks for low-memory systems
                    
                    downloaded = 0
                    last_progress_update = 0
                    start_time = time.time()
                    
                    with open(local_path, 'wb') as f:
                        while True:
                            # Check if user cancelled
                            if progress.iscanceled():
                                debug("Download cancelled by user")
                                return False
                            
                            # Read chunk
                            chunk = response.read(CHUNK_SIZE)
                            if not chunk:
                                break
                            
                            # Write chunk
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            # Update progress periodically
                            current_time = time.time()
                            if current_time - last_progress_update >= PROGRESS_UPDATE_INTERVAL:
                                last_progress_update = current_time
                                
                                if total_size > 0:
                                    progress_percent = int((downloaded / total_size) * 100)
                                    
                                    # Calculate speed
                                    elapsed = current_time - start_time
                                    if elapsed > 0:
                                        speed_mbps = (downloaded / elapsed) / (1024 * 1024)
                                        eta_seconds = (total_size - downloaded) / (downloaded / elapsed) if downloaded > 0 else 0
                                        eta_minutes = int(eta_seconds / 60)
                                        
                                        progress_line2 = f"Speed: {speed_mbps:.1f} MB/s"
                                        progress_line3 = f"ETA: {eta_minutes} min | {downloaded // (1024*1024)}/{total_size // (1024*1024)} MB"
                                    else:
                                        progress_line2 = f"Downloaded: {downloaded // (1024*1024)} MB"
                                        progress_line3 = f"Total: {total_size // (1024*1024)} MB"
                                    
                                    progress.update(progress_percent, progress_line2, progress_line3)
                                else:
                                    # Unknown total size
                                    progress_line2 = f"Downloaded: {downloaded // (1024*1024)} MB"
                                    progress.update(0, progress_line2, "Size unknown")
                
                progress.close()
                
                if downloaded > 0:
                    elapsed = time.time() - start_time
                    avg_speed = (downloaded / elapsed) / (1024 * 1024) if elapsed > 0 else 0
                    debug(f"Download completed: {downloaded} bytes in {elapsed:.1f}s (avg {avg_speed:.1f} MB/s)")
                    return True
                else:
                    debug("Download failed: no data received")
                    return False
                    
            except Exception as e:
                progress.close()
                error_msg = f"Download failed: {str(e)}"
                debug(error_msg)
                safe_dialog_ok("Download Error", error_msg)
                return False
                
        except Exception as e:
            error_msg = f"Failed to start download: {str(e)}"
            debug(error_msg)
            safe_dialog_ok("Download Error", error_msg)
            return False
    
    def _configure_large_file_streaming(self, listitem: xbmcgui.ListItem, 
                                      file_size_gb: float, url: str,
                                      video_info: Optional[Dict[str, Any]] = None) -> None:
        """
        Configure streaming properties for large files based on available memory and file size.
        
        Args:
            listitem: ListItem to configure
            file_size_gb: Estimated file size in GB
            url: Stream URL for format detection
            video_info: Optional video metadata
        """
        try:
            available_memory_mb = self._get_available_memory_mb()
            is_libreelec = self._is_libreelec_system()
            
            debug(f"Configuring streaming for {file_size_gb:.1f}GB file with {available_memory_mb}MB available memory")
            
            # MEMORY-AWARE CONFIGURATION: Adjust settings based on file size and available memory
            if file_size_gb > 20:  # Large file (>20GB)
                if available_memory_mb < 2048:  # Low memory system (<2GB)
                    # CONSERVATIVE SETTINGS for large files on low-memory devices
                    listitem.setProperty('Network.BufferSize', '33554432')  # 32MB buffer
                    listitem.setProperty('Network.Timeout', '60')  # Longer timeout for large files
                    listitem.setProperty('inputstream.adaptive.max_bandwidth', '25000000')  # 25Mbps limit
                    debug("Applied conservative settings for large file on low-memory system")
                    
                elif available_memory_mb < 4096:  # Medium memory system (2-4GB)
                    # BALANCED SETTINGS
                    listitem.setProperty('Network.BufferSize', '67108864')  # 64MB buffer
                    listitem.setProperty('Network.Timeout', '45')
                    listitem.setProperty('inputstream.adaptive.max_bandwidth', '50000000')  # 50Mbps limit
                    debug("Applied balanced settings for large file on medium-memory system")
                    
                else:  # High memory system (>4GB)
                    # AGGRESSIVE SETTINGS for high-memory devices
                    if is_libreelec:
                        # LIBREELEC + HIGH MEMORY: Maximum performance
                        listitem.setProperty('Network.BufferSize', '268435456')  # 256MB buffer
                        listitem.setProperty('Network.Timeout', '30')
                        listitem.setProperty('inputstream.adaptive.max_bandwidth', '0')  # No limit
                        debug("Applied aggressive LibreELEC settings for large file")
                    else:
                        # STANDARD HIGH-MEMORY SETTINGS
                        listitem.setProperty('Network.BufferSize', '134217728')  # 128MB buffer
                        listitem.setProperty('Network.Timeout', '30')
                        listitem.setProperty('inputstream.adaptive.max_bandwidth', '100000000')  # 100Mbps limit
                        debug("Applied high-memory settings for large file")
                        
            else:  # Standard file size (<20GB)
                # STANDARD SETTINGS - use existing logic
                if is_libreelec:
                    listitem.setProperty('Network.BufferSize', '16777216')   # 16MB buffer
                    listitem.setProperty('Network.Timeout', '10')
                else:
                    listitem.setProperty('Network.BufferSize', '8388608')    # 8MB buffer
                    listitem.setProperty('Network.Timeout', '30')
                debug("Applied standard settings for normal-sized file")
            
            # ADAPTIVE STREAMING OPTIMIZATION for large files
            if self._is_adaptive_stream(url):
                if file_size_gb > 50:  # Very large files
                    # ULTRA-LARGE FILE SETTINGS
                    listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    listitem.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive-auto')
                    
                    if available_memory_mb > 8192:  # >8GB RAM
                        listitem.setProperty('inputstream.adaptive.live_delay', '5')  # Minimal delay
                    else:
                        listitem.setProperty('inputstream.adaptive.live_delay', '15')  # Conservative delay
                        
                    debug("Applied ultra-large file adaptive streaming settings")
            
            # MEMORY PRESSURE MONITORING: Set properties for runtime monitoring
            listitem.setProperty('StreamCinema.FileSize', str(int(file_size_gb * 1000)))  # Size in MB
            listitem.setProperty('StreamCinema.MemoryMode', 'large_file' if file_size_gb > 20 else 'standard')
            
        except Exception as e:
            debug(f"Error configuring large file streaming: {str(e)}")
            # Fallback to conservative settings
            listitem.setProperty('Network.BufferSize', '33554432')  # 32MB
            listitem.setProperty('Network.Timeout', '60')
    
    def _format_url_with_headers(self, url: str, headers: Dict[str, str], 
                                is_libreelec: bool = False) -> str:
        """
        Format URL with headers optimized for LibreELEC and 1Gbit networks.
        
        Args:
            url: Original URL
            headers: HTTP headers
            is_libreelec: Whether running on LibreELEC
            
        Returns:
            str: Formatted URL with headers
        """
        try:
            # PERFORMANCE: Optimize headers for LibreELEC + 1Gbit
            optimized_headers = headers.copy()
            
            if is_libreelec:
                # LIBREELEC + 1GBIT: Enhanced connection headers
                if 'Connection' not in optimized_headers:
                    optimized_headers['Connection'] = 'keep-alive'
                if 'Keep-Alive' not in optimized_headers:
                    optimized_headers['Keep-Alive'] = 'timeout=300, max=1000'
                if 'Accept-Encoding' not in optimized_headers:
                    optimized_headers['Accept-Encoding'] = 'gzip, deflate, br'
                if 'User-Agent' not in optimized_headers:
                    optimized_headers['User-Agent'] = 'LibreELEC/Kodi (1Gbit; Stream Cinema)'
            
            # KODI OPTIMIZATION: Format headers for Kodi URL format
            header_parts = []
            for key, value in optimized_headers.items():
                encoded_value = str(value).replace('&', '%26').replace('=', '%3D').replace('|', '%7C')
                header_parts.append(f"{key}={encoded_value}")
            
            if header_parts:
                header_string = "&".join(header_parts)
                formatted_url = f"{url}|{header_string}"
                
                # 1GBIT OPTIMIZATION: Add performance parameters
                if is_libreelec:
                    perf_params = [
                        "http-timeout=10",
                        "http-version=2.0", 
                        "http-buffer-size=16384",
                        "tcp-nodelay=true"
                    ]
                    formatted_url += "&" + "&".join(perf_params)
                
                return formatted_url
            
        except Exception as e:
            debug(f"Error formatting URL with headers: {str(e)}")
        
        return url
    
    def resolve_stream_url(self, handle: int, url: str, title: str,
                          custom_headers: Optional[Dict[str, str]] = None,
                          video_info: Optional[Dict[str, Any]] = None,
                          art: Optional[Dict[str, str]] = None) -> bool:
        """
        Resolve a stream URL for playback using xbmcplugin.setResolvedUrl.
        
        This is the proper way to handle streaming in Kodi plugins.
        
        Args:
            handle: Plugin handle from sys.argv[1]
            url: The stream URL to resolve
            title: Display title for the stream
            custom_headers: Optional HTTP headers
            video_info: Optional video metadata
            art: Optional artwork
            
        Returns:
            bool: True if resolution was successful
        """
        try:
            # Create properly configured ListItem
            listitem = self.create_playable_listitem(
                url=url,
                title=title,
                custom_headers=custom_headers,
                video_info=video_info,
                art=art,
                enable_download=True
            )
            
            # Resolve the URL for playback
            xbmcplugin.setResolvedUrl(handle, True, listitem)
            
            info(f"Stream resolved successfully: {title}")
            return True
            
        except Exception as e:
            error_msg = f"Failed to resolve stream: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            # Signal failure to Kodi
            try:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            except:
                pass
            
            return False
    
    def add_downloadable_item(self, handle: int, url: str, title: str,
                             custom_headers: Optional[Dict[str, str]] = None,
                             video_info: Optional[Dict[str, Any]] = None,
                             art: Optional[Dict[str, str]] = None,
                             is_folder: bool = False) -> bool:
        """
        Add a downloadable item to the directory listing.
        
        This creates directory items that can be both played and downloaded
        through Kodi's native context menus.
        
        Args:
            handle: Plugin handle from sys.argv[1]
            url: The stream/download URL
            title: Display title
            custom_headers: Optional HTTP headers
            video_info: Optional video metadata
            art: Optional artwork
            is_folder: Whether this is a folder item
            
        Returns:
            bool: True if item was added successfully
        """
        try:
            # Create ListItem
            listitem = self.create_playable_listitem(
                url=url,
                title=title,
                custom_headers=custom_headers,
                video_info=video_info,
                art=art,
                enable_download=True
            )
            
            # Create plugin URL for this item
            plugin_url = self._create_plugin_url(url, title, custom_headers)
            
            # Add to directory
            success = xbmcplugin.addDirectoryItem(
                handle=handle,
                url=plugin_url,
                listitem=listitem,
                isFolder=is_folder
            )
            
            if success:
                debug(f"Added downloadable item: {title}")
            else:
                debug(f"Failed to add item: {title}")
            
            return success
            
        except Exception as e:
            error_msg = f"Failed to add downloadable item: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            return False
    
    def _format_headers_for_kodi(self, headers: Dict[str, str]) -> str:
        """
        Format HTTP headers for Kodi URL format.
        
        Args:
            headers: Dictionary of HTTP headers
            
        Returns:
            str: Formatted header string for Kodi
        """
        header_parts = []
        
        for key, value in headers.items():
            # URL encode the header value
            encoded_value = quote_plus(str(value))
            header_parts.append(f"{key}={encoded_value}")
        
        return "&".join(header_parts)
    
    def _configure_download_context_menu(self, listitem: xbmcgui.ListItem, 
                                       url: str, title: str) -> None:
        """
        Configure context menu for download functionality.
        
        Args:
            listitem: The ListItem to configure
            url: Stream URL
            title: Item title
        """
        try:
            # Add download context menu item
            context_menu = []
            
            # Download command - uses Kodi's built-in download functionality
            download_path = self._get_download_path()
            if download_path:
                safe_filename = make_legal_filename(f"{title}.mp4")
                download_cmd = f"RunPlugin(plugin://plugin.video.stream-cinema/?action=download&url={quote_plus(url)}&title={quote_plus(title)}&filename={quote_plus(safe_filename)})"
                context_menu.append(("Download", download_cmd))
            
            # Add information context menu
            info_cmd = f"RunPlugin(plugin://plugin.video.stream-cinema/?action=info&title={quote_plus(title)})"
            context_menu.append(("Information", info_cmd))
            
            if context_menu:
                listitem.addContextMenuItems(context_menu)
                
        except Exception as e:
            debug(f"Failed to configure context menu: {str(e)}")
    
    def _create_plugin_url(self, url: str, title: str, 
                          headers: Optional[Dict[str, str]] = None) -> str:
        """
        Create a plugin URL for the item.
        
        Args:
            url: Original stream URL
            title: Item title
            headers: Optional headers
            
        Returns:
            str: Plugin URL
        """
        try:
            base_url = "plugin://plugin.video.stream-cinema/"
            params = [
                f"action=play",
                f"url={quote_plus(url)}",
                f"title={quote_plus(title)}"
            ]
            
            if headers:
                headers_str = self._format_headers_for_kodi(headers)
                params.append(f"headers={quote_plus(headers_str)}")
            
            return f"{base_url}?{'&'.join(params)}"
            
        except Exception as e:
            debug(f"Failed to create plugin URL: {str(e)}")
            return url
    
    def handle_download_action(self, url: str, title: str, filename: str,
                              headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Handle download action with support for large files (80GB+).
        
        Uses chunked downloading to prevent memory exhaustion and provides
        proper progress reporting for large file downloads.
        
        Args:
            url: URL to download
            title: Item title
            filename: Desired filename
            headers: Optional HTTP headers
            
        Returns:
            bool: True if download was initiated successfully
        """
        try:
            download_path = self._get_download_path()
            if not download_path:
                safe_dialog_ok(
                    "Download Error",
                    "Download path not configured. Please check addon settings."
                )
                return False
            
            # Ensure download directory exists
            if not self._ensure_download_directory(download_path):
                safe_dialog_ok(
                    "Download Error",
                    f"Cannot create download directory: {download_path}"
                )
                return False
            
            # Prepare filename and path
            safe_filename = make_legal_filename(filename)
            full_path = os.path.join(download_path, safe_filename)
            
            # Check if file already exists
            if xbmcvfs.exists(full_path):
                if not xbmcgui.Dialog().yesno(
                    "File Exists",
                    f"File already exists. Overwrite?\n{safe_filename}"
                ):
                    return False
            
            # LARGE FILE DETECTION: Estimate file size to choose download method
            estimated_size_gb = self._estimate_file_size_gb(url, headers)
            available_memory_mb = self._get_available_memory_mb()
            
            debug(f"Download analysis: {estimated_size_gb:.1f}GB file, {available_memory_mb}MB available memory")
            
            # SMART DOWNLOAD SELECTION: Choose method based on file size and available memory
            use_chunked_download = (
                estimated_size_gb > 5.0 or  # Files larger than 5GB
                (estimated_size_gb > 1.0 and available_memory_mb < 4096) or  # 1GB+ files on low-memory systems
                estimated_size_gb == 0.0  # Unknown size (could be large)
            )
            
            if use_chunked_download:
                debug("Using chunked download for large file")
                success = self._download_large_file_chunked(
                    url=url,
                    local_path=full_path,
                    headers=headers,
                    title=title
                )
            else:
                debug("Using standard download for small file")
                success = self._download_small_file_legacy(
                    url=url,
                    local_path=full_path,
                    headers=headers,
                    title=title
                )
            
            if success:
                safe_notification(
                    "Download Complete",
                    f"Downloaded: {title}"
                )
                info(f"Download completed: {full_path}")
                return True
            else:
                # Cleanup partial download
                try:
                    if xbmcvfs.exists(full_path):
                        xbmcvfs.delete(full_path)
                except:
                    pass
                return False
            
        except Exception as e:
            error_msg = f"Download action failed: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            safe_dialog_ok(
                "Download Error",
                f"Download failed: {str(e)}"
            )
            return False
    
    def _download_small_file_legacy(self, url: str, local_path: str,
                                   headers: Optional[Dict[str, str]] = None,
                                   title: str = "Download") -> bool:
        """
        Download small files using the legacy xbmcvfs.copy method.
        
        This is kept for compatibility with small files where memory usage is not a concern.
        
        Args:
            url: URL to download
            local_path: Local file path
            headers: Optional HTTP headers
            title: Title for progress display
            
        Returns:
            bool: True if download succeeded
        """
        try:
            # Prepare final URL with headers
            if headers:
                header_string = self._format_headers_for_kodi(headers)
                final_url = f"{url}|{header_string}"
            else:
                final_url = url
            
            # Show progress dialog
            progress = xbmcgui.DialogProgress()
            progress.create("Downloading", f"Downloading: {title}")
            
            try:
                # Use xbmcvfs.copy for small files
                success = xbmcvfs.copy(final_url, local_path)
                progress.close()
                
                if not success:
                    safe_dialog_ok(
                        "Download Failed",
                        f"Failed to download: {title}"
                    )
                
                return success
                
            except Exception as e:
                progress.close()
                error_msg = f"Legacy download failed: {str(e)}"
                info(error_msg)
                safe_dialog_ok(
                    "Download Error",
                    f"Download failed: {str(e)}"
                )
                return False
                
        except Exception as e:
            error_msg = f"Legacy download setup failed: {str(e)}"
            debug(error_msg)
            return False
    
    def start_background_download(self, url: str, title: str, filename: str,
                                 headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Start a download in the background using improved threading utilities.
        
        This follows Kodi 21+ threading guidelines for plugin operations.
        
        Args:
            url: URL to download
            title: Item title
            filename: Desired filename
            headers: Optional HTTP headers
            
        Returns:
            bool: True if background download was started successfully
        """
        try:
            from resources.lib.common.threading_utils import run_in_background
            
            # THREADING SAFETY: Check if we're in a plugin execution context
            if not hasattr(self, '_background_downloads'):
                self._background_downloads = {}
            
            download_id = f"{title}_{int(time.time())}"
            
            # KODI THREADING: Use improved background thread management
            download_thread = run_in_background(
                self._background_download_worker,
                download_id, url, title, filename, headers,
                timeout=1800.0,  # 30 minute timeout for downloads
                thread_name=f"StreamCinema_Download_{download_id}"
            )
            
            # THREAD MANAGEMENT: Store thread reference for monitoring
            self._background_downloads[download_id] = {
                'thread': download_thread,
                'status': 'starting',
                'title': title,
                'start_time': time.time()
            }
            
            # KODI NOTIFICATION: Inform user that download started
            safe_notification(
                "Download Started",
                f"Background download started: {title}",
                time=3000
            )
            
            debug(f"Started background download thread: {download_id}")
            return True
            
        except Exception as e:
            error_msg = f"Failed to start background download: {str(e)}"
            debug(error_msg)
            safe_dialog_ok("Download Error", error_msg)
            return False
    
    def _background_download_worker(self, download_id: str, url: str, title: str, 
                                   filename: str, headers: Optional[Dict[str, str]] = None) -> None:
        """
        Background worker thread for downloads.
        
        This runs in a separate thread to prevent blocking Kodi's main thread.
        
        Args:
            download_id: Unique download identifier
            url: URL to download
            title: Item title
            filename: Desired filename
            headers: Optional HTTP headers
        """
        try:
            # THREAD SAFETY: Update status
            if hasattr(self, '_background_downloads') and download_id in self._background_downloads:
                self._background_downloads[download_id]['status'] = 'downloading'
            
            debug(f"Background download worker started: {download_id}")
            
            # DOWNLOAD EXECUTION: Use the main download method
            success = self.handle_download_action(url, title, filename, headers)
            
            # THREAD SAFETY: Update final status
            if hasattr(self, '_background_downloads') and download_id in self._background_downloads:
                self._background_downloads[download_id]['status'] = 'completed' if success else 'failed'
                self._background_downloads[download_id]['end_time'] = time.time()
            
            # KODI NOTIFICATION: Inform user of completion
            if success:
                safe_notification(
                    "Download Complete",
                    f"Successfully downloaded: {title}",
                    time=5000
                )
                info(f"Background download completed: {title}")
            else:
                safe_notification(
                    "Download Failed",
                    f"Failed to download: {title}",
                    time=5000
                )
                info(f"Background download failed: {title}")
            
            # CLEANUP: Remove completed download from tracking
            try:
                if hasattr(self, '_background_downloads') and download_id in self._background_downloads:
                    del self._background_downloads[download_id]
            except:
                pass
                
        except Exception as e:
            error_msg = f"Background download worker error: {str(e)}"
            debug(error_msg)
            
            # THREAD SAFETY: Update error status
            try:
                if hasattr(self, '_background_downloads') and download_id in self._background_downloads:
                    self._background_downloads[download_id]['status'] = 'error'
                    self._background_downloads[download_id]['error'] = str(e)
            except:
                pass
            
            # KODI NOTIFICATION: Inform user of error
            safe_notification(
                "Download Error",
                f"Download error: {title}",
                time=5000
            )
    
    def get_active_downloads(self) -> Dict[str, Dict]:
        """
        Get information about active background downloads.
        
        Returns:
            Dict: Dictionary of active downloads with their status
        """
        if not hasattr(self, '_background_downloads'):
            return {}
        
        # CLEANUP: Remove completed threads
        active_downloads = {}
        for download_id, download_info in self._background_downloads.items():
            thread = download_info.get('thread')
            if thread and thread.is_alive():
                active_downloads[download_id] = {
                    'title': download_info.get('title', 'Unknown'),
                    'status': download_info.get('status', 'unknown'),
                    'start_time': download_info.get('start_time', 0)
                }
        
        return active_downloads
    
    def _get_download_path(self) -> Optional[str]:
        """
        Get the configured download path from addon settings.
        
        Returns:
            Optional[str]: Download path if configured, None otherwise
        """
        download_path = get_setting('download.path')
        
        if not download_path or download_path.strip() == '':
            debug("Download path not configured in settings")
            return None
        
        # Translate special paths
        try:
            translated_path = xbmcvfs.translatePath(download_path)
            debug(f"Download path: {download_path} -> {translated_path}")
            return translated_path
        except Exception as e:
            debug(f"Failed to translate download path: {str(e)}")
            return download_path
    
    def _ensure_download_directory(self, download_path: str) -> bool:
        """
        Ensure the download directory exists, creating it if necessary.
        
        Args:
            download_path: Path to the download directory
            
        Returns:
            bool: True if directory exists or was created successfully
        """
        try:
            if not xbmcvfs.exists(download_path):
                debug(f"Creating download directory: {download_path}")
                success = xbmcvfs.mkdirs(download_path)
                if not success:
                    debug("Failed to create download directory")
                    return False
            
            return True
            
        except Exception as e:
            debug(f"Error ensuring download directory: {str(e)}")
            return False
    
    def show_download_info(self, title: str) -> None:
        """
        Show information dialog for a downloadable item.
        
        Args:
            title: Item title
        """
        try:
            download_path = self._get_download_path()
            
            if download_path:
                message = f"Title: {title}\n\nDownload Location:\n{download_path}\n\nUse the context menu 'Download' option to download this item."
            else:
                message = f"Title: {title}\n\nDownload path not configured.\nPlease set download path in addon settings."
            
            safe_dialog_ok("Download Information", message)
            
        except Exception as e:
            debug(f"Failed to show download info: {str(e)}")
    
    def _clean_video_info(self, video_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean video info dictionary for Kodi compatibility.
        
        Args:
            video_info: Raw video info dictionary
            
        Returns:
            Dict: Cleaned video info dictionary
        """
        try:
            clean_info = {}
            
            # KODI COMPATIBILITY: Map common fields
            field_mapping = {
                'title': 'title',
                'plot': 'plot',
                'year': 'year',
                'duration': 'duration',
                'genre': 'genre',
                'director': 'director',
                'cast': 'cast',
                'rating': 'rating',
                'mediatype': 'mediatype'
            }
            
            for source_key, target_key in field_mapping.items():
                if source_key in video_info:
                    value = video_info[source_key]
                    
                    # VALIDATION: Ensure proper data types
                    if target_key == 'duration' and isinstance(value, (int, float)):
                        clean_info[target_key] = int(value)
                    elif target_key == 'year' and isinstance(value, (int, str)):
                        try:
                            clean_info[target_key] = int(value)
                        except (ValueError, TypeError):
                            pass
                    elif target_key == 'rating' and isinstance(value, (int, float)):
                        clean_info[target_key] = float(value)
                    elif isinstance(value, str) and value.strip():
                        clean_info[target_key] = value.strip()
                    elif isinstance(value, (list, tuple)) and value:
                        clean_info[target_key] = value
            
            # FALLBACK: Ensure minimum required fields
            if 'mediatype' not in clean_info:
                clean_info['mediatype'] = 'video'
            
            return clean_info
            
        except Exception as e:
            debug(f"Error cleaning video info: {str(e)}")
            return {'mediatype': 'video'}
    
    def _encode_headers_for_url(self, headers: Dict[str, str]) -> str:
        """
        Encode headers for URL parameters.
        
        Args:
            headers: Headers dictionary
            
        Returns:
            str: URL-encoded headers string
        """
        try:
            import json
            import base64
            
            # ENCODING: Use base64 encoding for safe URL transport
            headers_json = json.dumps(headers)
            headers_b64 = base64.b64encode(headers_json.encode('utf-8')).decode('ascii')
            return headers_b64
            
        except Exception as e:
            debug(f"Error encoding headers: {str(e)}")
            return ""
    
    def _determine_mime_type(self, url: str, video_info: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Determine MIME type for the stream.
        
        Args:
            url: Stream URL
            video_info: Optional video metadata
            
        Returns:
            Optional[str]: MIME type if determined
        """
        try:
            # CODEC DETECTION: Check video info for codec hints
            if video_info and 'codec' in video_info:
                codec = video_info['codec'].lower()
                
                codec_mime_map = {
                    'h264': 'video/mp4',
                    'avc': 'video/mp4',
                    'h265': 'video/mp4',
                    'hevc': 'video/mp4',
                    'vp8': 'video/webm',
                    'vp9': 'video/webm',
                    'av1': 'video/mp4'
                }
                
                for codec_name, mime_type in codec_mime_map.items():
                    if codec_name in codec:
                        return mime_type
            
            # URL DETECTION: Check URL for format hints
            url_lower = url.lower()
            
            if any(ext in url_lower for ext in ['.m3u8', 'manifest.mpd']):
                return 'application/vnd.apple.mpegurl'
            elif '.webm' in url_lower:
                return 'video/webm'
            elif any(ext in url_lower for ext in ['.mkv', '.mp4', '.avi']):
                return 'video/mp4'
            
            # DEFAULT: Return MP4 for best compatibility
            return 'video/mp4'
            
        except Exception as e:
            debug(f"Error determining MIME type: {str(e)}")
            return 'video/mp4'
    
    def _is_adaptive_stream(self, url):
        """Enhanced detection for adaptive streaming formats."""
        if not url:
            return False
            
        url_lower = url.lower()
        
        # Enhanced adaptive streaming detection
        adaptive_indicators = [
            '.m3u8',           # HLS
            '.mpd',            # DASH
            'manifest',        # Generic manifest
            'playlist.m3u8',   # HLS playlist
            'master.m3u8',     # HLS master playlist
            'index.m3u8',      # HLS index
            '/hls/',           # HLS path indicator
            '/dash/',          # DASH path indicator
            'adaptive=true',   # Query parameter
            'protocol=hls',    # Protocol indicator
            'protocol=dash'    # Protocol indicator
        ]
        
        return any(indicator in url_lower for indicator in adaptive_indicators)
    
    def _configure_advanced_properties(self, listitem: xbmcgui.ListItem, url: str, 
                                     video_info: Optional[Dict[str, Any]] = None) -> None:
        """
        Configure advanced ListItem properties for optimal Kodi performance.
        
        Args:
            listitem: ListItem to configure
            url: Stream URL
            video_info: Optional video metadata
        """
        try:
            # KODI OPTIMIZATION: Detect and configure adaptive streaming
            if self._is_adaptive_stream(url):
                listitem.setProperty('inputstream', 'inputstream.adaptive')
                
                # PERFORMANCE: Configure adaptive streaming properties
                if '.m3u8' in url.lower():
                    listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                elif '.mpd' in url.lower():
                    listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                
                # STREAMING OPTIMIZATION: Set adaptive streaming parameters
                listitem.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive-auto')
                listitem.setProperty('inputstream.adaptive.max_bandwidth', '0')  # No limit
                
            else:
                # PERFORMANCE: Set default MIME type for non-adaptive streams
                listitem.setMimeType('video/mp4')
            
            # KODI OPTIMIZATION: Set network and performance properties
            listitem.setProperty('Network.Bandwidth', '0')  # Auto-detect
            listitem.setProperty('Network.Timeout', '30')   # 30 second timeout
            
            # STREAMING OPTIMIZATION: Enable hardware acceleration hints
            listitem.setProperty('VideoCodec', 'h264')  # Hint for hardware decoding
            listitem.setProperty('VideoAspect', '1.78')  # 16:9 aspect ratio hint
            
            # PERFORMANCE: Configure content type for better handling
            if video_info:
                if video_info.get('mediatype') == 'movie':
                    listitem.setProperty('IsMovie', 'true')
                elif video_info.get('mediatype') == 'episode':
                    listitem.setProperty('IsEpisode', 'true')
                    
                # KODI OPTIMIZATION: Set duration for better seeking
                if 'duration' in video_info:
                    listitem.setProperty('TotalTime', str(video_info['duration']))
            
            # STREAMING OPTIMIZATION: Enable subtitle and audio track support
            listitem.setProperty('SupportsSubtitles', 'true')
            listitem.setProperty('SupportsAudioTracks', 'true')
            
            # PERFORMANCE: Set resume properties
            listitem.setProperty('ResumeTime', '0')
            listitem.setProperty('StartOffset', '0')
            
        except Exception as e:
            debug(f"Error configuring advanced properties: {str(e)}")


def create_download_headers(kraska_token: Optional[str] = None,
                           user_agent: Optional[str] = None,
                           referer: Optional[str] = None,
                           additional_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Create HTTP headers dictionary for streaming/downloads.
    
    Args:
        kraska_token: Optional Kraska authentication token
        user_agent: Optional custom User-Agent string
        referer: Optional Referer header
        additional_headers: Optional additional headers dictionary
        
    Returns:
        Dict[str, str]: Headers dictionary ready for use
    """
    headers = {}
    
    # Add User-Agent
    if user_agent:
        headers['User-Agent'] = user_agent
    else:
        # Use default addon User-Agent
        try:
            from resources.lib.system import user_agent
            headers['User-Agent'] = user_agent()
        except ImportError:
            headers['User-Agent'] = 'Stream Cinema Kodi Addon'
    
    # Add authentication token if available
    if kraska_token:
        headers['Authorization'] = f'Bearer {kraska_token}'
    
    # Add Referer if specified
    if referer:
        headers['Referer'] = referer
    
    # Add any additional headers
    if additional_headers and isinstance(additional_headers, dict):
        headers.update(additional_headers)
    
    return headers


def resolve_and_play_stream(handle: int, url: str, title: str,
                           headers: Optional[Dict[str, str]] = None,
                           video_info: Optional[Dict[str, Any]] = None,
                           art: Optional[Dict[str, str]] = None) -> bool:
    """
    Convenience function to resolve and play a stream.
    
    This is the recommended way to handle streaming in Kodi plugins.
    
    Args:
        handle: Plugin handle from sys.argv[1]
        url: Stream URL
        title: Stream title
        headers: Optional HTTP headers
        video_info: Optional video metadata
        art: Optional artwork
        
    Returns:
        bool: True if stream was resolved successfully
    """
    download_manager = StreamCinemaDownloadManager()
    return download_manager.resolve_stream_url(
        handle=handle,
        url=url,
        title=title,
        custom_headers=headers,
        video_info=video_info,
        art=art
    )


# Export main classes and functions
__all__ = [
    'StreamCinemaDownloadManager',
    'create_download_headers',
    'resolve_and_play_stream'
] 