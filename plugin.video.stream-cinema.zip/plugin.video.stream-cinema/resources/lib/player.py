# -*- coding: utf-8 -*-
"""
Stream Cinema Player

Modern Kodi-compliant player implementation following best practices.
Uses xbmcplugin.setResolvedUrl for proper streaming and integrates with
the updated download manager for download functionality.

Compatible with Kodi 21+ using official API methods and proper threading.
"""

import sys
import traceback
from typing import Optional, Dict, Any, List
from urllib.parse import parse_qsl, urlparse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib.common.logger import debug, info
from resources.lib.constants import SC, ADDON_ID
from resources.lib.kodiutils import get_setting
from resources.lib.language import Strings
from resources.lib.common.threading_utils import safe_dialog_ok, safe_notification
from resources.lib.download_manager import StreamCinemaDownloadManager, resolve_and_play_stream


class StreamCinemaPlayer:
    """
    Modern Kodi player implementation following current best practices.
    
    This class handles:
    - Proper stream resolution via xbmcplugin.setResolvedUrl
    - Integration with download manager
    - Modern ListItem configuration
    - Proper error handling and user feedback
    """
    
    def __init__(self):
        """Initialize the player."""
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('name')
        self.download_manager = StreamCinemaDownloadManager()
        
        # Player state
        self.current_item = None
        self.current_url = None
        
        debug("StreamCinemaPlayer initialized")
    
    def play_stream(self, handle: int, url: str, title: str,
                   headers: Optional[Dict[str, str]] = None,
                   video_info: Optional[Dict[str, Any]] = None,
                   art: Optional[Dict[str, str]] = None,
                   subtitle_url: Optional[str] = None) -> bool:
        """
        Play a stream using modern Kodi methods.
        
        Args:
            handle: Plugin handle from sys.argv[1]
            url: Stream URL
            title: Stream title
            headers: Optional HTTP headers
            video_info: Optional video metadata
            art: Optional artwork
            subtitle_url: Optional subtitle URL
            
        Returns:
            bool: True if stream was resolved successfully
        """
        try:
            
            info(f"Playing stream: {title}")
            debug(f"Stream URL: {url}")
            debug(f"Handle: {handle}")
            
            # Validate URL
            if not self._validate_stream_url(url):
                safe_dialog_ok(
                    "Stream Error",
                    f"Invalid stream URL: {url}"
                )
                return False
            
            # Store current item info
            self.current_item = {
                'url': url,
                'title': title,
                'headers': headers,
                'video_info': video_info,
                'art': art,
                'subtitle_url': subtitle_url
            }
            self.current_url = url
            
            # Create properly configured ListItem
            listitem = self._create_stream_listitem(
                url=url,
                title=title,
                headers=headers,
                video_info=video_info,
                art=art,
                subtitle_url=subtitle_url
            )
            
            # Enhanced error handling for network issues
            try:
                # Test connectivity before attempting to play
                import urllib.request
                urllib.request.urlopen(url, timeout=10)
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as e:
                safe_notification(
                    "Stream unavailable",
                    f"Stream unavailable: {str(e)}"
                )
                return False
            except Exception:
                # Continue anyway - some streams may not respond to HEAD requests
                pass
            
            # Resolve the stream for playback
            success = self._resolve_stream(handle, listitem, url, headers)
            
            if success:
                info(f"Stream resolved successfully: {title}")
                # Show notification
                safe_notification(
                    "Stream Started",
                    f"Playing: {title}"
                )
            else:
                info(f"Failed to resolve stream: {title}")
                safe_dialog_ok(
                    "Playback Error",
                    f"Failed to start playback: {title}"
                )
            
            return success
            
        except Exception as e:
            error_msg = f"Error playing stream: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            safe_dialog_ok(
                "Playback Error",
                f"Failed to play stream: {str(e)}"
            )
            return False
    
    def _create_stream_listitem(self, url: str, title: str,
                               headers: Optional[Dict[str, str]] = None,
                               video_info: Optional[Dict[str, Any]] = None,
                               art: Optional[Dict[str, str]] = None,
                               subtitle_url: Optional[str] = None) -> xbmcgui.ListItem:
        """
        Create a properly configured ListItem for streaming.
        
        Args:
            url: Stream URL
            title: Stream title
            headers: Optional HTTP headers
            video_info: Optional video metadata
            art: Optional artwork
            subtitle_url: Optional subtitle URL
            
        Returns:
            xbmcgui.ListItem: Configured ListItem
        """
        try:
            # Create ListItem with proper title
            listitem = xbmcgui.ListItem(label=title)
            
            # Configure as playable video
            listitem.setProperty('IsPlayable', 'true')
            
            # Set video info
            if video_info:
                # Sanitize video_info to only include valid Kodi keys with proper types
                sanitized_info = self._sanitize_video_info(video_info, title)
                listitem.setInfo('video', sanitized_info)
                
                # Handle special cases that need separate methods
                self._set_special_video_info(listitem, video_info)
            else:
                # Set basic video info
                listitem.setInfo('video', {
                    'title': title,
                    'mediatype': 'video',
                    'plot': f"Streaming: {title}"
                })
            
            # Set artwork
            if art:
                listitem.setArt(art)
            
            # Configure stream URL with headers
            stream_url = self._format_stream_url(url, headers)
            listitem.setPath(stream_url)
            
            # Set additional properties for better compatibility
            self._configure_listitem_properties(listitem, video_info)
            
            # Add subtitles if provided
            if subtitle_url:
                listitem.setSubtitles([subtitle_url])
            
            debug(f"Created ListItem for: {title}")
            return listitem
            
        except Exception as e:
            error_msg = f"Failed to create ListItem: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            # Return basic ListItem as fallback
            listitem = xbmcgui.ListItem(label=title)
            listitem.setPath(url)
            listitem.setProperty('IsPlayable', 'true')
            return listitem
    
    def _sanitize_video_info(self, video_info: Dict[str, Any], title: str) -> Dict[str, Any]:
        """
        Sanitize video_info dictionary to only include valid Kodi video info keys with proper types.
        
        Args:
            video_info: Raw video info dictionary
            title: Fallback title
            
        Returns:
            Dict[str, Any]: Sanitized video info dictionary
        """
        # Valid Kodi video info keys with their expected types
        valid_keys = {
            # String values
            'title': str,
            'originaltitle': str,
            'sorttitle': str,
            'plot': str,
            'plotoutline': str,
            'tagline': str,
            'tvshowtitle': str,
            'premiered': str,
            'status': str,
            'set': str,
            'setoverview': str,
            'imdbnumber': str,
            'code': str,
            'aired': str,
            'lastplayed': str,
            'album': str,
            'trailer': str,
            'path': str,
            'dateadded': str,
            'mediatype': str,
            'mpaa': str,
            'votes': str,
            
            # Integer values
            'year': int,
            'episode': int,
            'season': int,
            'sortepisode': int,
            'sortseason': int,
            'top250': int,
            'setid': int,
            'tracknumber': int,
            'playcount': int,
            'overlay': int,
            'duration': int,
            'dbid': int,
            'count': int,
            'size': int,
            
            # Float values
            'rating': float,
            'userrating': int,  # Actually int, range 1-10
            
            # List values (strings or tuples)
            'genre': (str, list),
            'country': (str, list),
            'director': (str, list),
            'studio': (str, list),
            'writer': (str, list),
            'tag': (str, list),
            'credits': (str, list),
            'artist': list,
            'cast': list,
            'castandrole': list,
            'showlink': (str, list),
        }
        
        sanitized = {}
        
        # Keys that should be excluded from setInfo (handled separately or not valid)
        excluded_keys = {
            'cast', 'unique_ids', 'ratings', 'seasons', 'quality', 
            'language_info', 'stream_info', 'art'
        }
        
        # Process each key in video_info
        for key, value in video_info.items():
            # Skip excluded keys
            if key in excluded_keys:
                continue
                
            if key in valid_keys and value is not None:
                expected_type = valid_keys[key]
                
                try:
                    # Handle different expected types
                    if expected_type == str:
                        sanitized[key] = str(value)
                    elif expected_type == int:
                        if isinstance(value, (int, float)):
                            sanitized[key] = int(value)
                        elif isinstance(value, str) and value.isdigit():
                            sanitized[key] = int(value)
                    elif expected_type == float:
                        if isinstance(value, (int, float)):
                            sanitized[key] = float(value)
                        elif isinstance(value, str):
                            try:
                                sanitized[key] = float(value)
                            except ValueError:
                                pass
                    elif expected_type == list:
                        if isinstance(value, list):
                            sanitized[key] = value
                        elif isinstance(value, str):
                            sanitized[key] = [value]
                    elif isinstance(expected_type, tuple):
                        # Handle multiple possible types (e.g., str or list)
                        if str in expected_type and isinstance(value, str):
                            sanitized[key] = value
                        elif list in expected_type and isinstance(value, list):
                            sanitized[key] = value
                        elif str in expected_type:
                            sanitized[key] = str(value)
                            
                except (ValueError, TypeError) as e:
                    debug(f"Failed to convert {key}={value} to {expected_type}: {e}")
                    continue
        
        # Ensure we have at least basic required fields
        if 'title' not in sanitized:
            sanitized['title'] = title
        if 'mediatype' not in sanitized:
            sanitized['mediatype'] = 'video'
        if 'plot' not in sanitized and 'title' in sanitized:
            sanitized['plot'] = f"Streaming: {sanitized['title']}"
        
        debug(f"Sanitized video_info: {sanitized}")
        return sanitized
    
    def _set_special_video_info(self, listitem: xbmcgui.ListItem, video_info: Dict[str, Any]) -> None:
        """
        Set special video info that requires separate ListItem methods.
        
        Args:
            listitem: ListItem to configure
            video_info: Raw video info dictionary
        """
        try:
            # Handle cast information
            if 'cast' in video_info and isinstance(video_info['cast'], list):
                # Convert cast to the format expected by setCast
                cast_list = []
                for actor in video_info['cast']:
                    if isinstance(actor, dict):
                        cast_list.append(actor)
                    elif isinstance(actor, str):
                        cast_list.append({'name': actor, 'role': ''})
                
                if cast_list:
                    try:
                        listitem.setCast(cast_list)
                        debug(f"Set cast: {len(cast_list)} actors")
                    except Exception as e:
                        debug(f"Failed to set cast: {e}")
            
            # Handle unique IDs
            if 'unique_ids' in video_info and isinstance(video_info['unique_ids'], dict):
                try:
                    # Find default rating if available
                    default_rating = None
                    for key in ['imdb', 'tvdb', 'tmdb']:
                        if key in video_info['unique_ids']:
                            default_rating = key
                            break
                    
                    listitem.setUniqueIDs(video_info['unique_ids'], default_rating or '')
                    debug(f"Set unique IDs: {video_info['unique_ids']}")
                except Exception as e:
                    debug(f"Failed to set unique IDs: {e}")
            
            # Handle ratings (if present as a dict with rating info)
            if 'ratings' in video_info and isinstance(video_info['ratings'], dict):
                try:
                    for rating_type, rating_data in video_info['ratings'].items():
                        if isinstance(rating_data, dict):
                            rating = rating_data.get('rating', 0.0)
                            votes = rating_data.get('votes', 0)
                            default = rating_data.get('default', False)
                            listitem.setRating(rating_type, float(rating), int(votes), default)
                        elif isinstance(rating_data, (int, float)):
                            listitem.setRating(rating_type, float(rating_data))
                    debug(f"Set ratings: {video_info['ratings']}")
                except Exception as e:
                    debug(f"Failed to set ratings: {e}")
            
            # Handle seasons (for TV shows)
            if 'seasons' in video_info and isinstance(video_info['seasons'], list):
                try:
                    for season_data in video_info['seasons']:
                        if isinstance(season_data, dict):
                            number = season_data.get('number', 0)
                            name = season_data.get('name', '')
                            if number > 0:
                                listitem.addSeason(number, name)
                        elif isinstance(season_data, (int, tuple)):
                            if isinstance(season_data, int):
                                listitem.addSeason(season_data)
                            else:  # tuple (number, name)
                                listitem.addSeason(season_data[0], season_data[1] if len(season_data) > 1 else '')
                    debug(f"Set seasons: {len(video_info['seasons'])} seasons")
                except Exception as e:
                    debug(f"Failed to set seasons: {e}")
                    
        except Exception as e:
            debug(f"Error setting special video info: {e}")
    
    def _configure_listitem_properties(self, listitem: xbmcgui.ListItem,
                                     video_info: Optional[Dict[str, Any]] = None) -> None:
        """
        Configure additional ListItem properties for optimal playback.
        
        Args:
            listitem: ListItem to configure
            video_info: Optional video metadata
        """
        try:
            # LIBREELEC DETECTION: Check if running on LibreELEC for specific optimizations
            is_libreelec = self._is_libreelec_system()
            
            # KODI OPTIMIZATION: Set input stream properties for adaptive streaming
            if self._should_use_adaptive_stream():
                listitem.setProperty('inputstream', 'inputstream.adaptive')
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                
                # LIBREELEC + 1GBIT OPTIMIZATION: Enhanced adaptive streaming settings
                if is_libreelec:
                    listitem.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive-auto')
                    listitem.setProperty('inputstream.adaptive.max_bandwidth', '100000000')  # 100Mbps for 1Gbit
                    listitem.setProperty('inputstream.adaptive.min_bandwidth', '1000000')    # 1Mbps minimum
                    # PERFORMANCE: Larger segment cache for high bandwidth
                    listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    listitem.setProperty('inputstream.adaptive.live_delay', '10')  # Reduced delay for 1Gbit
                else:
                    # Standard settings for other systems
                    listitem.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive-auto')
                    listitem.setProperty('inputstream.adaptive.max_bandwidth', '0')  # No limit
                    listitem.setProperty('inputstream.adaptive.min_bandwidth', '0')
            
            # KODI OPTIMIZATION: Set MIME type based on URL or video info
            mime_type = self._determine_mime_type(video_info)
            if mime_type:
                listitem.setMimeType(mime_type)
            
            # PERFORMANCE OPTIMIZATION: Set additional properties for better compatibility
            listitem.setProperty('ResumeTime', '0')
            listitem.setProperty('TotalTime', '0')
            
            # LIBREELEC OPTIMIZATION: Hardware acceleration hints for LibreELEC
            if is_libreelec:
                listitem.setProperty('VideoCodec', 'h264')  # Hint for hardware decoding
                listitem.setProperty('VideoAspect', '1.78')  # 16:9 aspect ratio hint
                # HARDWARE ACCELERATION: Enable all available decoders on LibreELEC
                listitem.setProperty('VideoDecoderHWAccel', 'auto')
                listitem.setProperty('AllowHWAccel', 'true')
            else:
                listitem.setProperty('VideoCodec', 'h264')
                listitem.setProperty('VideoAspect', '1.78')
            
            # MEMORY-AWARE NETWORK OPTIMIZATION: Enhanced network properties based on available memory
            available_memory_mb = self._get_available_memory_mb()
            
            if is_libreelec:
                listitem.setProperty('Network.Bandwidth', '1000000000')  # 1Gbit hint
                listitem.setProperty('Network.Timeout', '15')            # Faster timeout for 1Gbit
                
                # MEMORY-AWARE BUFFER SIZING for LibreELEC
                if available_memory_mb > 8192:  # >8GB RAM
                    listitem.setProperty('Network.BufferSize', '134217728')  # 128MB buffer for high-memory LibreELEC
                elif available_memory_mb > 4096:  # 4-8GB RAM
                    listitem.setProperty('Network.BufferSize', '67108864')   # 64MB buffer
                else:  # <4GB RAM
                    listitem.setProperty('Network.BufferSize', '33554432')   # 32MB buffer for low-memory LibreELEC
            else:
                listitem.setProperty('Network.Bandwidth', '0')  # Auto-detect
                listitem.setProperty('Network.Timeout', '30')   # 30 second timeout
                
                # MEMORY-AWARE BUFFER SIZING for standard systems
                if available_memory_mb > 8192:  # >8GB RAM
                    listitem.setProperty('Network.BufferSize', '67108864')   # 64MB buffer
                elif available_memory_mb > 4096:  # 4-8GB RAM
                    listitem.setProperty('Network.BufferSize', '33554432')   # 32MB buffer
                else:  # <4GB RAM
                    listitem.setProperty('Network.BufferSize', '16777216')   # 16MB buffer for low-memory systems
            
            # PERFORMANCE: Configure for live streams if applicable
            if video_info and video_info.get('live', False):
                listitem.setProperty('IsLive', 'true')
                if is_libreelec:
                    # LIBREELEC LIVE OPTIMIZATION: Reduced buffering for 1Gbit
                    listitem.setProperty('inputstream.adaptive.live_delay', '5')  # Very low delay
                    listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                else:
                    listitem.setProperty('inputstream.adaptive.live_delay', '30')
                    listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            
            # KODI OPTIMIZATION: Set content type for better handling
            if video_info:
                if video_info.get('mediatype') == 'movie':
                    listitem.setProperty('IsMovie', 'true')
                elif video_info.get('mediatype') == 'episode':
                    listitem.setProperty('IsEpisode', 'true')
            
            # PERFORMANCE: Enable subtitle support
            listitem.setProperty('SupportsSubtitles', 'true')
            
        except Exception as e:
            debug(f"Error configuring ListItem properties: {str(e)}")
    
    def _format_stream_url(self, url: str, headers: Optional[Dict[str, str]] = None) -> str:
        """
        Format stream URL with headers for Kodi with performance optimizations.
        
        Args:
            url: Original stream URL
            headers: Optional HTTP headers
            
        Returns:
            str: Formatted URL with headers and Kodi optimizations
        """
        if not headers:
            return url
        
        try:
            # LIBREELEC DETECTION: Check for LibreELEC system
            is_libreelec = self._is_libreelec_system()
            
            # KODI OPTIMIZATION: Format headers for Kodi URL format with performance enhancements
            header_parts = []
            
            # PERFORMANCE: Add connection optimization headers
            optimized_headers = headers.copy()
            
            # 1GBIT OPTIMIZATION: Enhanced connection settings for high-speed networks
            if is_libreelec:
                # LIBREELEC + 1GBIT: Optimized connection headers
                if 'Connection' not in optimized_headers:
                    optimized_headers['Connection'] = 'keep-alive'
                if 'Keep-Alive' not in optimized_headers:
                    optimized_headers['Keep-Alive'] = 'timeout=300, max=1000'  # Long-lived connections
                # PERFORMANCE: Enable HTTP/2 and compression for 1Gbit
                if 'Accept-Encoding' not in optimized_headers:
                    optimized_headers['Accept-Encoding'] = 'gzip, deflate, br'  # Brotli compression
                if 'Cache-Control' not in optimized_headers:
                    optimized_headers['Cache-Control'] = 'no-cache, no-store'  # Fresh content for streaming
            else:
                # Standard optimization for other systems
                if 'Connection' not in optimized_headers:
                    optimized_headers['Connection'] = 'keep-alive'
                if 'Accept-Encoding' not in optimized_headers:
                    optimized_headers['Accept-Encoding'] = 'gzip, deflate'
            
            # KODI OPTIMIZATION: Add range support for seeking
            if 'Range' not in optimized_headers:
                optimized_headers['Accept-Ranges'] = 'bytes'
            
            # STREAMING OPTIMIZATION: Set appropriate user agent if not present
            if 'User-Agent' not in optimized_headers:
                if is_libreelec:
                    optimized_headers['User-Agent'] = 'LibreELEC/Kodi (1Gbit; Stream Cinema)'
                else:
                    optimized_headers['User-Agent'] = 'Kodi/20.0 (compatible; Stream Cinema)'
            
            for key, value in optimized_headers.items():
                # PERFORMANCE: Properly encode header values for Kodi
                encoded_value = str(value).replace('&', '%26').replace('=', '%3D').replace('|', '%7C')
                header_parts.append(f"{key}={encoded_value}")
            
            if header_parts:
                header_string = "&".join(header_parts)
                # KODI OPTIMIZATION: Use proper URL format with pipe separator
                formatted_url = f"{url}|{header_string}"
                
                # 1GBIT OPTIMIZATION: Enhanced Kodi-specific URL parameters
                kodi_params = []
                
                if is_libreelec:
                    # LIBREELEC + 1GBIT: Optimized parameters for high-speed streaming
                    kodi_params.append("http-timeout=15")        # Faster timeout for 1Gbit
                    kodi_params.append("http-version=2.0")       # HTTP/2 for better performance
                    kodi_params.append("http-buffer-size=16384") # 16KB buffer for high bandwidth
                    kodi_params.append("http-reconnect=true")    # Auto-reconnect for stability
                    kodi_params.append("http-seekable=true")     # Enable seeking
                    # PERFORMANCE: TCP optimizations for 1Gbit
                    kodi_params.append("tcp-nodelay=true")       # Disable Nagle's algorithm
                    kodi_params.append("tcp-keepalive=true")     # Keep connections alive
                else:
                    # Standard parameters for other systems
                    kodi_params.append("http-timeout=30")
                    kodi_params.append("http-version=2.0")
                    kodi_params.append("http-buffer-size=8192")
                
                if kodi_params:
                    formatted_url += "&" + "&".join(kodi_params)
                
                return formatted_url
            
        except Exception as e:
            debug(f"Error formatting headers: {str(e)}")
        
        return url
    
    def _resolve_stream(self, handle: int, listitem: xbmcgui.ListItem,
                       url: str, headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Resolve stream for playback using xbmcplugin.setResolvedUrl.
        
        Args:
            handle: Plugin handle
            listitem: Configured ListItem
            url: Stream URL
            headers: Optional headers
            
        Returns:
            bool: True if resolution was successful
        """
        try:
            # Use xbmcplugin.setResolvedUrl for proper streaming
            xbmcplugin.setResolvedUrl(handle, True, listitem)
            return True
            
        except Exception as e:
            error_msg = f"Failed to resolve stream: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            # Signal failure to Kodi
            try:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            except:
                pass
            
            return False
    
    def _validate_stream_url(self, url: str) -> bool:
        """
        Validate stream URL.
        
        Args:
            url: URL to validate
            
        Returns:
            bool: True if URL is valid
        """
        if not url or not isinstance(url, str):
            return False
        
        try:
            parsed = urlparse(url)
            return bool(parsed.scheme and parsed.netloc)
        except:
            return False
    
    def _should_use_adaptive_stream(self) -> bool:
        """
        Determine if adaptive streaming should be used with Kodi optimizations.
        
        Returns:
            bool: True if adaptive streaming should be used
        """
        try:
            # KODI OPTIMIZATION: Check if inputstream.adaptive is available and enabled
            if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
                debug("inputstream.adaptive not available")
                return False
            
            # PERFORMANCE: Check if addon is enabled
            if not xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'):
                debug("inputstream.adaptive not enabled")
                return False
            
            # KODI OPTIMIZATION: Check system capabilities for hardware acceleration
            has_hardware_decode = (
                xbmc.getCondVisibility('System.Platform.Android') or
                xbmc.getCondVisibility('System.Platform.Linux') or
                xbmc.getCondVisibility('System.Platform.Windows') or
                xbmc.getCondVisibility('System.Platform.OSX')
            )
            
            if has_hardware_decode:
                debug("Hardware decoding available - enabling adaptive streaming")
                return True
            
            # STREAMING OPTIMIZATION: Check network conditions
            # Enable adaptive streaming for better quality adaptation
            return True
            
        except Exception as e:
            debug(f"Error checking adaptive streaming support: {str(e)}")
            return False
    
    def _determine_mime_type(self, video_info: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Determine appropriate MIME type for the stream with Kodi optimizations.
        
        Args:
            video_info: Optional video metadata
            
        Returns:
            Optional[str]: MIME type if determined
        """
        # KODI OPTIMIZATION: Enhanced MIME type detection for better codec handling
        if video_info and 'codec' in video_info:
            codec = video_info['codec'].lower()
            
            # PERFORMANCE: Map codecs to optimal MIME types
            codec_mime_map = {
                'h264': 'video/mp4',
                'avc': 'video/mp4', 
                'h265': 'video/mp4',
                'hevc': 'video/mp4',
                'vp8': 'video/webm',
                'vp9': 'video/webm',
                'av1': 'video/mp4'
            }
            
            for codec_name, mime_type in codec_mime_map.items():
                if codec_name in codec:
                    debug(f"Detected codec {codec_name}, using MIME type {mime_type}")
                    return mime_type
        
        # STREAMING OPTIMIZATION: Check URL for format hints
        if hasattr(self, 'current_url') and self.current_url:
            url_lower = self.current_url.lower()
            
            # KODI OPTIMIZATION: URL-based MIME type detection
            if any(ext in url_lower for ext in ['.m3u8', 'manifest.mpd']):
                return 'application/vnd.apple.mpegurl'  # HLS/DASH
            elif '.webm' in url_lower:
                return 'video/webm'
            elif any(ext in url_lower for ext in ['.mkv', '.mp4', '.avi']):
                return 'video/mp4'
        
        # PERFORMANCE: Default to MP4 for best compatibility
        return 'video/mp4'
    
    def handle_download_request(self, url: str, title: str,
                              headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Handle download request using the download manager.
        
        Args:
            url: URL to download
            title: Item title
            headers: Optional HTTP headers
            
        Returns:
            bool: True if download was initiated successfully
        """
        try:
            info(f"Download requested: {title}")
            
            # Use download manager to handle the download
            filename = f"{title}.mp4"
            success = self.download_manager.handle_download_action(
                url=url,
                title=title,
                filename=filename,
                headers=headers
            )
            
            if success:
                info(f"Download initiated: {title}")
            else:
                info(f"Download failed: {title}")
            
            return success
            
        except Exception as e:
            error_msg = f"Download error: {str(e)}"
            info(error_msg)
            debug(f"Full traceback: {traceback.format_exc()}")
            
            safe_dialog_ok(
                "Download Error",
                f"Failed to download: {str(e)}"
            )
            return False
    
    def show_stream_info(self, title: str, url: str,
                        video_info: Optional[Dict[str, Any]] = None) -> None:
        """
        Show information dialog for a stream.
        
        Args:
            title: Stream title
            url: Stream URL
            video_info: Optional video metadata
        """
        try:
            info_lines = [f"Title: {title}"]
            
            if video_info:
                if 'plot' in video_info:
                    info_lines.append(f"Plot: {video_info['plot']}")
                if 'duration' in video_info:
                    duration = video_info['duration']
                    if isinstance(duration, int) and duration > 0:
                        hours = duration // 3600
                        minutes = (duration % 3600) // 60
                        info_lines.append(f"Duration: {hours:02d}:{minutes:02d}")
                if 'year' in video_info:
                    info_lines.append(f"Year: {video_info['year']}")
                if 'genre' in video_info:
                    info_lines.append(f"Genre: {video_info['genre']}")
            
            # Add technical info
            parsed_url = urlparse(url)
            info_lines.append(f"Source: {parsed_url.netloc}")
            
            message = "\n".join(info_lines)
            safe_dialog_ok("Stream Information", message)
            
        except Exception as e:
            debug(f"Failed to show stream info: {str(e)}")
    
    def _get_available_memory_mb(self) -> int:
        """
        Get available system memory in MB.
        
        Returns:
            int: Available memory in MB, or 2048 if detection fails
        """
        try:
            # Use existing memory detection from kodivideocache
            free_mem_str = xbmc.getInfoLabel('System.FreeMemory')
            if 'MB' in free_mem_str:
                # Kodi reports in binary MB (MiB)
                free_mem = int(free_mem_str.replace('MB', '').strip())
                debug(f"Detected available memory: {free_mem} MB")
                return free_mem
            else:
                # Assume bytes, convert to MB
                free_mem = int(free_mem_str) / (1024 * 1024)
                debug(f"Detected available memory: {int(free_mem)} MB")
                return int(free_mem)
        except (ValueError, TypeError):
            debug('Error detecting available memory, defaulting to 2048 MB')
            return 2048  # Default to 2GB if detection fails

    def _is_libreelec_system(self) -> bool:
        """
        Detect if running on LibreELEC system for specific optimizations.
        
        Returns:
            bool: True if running on LibreELEC
        """
        try:
            # LIBREELEC DETECTION: Check system information
            if xbmc.getCondVisibility('System.Platform.Linux'):
                # Check for LibreELEC specific indicators
                system_name = xbmc.getInfoLabel('System.FriendlyName').lower()
                build_version = xbmc.getInfoLabel('System.BuildVersion').lower()
                
                # DETECTION: Multiple methods to identify LibreELEC
                libreelec_indicators = [
                    'libreelec' in system_name,
                    'libreelec' in build_version,
                    xbmc.getCondVisibility('System.HasAddon(service.libreelec.settings)')
                ]
                
                if any(libreelec_indicators):
                    debug("LibreELEC system detected - enabling 1Gbit optimizations")
                    return True
            
            return False
            
        except Exception as e:
            debug(f"Error detecting LibreELEC: {str(e)}")
            return False


def handle_plugin_action(action: str, params: Dict[str, str]) -> bool:
    """
    Handle plugin actions from URL parameters.
    
    Args:
        action: Action to perform
        params: URL parameters
        
    Returns:
        bool: True if action was handled successfully
    """
    try:
        player = StreamCinemaPlayer()
        
        if action == 'play':
            # Extract parameters
            url = params.get('url', '')
            title = params.get('title', 'Unknown')
            headers_str = params.get('headers', '')
            
            # Parse headers if provided
            headers = None
            if headers_str:
                try:
                    # Simple header parsing - in production, use proper URL decoding
                    header_pairs = headers_str.split('&')
                    headers = {}
                    for pair in header_pairs:
                        if '=' in pair:
                            key, value = pair.split('=', 1)
                            headers[key] = value
                except Exception as e:
                    debug(f"Failed to parse headers: {str(e)}")
            
            # Get handle from sys.argv
            handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
            
            return player.play_stream(
                handle=handle,
                url=url,
                title=title,
                headers=headers
            )
        
        elif action == 'download':
            url = params.get('url', '')
            title = params.get('title', 'Unknown')
            headers_str = params.get('headers', '')
            
            # Parse headers if provided
            headers = None
            if headers_str:
                try:
                    header_pairs = headers_str.split('&')
                    headers = {}
                    for pair in header_pairs:
                        if '=' in pair:
                            key, value = pair.split('=', 1)
                            headers[key] = value
                except Exception as e:
                    debug(f"Failed to parse headers: {str(e)}")
            
            return player.handle_download_request(
                url=url,
                title=title,
                headers=headers
            )
        
        elif action == 'info':
            title = params.get('title', 'Unknown')
            url = params.get('url', '')
            
            player.show_stream_info(title=title, url=url)
            return True
        
        else:
            debug(f"Unknown action: {action}")
            return False
    
    except Exception as e:
        error_msg = f"Error handling plugin action: {str(e)}"
        info(error_msg)
        debug(f"Full traceback: {traceback.format_exc()}")
        return False


def main():
    """
    Main entry point for the player module.
    """
    try:
        # Parse URL parameters
        if len(sys.argv) > 2:
            params = dict(parse_qsl(sys.argv[2][1:]))
            action = params.get('action', '')
            
            if action:
                handle_plugin_action(action, params)
            else:
                debug("No action specified in parameters")
        else:
            debug("No parameters provided")
    
    except Exception as e:
        error_msg = f"Error in player main: {str(e)}"
        info(error_msg)
        debug(f"Full traceback: {traceback.format_exc()}")


def create_stream_headers(kraska_token: Optional[str] = None,
                         user_agent: Optional[str] = None,
                         referer: Optional[str] = None,
                         additional_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Create HTTP headers dictionary for streaming/downloads.
    
    Args:
        kraska_token: Optional Kraska authentication token
        user_agent: Optional custom User-Agent string
        referer: Optional Referer header
        additional_headers: Optional additional headers dictionary
        
    Returns:
        Dict[str, str]: Headers dictionary ready for use
    """
    headers = {}
    
    # Add User-Agent
    if user_agent:
        headers['User-Agent'] = user_agent
    else:
        # Use default addon User-Agent
        try:
            from resources.lib.system import user_agent
            headers['User-Agent'] = user_agent()
        except ImportError:
            headers['User-Agent'] = 'Stream Cinema Kodi Addon'
    
    # Add authentication token if available
    if kraska_token:
        headers['Authorization'] = f'Bearer {kraska_token}'
    
    # Add Referer if specified
    if referer:
        headers['Referer'] = referer
    
    # Add any additional headers
    if additional_headers and isinstance(additional_headers, dict):
        headers.update(additional_headers)
    
    return headers


# Export main classes and functions
__all__ = [
    'StreamCinemaPlayer',
    'handle_plugin_action',
    'create_stream_headers',
    'main'
]


if __name__ == '__main__':
    main() 