# -*- coding: utf-8 -*-
import os
import sqlite3
import threading
from json import loads, dumps

from resources.lib.constants import ADDON, ADDON_ID, SC
from resources.lib.common.logger import debug
from resources.lib.common.threading_utils import safe_dialog_ok, safe_dialog_progress
from resources.lib.kodiutils import translate_path, get_skin_name
# Removed SYSTEM_VERSION import - using Kodi 21+ database versions directly

import xbmcvfs

checked = False
_storage_cache = {}
# Add memory management for global caches
_storage_cache_max_size = 50  # Maximum number of cached storage items
_storage_cache_access_count = {}  # Track access for LRU cleanup
_last_cache_cleanup = 0  # Track last cleanup time


def _cleanup_storage_cache():
    """Clean up storage cache when it exceeds size limit"""
    global _storage_cache, _storage_cache_access_count, _last_cache_cleanup
    import time
    
    current_time = time.time()
    # Only cleanup every 5 minutes to avoid overhead
    if current_time - _last_cache_cleanup < 300:
        return
        
    _last_cache_cleanup = current_time
    
    if len(_storage_cache) <= _storage_cache_max_size:
        return
        
    debug('Storage cache size {} exceeds limit {}, cleaning up...'.format(
        len(_storage_cache), _storage_cache_max_size))
    
    # Sort by access count (least recently used first)
    items_by_usage = sorted(
        _storage_cache_access_count.items(), 
        key=lambda x: x[1]
    )
    
    # Remove least used items until we're under the limit
    target_size = int(_storage_cache_max_size * 0.8)  # Remove 20% extra
    items_to_remove = len(_storage_cache) - target_size
    
    for name, _ in items_by_usage[:items_to_remove]:
        if name in _storage_cache:
            del _storage_cache[name]
        if name in _storage_cache_access_count:
            del _storage_cache_access_count[name]
    
    debug('Storage cache cleaned up, new size: {}'.format(len(_storage_cache)))


def reset_global_storage_state():
    """Reset global storage state for each plugin call to avoid Kodi execution model issues"""
    global _storage_cache, _storage_cache_access_count, _last_cache_cleanup
    
    # Periodic cleanup to prevent unbounded growth across plugin calls
    import time
    current_time = time.time()
    if current_time - _last_cache_cleanup > 1800:  # Every 30 minutes
        debug('Resetting storage global state for plugin call isolation')
        _storage_cache.clear()
        _storage_cache_access_count.clear()
        _last_cache_cleanup = current_time

def cleanup_all_storage_caches():
    """Cleanup method for proper shutdown"""
    global _storage_cache, _storage_cache_access_count
    debug('Cleaning up all storage caches...')
    _storage_cache.clear()
    _storage_cache_access_count.clear()
    debug('Storage cache cleanup complete')


class Sqlite(object):
    _connection_pool = {}  # Class-level connection pool
    _max_pool_size = 10   # Maximum connections to prevent memory leaks
    _pool_access_count = {}  # Track access for LRU cleanup
    _pool_lock = threading.RLock()  # Thread-safe connection pool access
    
    def __init__(self, path):
        self._path = translate_path(path)
        self._connection = None
        # debug('db file: {}'.format(self._path))

    @classmethod
    def _cleanup_connection_pool(cls):
        """Clean up connection pool when it exceeds size limit"""
        with cls._pool_lock:
            if len(cls._connection_pool) <= cls._max_pool_size:
                return
                
            debug('Connection pool size {} exceeds limit {}, cleaning up...'.format(
                len(cls._connection_pool), cls._max_pool_size))
            
            # Sort by access count (least recently used first)
            items_by_usage = sorted(
                cls._pool_access_count.items(), 
                key=lambda x: x[1]
            )
            
            # Close and remove least used connections
            target_size = int(cls._max_pool_size * 0.8)  # Remove 20% extra
            connections_to_remove = len(cls._connection_pool) - target_size
            
            for path, _ in items_by_usage[:connections_to_remove]:
                if path in cls._connection_pool:
                    try:
                        cls._connection_pool[path].close()
                    except:
                        pass
                    del cls._connection_pool[path]
                if path in cls._pool_access_count:
                    del cls._pool_access_count[path]
            
            debug('Connection pool cleaned up, new size: {}'.format(len(cls._connection_pool)))

    def _get_conn(self):
        # Use connection pooling to avoid creating multiple connections to same DB
        with Sqlite._pool_lock:
            if self._path in Sqlite._connection_pool:
                try:
                    # Test if existing connection is still valid
                    conn = Sqlite._connection_pool[self._path]
                    # Do a simple test query to verify connection is valid
                    conn.execute("SELECT 1").fetchone()
                    # Track access for LRU management
                    Sqlite._pool_access_count[self._path] = Sqlite._pool_access_count.get(self._path, 0) + 1
                    return conn
                except (sqlite3.ProgrammingError, sqlite3.OperationalError, sqlite3.DatabaseError):
                    # Connection is stale or database is locked, remove from pool
                    try:
                        # Try to close invalid connection cleanly
                        Sqlite._connection_pool[self._path].close()
                    except:
                        pass
                    del Sqlite._connection_pool[self._path]
                    if self._path in Sqlite._pool_access_count:
                        del Sqlite._pool_access_count[self._path]
            
            # Clean up pool if needed before adding new connection
            Sqlite._cleanup_connection_pool()
            
            # Create new connection with proper isolation level and timeout
            # MEMORY LEAK FIX: Use context manager and proper connection parameters
            connection = sqlite3.connect(self._path, timeout=5.0, check_same_thread=False, 
                                       isolation_level=None)  # autocommit mode to prevent lock issues
            connection.execute("PRAGMA journal_mode=WAL")  # Write-Ahead Logging for better concurrency
            connection.execute("PRAGMA synchronous=NORMAL")  # Better performance with safety
            Sqlite._connection_pool[self._path] = connection
            Sqlite._pool_access_count[self._path] = 1
            return connection

    def execute(self, query, *args):
        # debug('SQL: {} <- {}'.format(query, args))
        # debug('SQL')
        with self._get_conn() as conn:
            c = conn.cursor()
            c.execute(query, args)
            return c

    @classmethod
    def cleanup_all_connections(cls):
        """Cleanup method for proper shutdown"""
        with cls._pool_lock:
            debug('Cleaning up all database connections...')
            for path, conn in cls._connection_pool.items():
                try:
                    conn.close()
                except:
                    pass
            cls._connection_pool.clear()
            cls._pool_access_count.clear()
            debug('Database connection cleanup complete')


class KodiAddonsDb:
    def __init__(self):
        path = 'special://database/Addons33.db'  # Kodi 21+ database version
        self._db = Sqlite(path)

    def check_repo(self):
        query = 'select id from repo where id in (' \
                'select idRepo from addonlinkrepo where idAddon in (' \
                'select id from addons where addonID=?))'
        res = self._db.execute(query, ADDON_ID).fetchone()
        if res is not None:
            return True
        return False

    def enable_auto_update(self):
        if not self.check_repo():
            from resources.lib.language import Strings
            safe_dialog_ok(Strings.txt(Strings.SYSTEM_H1), Strings.txt(Strings.SYSTEM_NOT_INSTALLED_FROM_REPOSITORY))
        query = 'delete from update_rules where addonID=?'
        self._db.execute(query, ADDON_ID)


class KodiDb:
    _static_db = None

    def __init__(self):
        path = 'special://database/MyVideos121.db'  # Kodi 21+ database version
        if KodiDb._static_db is None:
            KodiDb._static_db = Sqlite(path)
        self._db = KodiDb._static_db
        # debug('tables: {}'.format(self._db.execute('SELECT name FROM sqlite_master WHERE type =\'table\'').fetchall()))

    def get_watched_path(self, path):
        try:
            sql = 'select f.* ' \
                  'from files f join path p on p.idPath = f.idPath ' \
                  'where f.strfilename like ? or p.strpath like ?'
            return self._db.execute(sql, path, path).fetchone()
        except:
            return None

    def set_watched_path(self, path, times):
        res = self.get_watched_path(path)
        if res and res[0]:
            # debug('MAME PATH: {}'.find(path))
            sql = 'update files set playcount=? where idfile=?'
            self._db.execute(sql, times, res[0])
        else:
            debug('Nemame PATH: {}'.format(path))
            pass

    def get_watched(self):
        try:
            query = 'select p.strPath || f.strFilename ' \
                    'from files f join path p on p.idPath = f.idPath ' \
                    'where f.playCount > 0'
            return self._db.execute(query).fetchall()
        except:
            return None


class TexturesDb:
    def __init__(self):
        path = 'special://database/Textures13.db'  # Kodi 21+ database version
        self._db = Sqlite(path)

    def clean(self):
        zoznam = self.to_clean()
        total = len(zoznam)
        d = safe_dialog_progress()
        d.create('mazanie', 'mazem')
        
        # Handle empty list to prevent division by zero
        if total == 0:
            debug('No textures to clean')
            d.close()
            return
            
        for pos, i in enumerate(zoznam):
            p = int(pos/total*100)
            debug('item: {}/{} {}'.format(pos, total, TexturesDb.file_name(i)))
            self.remove_item(i)
            d.update(p, 'mazanie', 'mazem {}'.format(i[1]))
        d.close()

    @staticmethod
    def file_name(item):
        return translate_path("special://masterprofile/Thumbnails/{}".format(item[1]))

    def remove_item(self, item):
        xbmcvfs.delete(TexturesDb.file_name(item))
        self._db.execute('delete from sizes where idtexture=?', item[0])
        self._db.execute('delete from texture where id=?', item[0])

    def to_clean(self):
        q = "SELECT s.idtexture, t.cachedurl, s.lastusetime FROM sizes AS s JOIN texture t ON (t.id=s.idtexture) WHERE lastusetime <= DATETIME('now', '-1 month') ORDER BY 3 ASC"
        return self._db.execute(q).fetchall()


class Storage(object):
    _sql_create = (
        'CREATE TABLE IF NOT EXISTS storage '
        '('
        '  item_key VARCHAR(255) PRIMARY KEY ,'
        '  item_value BLOB'
        ')'
    )
    _sql_set = 'INSERT OR REPLACE INTO storage (item_key, item_value) VALUES (?, ?)'
    _sql_get = 'SELECT item_value FROM storage WHERE item_key = ?'
    _sql_del = 'DELETE FROM storage WHERE item_key = ?'
    _data = {}
    _static_db = None
    _db_lock = threading.RLock()  # Thread-safe database access

    def __init__(self, name):
        path = ADDON.getAddonInfo("profile")
        if not xbmcvfs.exists(path):
            debug("storage path: {}".format(repr(path)))
            xbmcvfs.mkdir(path)
        path = os.path.join(path, 'storage.db')
        if Storage._static_db is None:
            Storage._static_db = Sqlite(path=path)
        self._db = Storage._static_db
        global checked
        self._data = {}
        self._last_saved = {}
        self._name = name
        if not checked:
            checked = True
            self._db.execute(self._sql_create)
        self.load()

    def __setitem__(self, key, value):
        if value is not None:
            self._data[key] = value
        else:
            if key in self._data:
                del self._data[key]
        self.save()

    def __getitem__(self, item):
        return self._data.get(item)

    def __delitem__(self, key):
        if key in self._data:
            del self._data[key]
        self.save()

    def get(self, name):
        if name in self._data:
            return self._data[name]
        return None

    def update(self, up):
        debug('updatujem {} o {}'.format(self._name, up))
        self._data.update(up)
        self.save()

    def save(self):
        with Storage._db_lock:
            # Optimize: Only save if data actually changed
            if hasattr(self, '_last_saved_hash'):
                import hashlib
                current_hash = hashlib.md5(str(self._data).encode()).hexdigest()
                if current_hash == self._last_saved_hash:
                    debug('Data unchanged, skipping save for {}'.format(self._name))
                    return
                self._last_saved_hash = current_hash
            else:
                import hashlib
                self._last_saved_hash = hashlib.md5(str(self._data).encode()).hexdigest()
            
            try:
                # Use faster JSON serialization with separators
                data_str = dumps(self._data, separators=(',', ':'))
                self._db.execute(self._sql_set, '{}'.format(self._name), data_str)
                _storage_cache[self._name] = self._data
            except (TypeError, ValueError) as e:
                debug('JSON serialization error for {}: {}'.format(self._name, str(e)))

    def load(self, force=False):
        with Storage._db_lock:
            # debug('name {}'.format(self._name))
            global _storage_cache, _storage_cache_access_count
            
            # Trigger periodic cleanup
            _cleanup_storage_cache()
            
            if force is False and self._name in _storage_cache:
                self._data = _storage_cache.get(self._name)
                # Track access for LRU management
                _storage_cache_access_count[self._name] = _storage_cache_access_count.get(self._name, 0) + 1
                return
            
            # debug('storage cache: {}'.format(_storage_cache))
            try:
                val = self._db.execute(self._sql_get, self._name).fetchone()
                if val and val[0]:
                    # Use faster JSON loading
                    self._data = loads(val[0])
                else:
                    self._data = {}
            except (ValueError, TypeError) as e:
                debug('JSON deserialization error for {}: {}'.format(self._name, str(e)))
                self._data = {}
            except sqlite3.Error as e:
                debug('Database error loading {}: {}'.format(self._name, str(e)))
                self._data = {}
            except Exception as e:
                debug('Unexpected error loading {}: {}'.format(self._name, str(e)))
                self._data = {}
                
            _storage_cache[self._name] = self._data
            _storage_cache_access_count[self._name] = 1
            # debug('loaded data {}'.format(self._data))

    @property
    def data(self):
        return self._data


class KodiViewModeDb:
    def __init__(self):
        path = 'special://database/ViewModes6.db'  # Kodi 21+ database version
        self._db = Sqlite(path)

    def get_sort(self, url):
        query = 'select sortMethod, sortOrder from view where path=? and skin=?'
        return self._db.execute(query, url, get_skin_name()).fetchone()


preferred_lang_list = Storage(SC.ITEM_PREFERRED_LANG)