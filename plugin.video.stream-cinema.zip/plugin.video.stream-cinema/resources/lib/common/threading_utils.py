import xbmc
import threading
import functools
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Callable, Any, Dict, List
from resources.lib.common.logger import debug

# Global thread pool for addon-wide use
_global_thread_pool: Optional[ThreadPoolExecutor] = None
_thread_pool_lock = threading.Lock()
_active_threads: Dict[str, threading.Thread] = {}
_thread_cleanup_lock = threading.Lock()

def get_global_thread_pool(max_workers: int = 4) -> ThreadPoolExecutor:
    """
    Get or create the global thread pool for the addon.
    
    Args:
        max_workers: Maximum number of worker threads
        
    Returns:
        ThreadPoolExecutor: Global thread pool instance
    """
    global _global_thread_pool
    
    with _thread_pool_lock:
        if _global_thread_pool is None or _global_thread_pool._shutdown:
            _global_thread_pool = ThreadPoolExecutor(
                max_workers=max_workers,
                thread_name_prefix="StreamCinema-Worker"
            )
            debug(f"Created global thread pool with {max_workers} workers")
        
        return _global_thread_pool

def cleanup_global_thread_pool(timeout: float = 5.0) -> None:
    """
    Clean up the global thread pool.
    
    Args:
        timeout: Maximum time to wait for threads to finish
    """
    global _global_thread_pool
    
    with _thread_pool_lock:
        if _global_thread_pool is not None:
            debug("Shutting down global thread pool...")
            _global_thread_pool.shutdown(wait=True, timeout=timeout)
            _global_thread_pool = None
            debug("Global thread pool shutdown complete")

def is_main_thread() -> bool:
    """Check if current thread is the main thread"""
    return threading.current_thread() is threading.main_thread()

def ensure_main_thread(func: Callable) -> Callable:
    """
    Decorator to ensure function runs on main thread.
    
    For modern Kodi streaming, this is only needed when you actually
    use background threads (like speed testing or downloads).
    Most streaming operations run on main thread already.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if is_main_thread():
            return func(*args, **kwargs)
        else:
            debug('Function {} called from background thread {}, but main thread execution required'.format(
                func.__name__, threading.current_thread().name))
            # For modern Kodi, we should avoid complex marshaling
            # Instead, restructure code to avoid calling UI functions from background threads
            raise RuntimeError(
                'Function {} must be called from main thread. '
                'Restructure your code to avoid UI calls from background threads.'.format(func.__name__)
            )
    return wrapper

def run_on_main_thread(command: str) -> None:
    """Execute command safely on main thread using Kodi's executebuiltin"""
    if not is_main_thread():
        debug('Warning: executebuiltin called from background thread. This may cause issues.')
    
    try:
        xbmc.executebuiltin(command)
        debug('Executed main thread command: {}'.format(command))
    except Exception as e:
        debug('Error executing main thread command: {}'.format(str(e)))

def run_in_background(func: Callable, *args, timeout: float = 30.0, 
                     thread_name: Optional[str] = None, **kwargs) -> threading.Thread:
    """
    Run a function in a background thread with proper error handling and cleanup.
    
    Args:
        func: Function to run in background
        *args: Arguments for the function
        timeout: Maximum execution time in seconds
        thread_name: Optional custom thread name
        **kwargs: Keyword arguments for the function
        
    Returns:
        threading.Thread: The created thread
    """
    def safe_worker():
        thread_id = threading.get_ident()
        start_time = time.time()
        current_thread_name = threading.current_thread().name
        
        # Log thread start for monitoring
        try:
            from resources.lib.common.thread_monitor import log_thread_activity
            log_thread_activity('start', current_thread_name, func.__name__)
        except ImportError:
            pass  # Thread monitoring not available
        
        try:
            debug(f"Background thread {thread_id} started: {func.__name__}")
            result = func(*args, **kwargs)
            elapsed = time.time() - start_time
            debug(f"Background thread {thread_id} completed in {elapsed:.2f}s: {func.__name__}")
            
            # Log successful completion
            try:
                from resources.lib.common.thread_monitor import log_thread_activity
                log_thread_activity('end', current_thread_name, func.__name__, success=True)
            except ImportError:
                pass
            
            return result
        except Exception as e:
            elapsed = time.time() - start_time
            error_msg = str(e)
            debug(f"Background thread {thread_id} error after {elapsed:.2f}s: {func.__name__} - {error_msg}")
            
            # Log error
            try:
                from resources.lib.common.thread_monitor import log_thread_activity
                log_thread_activity('end', current_thread_name, func.__name__, success=False, error=error_msg)
            except ImportError:
                pass
            
            # Don't re-raise - let thread die gracefully
        finally:
            # Clean up thread reference
            with _thread_cleanup_lock:
                thread_key = f"{func.__name__}_{thread_id}"
                _active_threads.pop(thread_key, None)
    
    # Create thread with proper naming
    if thread_name is None:
        thread_name = f"StreamCinema-{func.__name__}-{int(time.time())}"
    
    thread = threading.Thread(
        target=safe_worker,
        name=thread_name,
        daemon=True  # Thread ends with plugin
    )
    
    # Track active thread
    with _thread_cleanup_lock:
        thread_key = f"{func.__name__}_{thread.ident or 'pending'}"
        _active_threads[thread_key] = thread
    
    thread.start()
    return thread

def run_concurrent(tasks: List[Callable], max_workers: int = 4, 
                  timeout: float = 30.0) -> List[Any]:
    """
    Run multiple tasks concurrently using the global thread pool.
    
    Args:
        tasks: List of callable tasks to run
        max_workers: Maximum number of concurrent workers
        timeout: Maximum time to wait for all tasks
        
    Returns:
        List[Any]: Results from all tasks (None for failed tasks)
    """
    if not tasks:
        return []
    
    thread_pool = get_global_thread_pool(max_workers)
    results = [None] * len(tasks)
    
    try:
        # Submit all tasks
        future_to_index = {
            thread_pool.submit(task): i 
            for i, task in enumerate(tasks)
        }
        
        # Collect results with timeout
        for future in as_completed(future_to_index, timeout=timeout):
            index = future_to_index[future]
            try:
                results[index] = future.result()
                debug(f"Concurrent task {index} completed successfully")
            except Exception as e:
                debug(f"Concurrent task {index} failed: {str(e)}")
                results[index] = None
                
    except Exception as e:
        debug(f"Concurrent execution error: {str(e)}")
        # Cancel remaining futures
        for future in future_to_index:
            if not future.done():
                future.cancel()
    
    return results

def cleanup_active_threads(timeout: float = 5.0) -> None:
    """
    Clean up all active threads.
    
    Args:
        timeout: Maximum time to wait for threads to finish
    """
    with _thread_cleanup_lock:
        if not _active_threads:
            return
        
        debug(f"Cleaning up {len(_active_threads)} active threads...")
        
        # Wait for threads to finish
        for thread_key, thread in list(_active_threads.items()):
            if thread.is_alive():
                thread.join(timeout=timeout / len(_active_threads))
                if thread.is_alive():
                    debug(f"Thread {thread_key} did not finish within timeout")
                else:
                    debug(f"Thread {thread_key} finished successfully")
            
            # Remove from tracking
            _active_threads.pop(thread_key, None)
        
        debug("Thread cleanup complete")

# Simplified dialog functions that work directly (no complex marshaling)
@ensure_main_thread
def safe_dialog_ok(heading: str, message: str) -> bool:
    """Thread-safe OK dialog - must be called from main thread"""
    from resources.lib.gui.dialog import dok
    return dok(heading, message)

@ensure_main_thread
def safe_dialog_yesno(heading: str, message: str, yeslabel: str = 'Yes', nolabel: str = 'No') -> bool:
    """Thread-safe Yes/No dialog - must be called from main thread"""
    from resources.lib.gui.dialog import dyesno
    return dyesno(heading, message, yeslabel, nolabel)

@ensure_main_thread
def safe_dialog_select(items: List, heading: str = '', use_details: bool = False) -> int:
    """Thread-safe select dialog - must be called from main thread"""
    from resources.lib.gui.dialog import dselect
    return dselect(items, heading, use_details)

@ensure_main_thread
def safe_dialog_progress():
    """Thread-safe progress dialog - must be called from main thread"""
    from resources.lib.gui.dialog import dprogressgb
    return dprogressgb()

def safe_notification(title: str, message: str, time: int = 5000, icon: str = '') -> None:
    """
    Thread-safe notification using executebuiltin.
    This is safe to call from any thread.
    """
    command = 'Notification({},{},{},{})'.format(title, message, time, icon)
    run_on_main_thread(command)

# For debugging/monitoring
def get_thread_info() -> Dict[str, Any]:
    """Get current thread information for debugging"""
    return {
        'thread_name': threading.current_thread().name,
        'is_main_thread': is_main_thread(),
        'thread_id': threading.get_ident(),
        'active_threads': len(_active_threads),
        'global_pool_active': _global_thread_pool is not None and not _global_thread_pool._shutdown
    }

def get_active_thread_count() -> int:
    """Get the number of active background threads"""
    with _thread_cleanup_lock:
        # Clean up dead threads while counting
        dead_threads = [
            key for key, thread in _active_threads.items() 
            if not thread.is_alive()
        ]
        for key in dead_threads:
            _active_threads.pop(key, None)
        
        return len(_active_threads)

# Context manager for thread-safe operations
class ThreadSafeOperation:
    """Context manager for thread-safe operations with timeout"""
    
    def __init__(self, operation_name: str, timeout: float = 30.0):
        self.operation_name = operation_name
        self.timeout = timeout
        self.start_time = None
        
    def __enter__(self):
        self.start_time = time.time()
        debug(f"Starting thread-safe operation: {self.operation_name}")
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed = time.time() - self.start_time
        if exc_type is None:
            debug(f"Thread-safe operation completed in {elapsed:.2f}s: {self.operation_name}")
        else:
            debug(f"Thread-safe operation failed after {elapsed:.2f}s: {self.operation_name} - {str(exc_val)}")
        
        # Check for timeout
        if elapsed > self.timeout:
            debug(f"Warning: Operation exceeded timeout ({self.timeout}s): {self.operation_name}")

# Legacy compatibility - these functions now just call the simple versions
def call_on_main_thread(func: Callable, *args, **kwargs) -> Any:
    """
    Legacy compatibility function.
    
    For modern Kodi, restructure your code to avoid this pattern.
    Use ensure_main_thread decorator instead.
    """
    debug('Warning: call_on_main_thread is deprecated. Use ensure_main_thread decorator instead.')
    if is_main_thread():
        return func(*args, **kwargs)
    else:
        raise RuntimeError('Complex main thread marshaling removed. Restructure code to call from main thread.')

def call_on_main_thread_async(func: Callable, *args, **kwargs) -> None:
    """
    Legacy compatibility function.
    
    For modern Kodi, restructure your code to avoid this pattern.
    """
    debug('Warning: call_on_main_thread_async is deprecated. Restructure code to avoid background UI calls.')
    if is_main_thread():
        return func(*args, **kwargs)
    else:
        debug('Ignoring async main thread call from background thread: {}'.format(func.__name__))

# Cleanup function to be called on addon shutdown
def cleanup_all_threading() -> None:
    """Clean up all threading resources"""
    debug("Cleaning up all threading resources...")
    cleanup_active_threads()
    cleanup_global_thread_pool()
    debug("Threading cleanup complete") 