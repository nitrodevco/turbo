import xbmcvfs
import xml.etree.ElementTree as ET

from resources.lib.common.logger import debug
from resources.lib.gui.dialog import dinput
from resources.lib.common.threading_utils import safe_dialog_yesno, safe_dialog_ok
from xbmcgui import INPUT_NUMERIC
import xbmc

from resources.lib.kodiutils import translate_path, get_system_platform, jsonrpc
from resources.lib.language import Strings


def set_kodi_cache_size():
    """
    Configure Kodi's video cache settings by safely modifying advancedsettings.xml.
    Preserves existing settings while updating only the cache configuration.
    
    Note: Uses binary MB (MiB = 1024^2 bytes) throughout for technical accuracy,
    as system memory is typically reported in binary units.
    
    Returns:
        bool: True if successful, False if user cancelled or operation failed
    """
    try:
        # Get and parse free memory
        free_mem_str = xbmc.getInfoLabel('System.FreeMemory')
        try:
            if 'MB' in free_mem_str:
                # Kodi typically reports in binary MB (MiB), treat as such
                free_mem = int(free_mem_str.replace('MB', '').strip())
            else:
                # Assume it's in bytes, convert to binary MB (MiB) using 1024^2
                free_mem = int(free_mem_str) / (1024 * 1024)
        except (ValueError, TypeError):
            debug('Error parsing free memory: {}'.format(free_mem_str))
            safe_dialog_ok('ERROR', 'Unable to determine system memory. Cache setup cancelled.')
            return False
        
        # Get user input for cache percentage
        msg = Strings.txt(Strings.SETUP_VIDEO_CACHE_MSG1)
        user_input = dinput(msg.format(int(free_mem)), '80', type=INPUT_NUMERIC)
        debug('user input: {}'.format(user_input))
        
        if not user_input or user_input.strip() == '':
            return False
        
        # Validate and process coefficient
        try:
            coefficient = int(user_input.replace('%', '').strip())
            # Proper range validation - fix the flawed 1 < coefficient > 80 logic
            if coefficient < 1 or coefficient > 80:
                debug('Coefficient {} out of range, clamping to valid range'.format(coefficient))
                coefficient = max(1, min(coefficient, 80))
        except (ValueError, TypeError):
            debug('Invalid coefficient input: {}'.format(user_input))
            safe_dialog_ok('ERROR', 'Invalid input. Please enter a number between 1 and 80.')
            return False
        
        filename = translate_path('special://userdata/advancedsettings.xml')
        
        debug('cache size: {} * {}% / 3 = {}'.format(
            free_mem, coefficient, int(free_mem / 3 * (coefficient/100))
        ))
        
        # Handle existing advancedsettings.xml safely
        root = None
        if xbmcvfs.exists(filename):
            res = safe_dialog_yesno('WARNING', Strings.txt(Strings.SETUP_VIDEO_CACHE_MSG2))
            if not res:
                return False
            
            # Try to parse existing XML to preserve other settings
            try:
                f = xbmcvfs.File(filename, 'r')
                content = f.read()
                f.close()
                if content:
                    root = ET.fromstring(content)
                    debug('Successfully parsed existing advancedsettings.xml')
            except (ET.ParseError, Exception) as e:
                debug('Error parsing existing advancedsettings.xml: {}'.format(e))
                # If we can't parse it, we'll create a new one after user confirmation
                res = safe_dialog_yesno('WARNING', 
                    'Existing advancedsettings.xml appears corrupted. Create new file?')
                if not res:
                    return False
                root = None
        
        # Create root element if none exists
        if root is None:
            root = ET.Element('advancedsettings')
        
        # Calculate cache size (in bytes) - using binary MB (MiB) for technical accuracy
        # LIBREELEC OPTIMIZATION: Increase cache for 1Gbit networks
        if coefficient > 80:  # High-end LibreELEC systems
            cache_size_mb = min(1024, int(free_mem / 2 * (coefficient/100)))  # Use more RAM on LibreELEC
        else:
            cache_size_mb = min(500, int(free_mem / 3 * (coefficient/100)))
        
        cache_size = int(cache_size_mb * 1024 * 1024)  # Convert to bytes (binary megabytes)
        debug('Cache size: {} MiB ({} bytes)'.format(cache_size_mb, cache_size))
        
        # Find or create cache element
        cache_elem = root.find('cache')
        if cache_elem is None:
            cache_elem = ET.SubElement(root, 'cache')
        
        # Update cache settings - remove existing cache children to avoid duplicates
        for child in list(cache_elem):
            cache_elem.remove(child)
        
        # LIBREELEC OPTIMIZATION: Enhanced cache configuration for 1Gbit streaming
        ET.SubElement(cache_elem, 'buffermode').text = '1'  # Cache all filesystems
        ET.SubElement(cache_elem, 'memorysize').text = str(cache_size)
        
        # NETWORK OPTIMIZATION: Optimized for 1Gbit networks
        ET.SubElement(cache_elem, 'readfactor').text = '8.0'  # Higher read factor for 1Gbit
        ET.SubElement(cache_elem, 'chunksize').text = '1048576'  # 1MB chunks for high bandwidth
        
        # LIBREELEC SPECIFIC: Network buffer optimizations
        network_elem = root.find('network')
        if network_elem is None:
            network_elem = ET.SubElement(root, 'network')
        
        # Clear existing network settings
        for child in list(network_elem):
            network_elem.remove(child)
        
        # 1GBIT OPTIMIZATION: Network settings for high-speed connections
        ET.SubElement(network_elem, 'curlclienttimeout').text = '30'
        ET.SubElement(network_elem, 'curllowspeedtime').text = '20'
        ET.SubElement(network_elem, 'curlretries').text = '2'
        ET.SubElement(network_elem, 'httpproxytype').text = '0'
        
        # LIBREELEC OPTIMIZATION: Increase network buffers for 1Gbit
        ET.SubElement(network_elem, 'cachemembuffersize').text = str(cache_size // 4)  # 25% of cache for network buffer
        
        # STREAMING OPTIMIZATION: Video player settings for high bandwidth
        videoplayer_elem = root.find('videoplayer')
        if videoplayer_elem is None:
            videoplayer_elem = ET.SubElement(root, 'videoplayer')
        
        # Clear existing videoplayer settings
        for child in list(videoplayer_elem):
            videoplayer_elem.remove(child)
        
        # 1GBIT STREAMING: Optimized video player settings
        ET.SubElement(videoplayer_elem, 'adjustrefreshrate').text = 'true'
        ET.SubElement(videoplayer_elem, 'usedisplayasclock').text = 'true'
        ET.SubElement(videoplayer_elem, 'synctype').text = 'audio'
        
        # LIBREELEC OPTIMIZATION: Hardware acceleration settings
        ET.SubElement(videoplayer_elem, 'usevaapi').text = 'true'  # Enable VAAPI on LibreELEC
        ET.SubElement(videoplayer_elem, 'usevdpau').text = 'true'  # Enable VDPAU if available
        ET.SubElement(videoplayer_elem, 'allowhwaccel').text = 'true'
        
        # PERFORMANCE: Audio settings for smooth playback
        audio_elem = root.find('audio')
        if audio_elem is None:
            audio_elem = ET.SubElement(root, 'audio')
        
        # Clear existing audio settings
        for child in list(audio_elem):
            audio_elem.remove(child)
        
        # LIBREELEC AUDIO: Optimized audio settings
        ET.SubElement(audio_elem, 'resample').text = '192000'
        ET.SubElement(audio_elem, 'stereoupmix').text = 'false'
        ET.SubElement(audio_elem, 'streamsilence').text = '1'
        
        # Write the updated XML with proper error handling
        try:
            # Format the XML nicely
            _indent_xml(root)
            
            # Convert to string
            xml_str = ET.tostring(root, encoding='unicode')
            formatted_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_str
            
            # Write to file
            f = xbmcvfs.File(filename, 'w')
            result = f.write(formatted_xml)
            f.close()
            
            if result:
                debug('Successfully updated advancedsettings.xml with cache settings')
            else:
                raise Exception('File write returned False')
            
        except Exception as e:
            debug('Error writing advancedsettings.xml: {}'.format(e))
            safe_dialog_ok('ERROR', 'Failed to save cache settings. Please check file permissions.')
            return False
        
        # Prompt for restart
        platform = get_system_platform()
        if platform in ['linux', 'windows']:
            res = safe_dialog_yesno('INFO', Strings.txt(Strings.SETUP_VIDEO_CACHE_MSG3))
            if res:
                jsonrpc(method="RestartApp")
        else:
            safe_dialog_ok('INFO', Strings.txt(Strings.SETUP_VIDEO_CACHE_MSG4))
        
        return True
        
    except Exception as e:
        debug('Unexpected error in set_kodi_cache_size: {}'.format(e))
        safe_dialog_ok('ERROR', 'An unexpected error occurred during cache setup.')
        return False


def _indent_xml(elem, level=0):
    """
    Add pretty-printing indentation to XML elements.
    """
    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for child in elem:
            _indent_xml(child, level+1)
        if not child.tail or not child.tail.strip():
            child.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


