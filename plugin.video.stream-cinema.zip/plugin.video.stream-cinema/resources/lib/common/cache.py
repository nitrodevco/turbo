import xbmcvfs
import xbmcgui
import xbmc
import datetime
import time
import sqlite3
import json

from resources.lib.common.logger import debug
from resources.lib.constants import ADDON


import threading

class SimpleCache(object):
    """simple stateless caching system for Kodi"""
    enable_mem_cache = True
    global_checksum = None
    _exit = False
    _auto_clean_interval = datetime.timedelta(hours=4)
    _win = None
    _busy_tasks = []
    _database = None
    _enabled = True
    # Class-level cleanup lock to prevent race conditions
    _cleanup_lock = threading.Lock()
    # Instance-level database connection for reuse
    _db_connection = None

    def __init__(self, enabled=True):
        """Initialize our caching class"""
        self._enabled = enabled
        self._win = xbmcgui.Window(10000)
        self._monitor = xbmc.Monitor()
        self.check_cleanup()
        self._log_msg("Initialized")

    def close(self):
        """tell any tasks to stop immediately (as we can be called multithreaded) and cleanup objects"""
        self._exit = True
        # wait for all tasks to complete with timeout to prevent hanging
        max_wait_time = 5.0  # 5 seconds maximum wait  
        wait_increment = 0.025  # 25ms increments
        wait_time = 0.0
        while self._busy_tasks and not self._monitor.abortRequested() and wait_time < max_wait_time:
            # Use Kodi-responsive sleep instead of blocking xbmc.sleep()
            if self._monitor.waitForAbort(wait_increment):
                break  # Kodi is shutting down, exit immediately
            wait_time += wait_increment
        
        if self._busy_tasks:
            self._log_msg("Warning: {} tasks still running during shutdown".format(len(self._busy_tasks)))
        
        # Close database connection if it exists
        if self._db_connection:
            try:
                self._db_connection.close()
            except:
                pass  # Ignore errors during shutdown
            self._db_connection = None
            
        del self._win
        del self._monitor
        self._log_msg("Closed")

    def __del__(self):
        """make sure close is called"""
        if not self._exit:
            self.close()

    def get(self, endpoint, checksum=""):
        """
            get object from cache and return the results
            endpoint: the (unique) name of the cache object as reference
            checkum: optional argument to check if the checksum in the cacheobject matches the checkum provided
        """
        if self._enabled is not True:
            return None
        checksum = self._get_checksum(checksum)
        cur_time = self._get_timestamp(datetime.datetime.now())
        result = None
        # 1: try memory cache first
        if self.enable_mem_cache:
            result = self._get_mem_cache(endpoint, checksum, cur_time)

        # 2: fallback to _database cache
        if result is None:
            result = self._get_db_cache(endpoint, checksum, cur_time)

        return result

    def set(self, endpoint, data, checksum="", expiration=datetime.timedelta(seconds=3600)):
        """
            set data in cache
        """
        task_name = "set.%s" % endpoint
        self._busy_tasks.append(task_name)
        
        try:
            checksum = self._get_checksum(checksum)
            expires = self._get_timestamp(datetime.datetime.now() + expiration)

            # memory cache: write to window property
            if self.enable_mem_cache and not self._exit:
                self._set_mem_cache(endpoint, checksum, expires, data)

            # db cache
            if not self._exit:
                self._set_db_cache(endpoint, checksum, expires, data)
        finally:
            # Ensure task is always removed from list to prevent memory leaks
            try:
                self._busy_tasks.remove(task_name)
            except ValueError:
                # Task was already removed, ignore
                pass

    def check_cleanup(self):
        """check if cleanup is needed - public method, may be called by calling addon"""
        # Prevent use after close
        if self._exit or not hasattr(self, '_win') or self._win is None:
            return
            
        cur_time = datetime.datetime.now()
        lastexecuted = self._win.getProperty("simplecache.clean.lastexecuted")
        if not lastexecuted:
            self._win.setProperty("simplecache.clean.lastexecuted", json.dumps(cur_time.isoformat()))
        else:
            try:
                last_time = datetime.datetime.fromisoformat(json.loads(lastexecuted))
                if (last_time + self._auto_clean_interval) < cur_time:
                    # cleanup needed...
                    self._do_cleanup()
            except (ValueError, TypeError):
                # Invalid date format, trigger cleanup
                self._do_cleanup()

    def _get_mem_cache(self, endpoint, checksum, cur_time):
        """
            get cache data from memory cache
            we use window properties because we need to be stateless
        """
        # Prevent use after close
        if self._exit or not hasattr(self, '_win') or self._win is None:
            return None
            
        result = None
        cachedata = self._win.getProperty(endpoint)

        if cachedata:
            try:
                # Use JSON instead of dangerous eval()
                cachedata = json.loads(cachedata)
                if cachedata[0] > cur_time:
                    if not checksum or checksum == cachedata[2]:
                        result = cachedata[1]
            except (ValueError, TypeError, IndexError):
                # Clear corrupted cache data
                self._win.clearProperty(endpoint)
        return result

    def _set_mem_cache(self, endpoint, checksum, expires, data):
        """
            window property cache as alternative for memory cache
            usefull for (stateless) plugins
        """
        # Prevent use after close
        if self._exit or not hasattr(self, '_win') or self._win is None:
            return
            
        cachedata = (expires, data, checksum)
        # Use JSON serialization instead of repr for security
        try:
            cachedata_str = json.dumps(cachedata)
            self._win.setProperty(endpoint, cachedata_str)
        except (TypeError, ValueError):
            # Data not JSON serializable, skip caching
            self._log_msg("Data not JSON serializable for endpoint: %s" % endpoint)

    def _get_db_cache(self, endpoint, checksum, cur_time):
        """get cache data from sqllite _database"""
        result = None
        query = "SELECT expires, data, checksum FROM simplecache WHERE id = ?"
        cache_data = self._execute_sql(query, (endpoint,))
        if cache_data:
            cache_data = cache_data.fetchone()
            if cache_data and cache_data[0] > cur_time:
                if not checksum or cache_data[2] == checksum:
                    try:
                        # Use JSON instead of dangerous eval()
                        result = json.loads(cache_data[1])
                        # also set result in memory cache for further access
                        if self.enable_mem_cache:
                            self._set_mem_cache(endpoint, checksum, cache_data[0], result)
                    except (ValueError, TypeError):
                        # Clear corrupted cache data
                        self._execute_sql("DELETE FROM simplecache WHERE id = ?", (endpoint,))
        return result

    def _set_db_cache(self, endpoint, checksum, expires, data):
        """ store cache data in _database """
        query = "INSERT OR REPLACE INTO simplecache( id, expires, data, checksum) VALUES (?, ?, ?, ?)"
        # Use JSON serialization instead of repr for security
        try:
            data_str = json.dumps(data)
            self._execute_sql(query, (endpoint, expires, data_str, checksum))
        except (TypeError, ValueError):
            # Data not JSON serializable, skip caching
            self._log_msg("Data not JSON serializable for endpoint: %s" % endpoint)

    def _do_cleanup(self):
        """perform cleanup task"""
        if self._exit or self._monitor.abortRequested():
            return
        # Use unique task identifier instead of module name to prevent race conditions
        import uuid
        cleanup_task_id = "cleanup.{}".format(uuid.uuid4().hex[:8])
        self._busy_tasks.append(cleanup_task_id)
        cur_time = datetime.datetime.now()
        cur_timestamp = self._get_timestamp(cur_time)
        self._log_msg("Running cleanup...")
        
        # Prevent use after close
        if not hasattr(self, '_win') or self._win is None:
            return
            
        # Use proper thread lock to prevent race condition
        if not SimpleCache._cleanup_lock.acquire(blocking=False):
            # Another cleanup is already running
            return
        
        try:
            # Also set window property for compatibility with external checks
            if hasattr(self, '_win') and self._win is not None:
                self._win.setProperty("simplecachecleanbusy", "busy")

            query = "SELECT id, expires FROM simplecache"
            for cache_data in self._execute_sql(query).fetchall():
                cache_id = cache_data[0]
                cache_expires = cache_data[1]

                if self._exit or self._monitor.abortRequested():
                    return

                # clean up db cache object only if expired
                if cache_expires < cur_timestamp:
                    query = 'DELETE FROM simplecache WHERE id = ?'
                    self._execute_sql(query, (cache_id,))
                    self._log_msg("delete from db %s" % cache_id)
                    
                    # Only clear memory cache for expired items, not all items
                    if hasattr(self, '_win') and self._win is not None:
                        self._win.clearProperty(cache_id)
                        self._log_msg("cleared memory cache for expired item %s" % cache_id)

            # compact db
            self._execute_sql("VACUUM")
            
            # Note: Memory cache items that don't exist in DB (orphaned) cannot be easily
            # cleaned up due to Kodi's window property system limitations (no enumeration).
            # However, since we now only use memory cache as acceleration for DB cache,
            # and clear memory items when their DB counterparts expire, this is acceptable.

            # remove task from list
            self._busy_tasks.remove(cleanup_task_id)
            
            # Only update window properties if window still exists
            if hasattr(self, '_win') and self._win is not None:
                self._win.setProperty("simplecache.clean.lastexecuted", json.dumps(cur_time.isoformat()))
                self._win.clearProperty("simplecachecleanbusy")
            self._log_msg("Auto cleanup done")
        finally:
            # Always release the cleanup lock
            SimpleCache._cleanup_lock.release()

    def _get_database(self):
        """get reference to our sqlite database - reuses connection when possible"""
        # Try to reuse existing connection first
        if self._db_connection:
            try:
                # Test if connection is still valid
                self._db_connection.execute('SELECT 1').fetchone()
                return self._db_connection
            except (sqlite3.ProgrammingError, sqlite3.OperationalError, sqlite3.DatabaseError):
                # Connection is stale, close it and create new one
                try:
                    self._db_connection.close()
                except:
                    pass
                self._db_connection = None
        
        # Create new connection
        dbpath = ADDON.getAddonInfo('profile')
        dbfile = xbmcvfs.translatePath("%s/simplecache.db" % dbpath)

        if not xbmcvfs.exists(dbpath):
            xbmcvfs.mkdirs(dbpath)
        try:
            connection = sqlite3.connect(dbfile, timeout=30, isolation_level=None)
            connection.execute('SELECT * FROM simplecache LIMIT 1')
            self._db_connection = connection
            return connection
        except Exception as error:
            # our _database is corrupt or doesn't exist yet, we simply try to recreate it
            if xbmcvfs.exists(dbfile):
                xbmcvfs.delete(dbfile)
            try:
                connection = sqlite3.connect(dbfile, timeout=30, isolation_level=None)
                connection.execute(
                    """CREATE TABLE IF NOT EXISTS simplecache(
                    id TEXT UNIQUE, expires INTEGER, data TEXT, checksum INTEGER)""")
                self._db_connection = connection
                return connection
            except Exception as error:
                self._log_msg("Exception while initializing _database: %s" % str(error), xbmc.LOGWARNING)
                self.close()
                return None

    def _execute_sql(self, query, data=None):
        """little wrapper around execute and executemany to just retry a db command if db is locked"""
        retries = 0
        result = None
        error = None
        
        while not retries == 10 and not self._monitor.abortRequested():
            if self._exit:
                return None
            
            _database = self._get_database()
            if _database is None:
                return None
                
            try:
                if isinstance(data, list):
                    result = _database.executemany(query, data)
                elif data:
                    result = _database.execute(query, data)
                else:
                    result = _database.execute(query)
                # Ensure changes are committed for isolation_level=None
                return result
            except sqlite3.OperationalError as error:
                if "database is locked" in str(error):
                    self._log_msg("retrying DB commit...")
                    retries += 1
                    self._monitor.waitForAbort(0.5)
                else:
                    break
            except Exception as error:
                break
                
        self._log_msg("database ERROR ! -- %s" % str(error), xbmc.LOGWARNING)
        return None

    @staticmethod
    def _log_msg(msg, loglevel=xbmc.LOGDEBUG):
        """helper to send a message to the kodi log"""
        debug("CACHE {}".format(msg))

    @staticmethod
    def _get_timestamp(date_time):
        """Converts a datetime object to unix timestamp"""
        return int(time.mktime(date_time.timetuple()))

    def _get_checksum(self, stringinput):
        """get better checksum from string to avoid collisions"""
        if not stringinput and not self.global_checksum:
            return 0
        if self.global_checksum:
            stringinput = "%s-%s" % (self.global_checksum, stringinput)
        else:
            stringinput = str(stringinput)
        
        # Use built-in hash() which is much better than simple addition
        # Convert to positive integer for consistency
        return abs(hash(stringinput)) % (2**31)


def use_cache(cache_days=14):
    """
        wrapper around our simple cache to use as decorator
        Usage: define an instance of SimpleCache with name "cache" (self.cache) in your class
        Any method that needs caching just add @use_cache as decorator
        NOTE: use unnamed arguments for calling the method and named arguments for optional settings
    """

    def decorator(func):
        """our decorator"""

        def decorated(*args, **kwargs):
            """process the original method and apply caching of the results"""
            method_class = args[0]
            method_class_name = method_class.__class__.__name__
            cache_str = "%s.%s" % (method_class_name, func.__name__)
            # cache identifier is based on positional args only
            # named args are considered optional and ignored
            for item in args[1:]:
                # Use repr() instead of str() to get more unique representations
                # and handle complex objects better
                try:
                    item_repr = repr(item)
                except:
                    # Fallback to str() if repr() fails
                    item_repr = str(item)
                cache_str += u".%s" % item_repr
            cache_str = cache_str.lower()
            cachedata = method_class.cache.get(cache_str)
            global_cache_ignore = False
            try:
                global_cache_ignore = method_class.ignore_cache
            except Exception:
                pass
            if cachedata is not None and not kwargs.get("ignore_cache", False) and not global_cache_ignore:
                return cachedata
            else:
                result = func(*args, **kwargs)
                method_class.cache.set(cache_str, result, expiration=datetime.timedelta(days=cache_days))
                return result

        return decorated

    return decorator
