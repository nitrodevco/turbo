"""
Thread Monitor Utility for Stream Cinema

This module provides thread monitoring and debugging capabilities
to help identify threading issues and ensure proper resource management.
"""

import threading
import time
from typing import Dict, List, Any, Optional
from resources.lib.common.logger import debug, info
import functools

class ThreadMonitor:
    """Monitor and track thread activity for debugging purposes"""
    
    def __init__(self):
        self._start_time = time.time()
        self._thread_history: List[Dict[str, Any]] = []
        self._max_history = 100  # Keep last 100 thread events
        self._lock = threading.Lock()
    
    def log_thread_start(self, thread_name: str, function_name: str) -> None:
        """Log when a thread starts"""
        with self._lock:
            event = {
                'event': 'start',
                'thread_name': thread_name,
                'function_name': function_name,
                'timestamp': time.time(),
                'thread_id': threading.get_ident()
            }
            self._thread_history.append(event)
            self._cleanup_history()
            
        debug(f"Thread started: {thread_name} ({function_name})")
    
    def log_thread_end(self, thread_name: str, function_name: str, 
                      success: bool = True, error: Optional[str] = None) -> None:
        """Log when a thread ends"""
        with self._lock:
            event = {
                'event': 'end',
                'thread_name': thread_name,
                'function_name': function_name,
                'timestamp': time.time(),
                'thread_id': threading.get_ident(),
                'success': success,
                'error': error
            }
            self._thread_history.append(event)
            self._cleanup_history()
            
        status = "successfully" if success else f"with error: {error}"
        debug(f"Thread ended {status}: {thread_name} ({function_name})")
    
    def get_active_threads(self) -> List[Dict[str, Any]]:
        """Get list of currently active threads"""
        active_threads = []
        
        for thread in threading.enumerate():
            if thread.is_alive():
                active_threads.append({
                    'name': thread.name,
                    'ident': thread.ident,
                    'daemon': thread.daemon,
                    'is_main': thread is threading.main_thread()
                })
        
        return active_threads
    
    def get_thread_summary(self) -> Dict[str, Any]:
        """Get a summary of thread activity"""
        with self._lock:
            active_threads = self.get_active_threads()
            
            # Count thread events
            start_events = [e for e in self._thread_history if e['event'] == 'start']
            end_events = [e for e in self._thread_history if e['event'] == 'end']
            error_events = [e for e in end_events if not e.get('success', True)]
            
            return {
                'monitor_uptime': time.time() - self._start_time,
                'active_thread_count': len(active_threads),
                'active_threads': active_threads,
                'total_threads_started': len(start_events),
                'total_threads_ended': len(end_events),
                'thread_errors': len(error_events),
                'recent_errors': error_events[-5:] if error_events else []
            }
    
    def log_summary(self) -> None:
        """Log a summary of thread activity"""
        summary = self.get_thread_summary()
        
        info("=== Thread Monitor Summary ===")
        info(f"Monitor uptime: {summary['monitor_uptime']:.1f}s")
        info(f"Active threads: {summary['active_thread_count']}")
        info(f"Total started: {summary['total_threads_started']}")
        info(f"Total ended: {summary['total_threads_ended']}")
        info(f"Errors: {summary['thread_errors']}")
        
        if summary['active_threads']:
            info("Active threads:")
            for thread in summary['active_threads']:
                thread_type = "main" if thread['is_main'] else "daemon" if thread['daemon'] else "regular"
                info(f"  - {thread['name']} ({thread_type})")
        
        if summary['recent_errors']:
            info("Recent errors:")
            for error in summary['recent_errors']:
                info(f"  - {error['thread_name']}: {error.get('error', 'Unknown error')}")
        
        info("=== End Thread Summary ===")
    
    def check_thread_health(self) -> Dict[str, Any]:
        """Check for potential threading issues"""
        issues = []
        warnings = []
        
        active_threads = self.get_active_threads()
        thread_count = len(active_threads)
        
        # Check for too many threads
        if thread_count > 20:
            issues.append(f"High thread count: {thread_count} active threads")
        elif thread_count > 10:
            warnings.append(f"Moderate thread count: {thread_count} active threads")
        
        # Check for non-daemon threads (potential memory leaks)
        non_daemon_threads = [t for t in active_threads if not t['daemon'] and not t['is_main']]
        if non_daemon_threads:
            issues.append(f"Non-daemon threads detected: {len(non_daemon_threads)}")
        
        # Check thread history for patterns
        with self._lock:
            recent_errors = [e for e in self._thread_history 
                           if e['event'] == 'end' and not e.get('success', True)
                           and time.time() - e['timestamp'] < 300]  # Last 5 minutes
            
            if len(recent_errors) > 5:
                issues.append(f"High error rate: {len(recent_errors)} thread errors in last 5 minutes")
        
        return {
            'healthy': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'thread_count': thread_count,
            'check_time': time.time()
        }
    
    def _cleanup_history(self) -> None:
        """Clean up old history entries"""
        if len(self._thread_history) > self._max_history:
            # Keep only the most recent entries
            self._thread_history = self._thread_history[-self._max_history:]

# Global thread monitor instance
_thread_monitor: Optional[ThreadMonitor] = None
_monitor_lock = threading.Lock()

def get_thread_monitor() -> ThreadMonitor:
    """Get the global thread monitor instance"""
    global _thread_monitor
    
    with _monitor_lock:
        if _thread_monitor is None:
            _thread_monitor = ThreadMonitor()
        return _thread_monitor

def log_thread_activity(event_type: str, thread_name: str, function_name: str, 
                       success: bool = True, error: Optional[str] = None) -> None:
    """Log thread activity to the global monitor"""
    try:
        monitor = get_thread_monitor()
        if event_type == 'start':
            monitor.log_thread_start(thread_name, function_name)
        elif event_type == 'end':
            monitor.log_thread_end(thread_name, function_name, success, error)
    except Exception as e:
        # Don't let monitoring errors affect the main functionality
        debug(f"Thread monitoring error: {str(e)}")

def get_thread_health_report() -> Dict[str, Any]:
    """Get a thread health report"""
    try:
        monitor = get_thread_monitor()
        return monitor.check_thread_health()
    except Exception as e:
        debug(f"Thread health check error: {str(e)}")
        return {
            'healthy': False,
            'issues': [f"Health check failed: {str(e)}"],
            'warnings': [],
            'thread_count': 0,
            'check_time': time.time()
        }

def log_thread_summary() -> None:
    """Log a summary of thread activity"""
    try:
        monitor = get_thread_monitor()
        monitor.log_summary()
    except Exception as e:
        debug(f"Thread summary error: {str(e)}")

# Decorator for automatic thread monitoring
def monitor_thread(func):
    """Decorator to automatically monitor thread execution"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        thread_name = threading.current_thread().name
        function_name = func.__name__
        
        log_thread_activity('start', thread_name, function_name)
        
        try:
            result = func(*args, **kwargs)
            log_thread_activity('end', thread_name, function_name, success=True)
            return result
        except Exception as e:
            log_thread_activity('end', thread_name, function_name, success=False, error=str(e))
            raise
    
    return wrapper 