# Kodi Threading Guidelines and Best Practices

## Overview

This document provides comprehensive guidelines for threading in Kodi 20+ plugins, based on official Kodi documentation and best practices. It covers when to use threads, how to use them properly, and what to avoid.

## Table of Contents

1. [Understanding Kodi's Plugin Lifecycle](#understanding-kodis-plugin-lifecycle)
2. [Threading Guidelines](#threading-guidelines)
3. [Main Thread vs Background Threads](#main-thread-vs-background-threads)
4. [UI Interaction from Threads](#ui-interaction-from-threads)
5. [Service Addons for Persistent Tasks](#service-addons-for-persistent-tasks)
6. [Error Handling in Threads](#error-handling-in-threads)
7. [Threading Utils Analysis](#threading-utils-analysis)
8. [Best Practices Summary](#best-practices-summary)
9. [Common Pitfalls](#common-pitfalls)
10. [Examples](#examples)

## Understanding Kodi's Plugin Lifecycle

### Key Concepts

**Threads initiated within a standard plugin path (e.g., during directory listing) are scoped to that specific plugin execution.** They do **not** persist across user actions (e.g., from browsing to playing). Each plugin invocation may run in a separate Python environment.

```python
# ❌ WRONG: This thread won't persist across plugin invocations
def plugin_main():
    def background_task():
        while True:  # This will die when plugin execution ends
            time.sleep(10)
            # Do something
    
    thread = threading.Thread(target=background_task, daemon=True)
    thread.start()
    # Plugin execution ends, thread dies
```

### Plugin Execution Model

- Each plugin call is a separate execution context
- Threads don't survive between different plugin actions
- Memory and state are not shared between invocations
- For persistent behavior, use **Kodi service addons**

## Threading Guidelines

### ✅ When to Use Threads

1. **Concurrent operations during a single plugin execution**
   ```python
   # ✅ GOOD: Multiple stream resolution during one execution
   def resolve_multiple_streams():
       threads = []
       results = {}
       
       def resolve_stream(url, index):
           results[index] = resolve_single_stream(url)
       
       for i, url in enumerate(stream_urls):
           thread = threading.Thread(target=resolve_stream, args=(url, i))
           threads.append(thread)
           thread.start()
       
       for thread in threads:
           thread.join()
       
       return results
   ```

2. **Fetching stream URLs or metadata before calling `xbmcplugin.setResolvedUrl()`**
   ```python
   # ✅ GOOD: Background metadata fetching
   def get_stream_with_metadata():
       metadata = {}
       
       def fetch_metadata():
           metadata['info'] = get_video_info()
           metadata['subtitles'] = get_subtitle_urls()
       
       thread = threading.Thread(target=fetch_metadata)
       thread.start()
       
       stream_url = resolve_stream_url()
       thread.join()  # Wait for metadata
       
       return stream_url, metadata
   ```

### ❌ When NOT to Use Threads

1. **For persistent background tasks across plugin invocations**
2. **For UI updates from background threads**
3. **For simple sequential operations**
4. **For operations that require user interaction**

## Main Thread vs Background Threads

### Main Thread Responsibilities

- All UI operations (dialogs, notifications, etc.)
- Plugin lifecycle management
- Kodi API calls that affect the UI
- `xbmcplugin` operations

### Background Thread Responsibilities

- Network requests
- File I/O operations
- Data processing
- Stream resolution
- Metadata fetching

### Thread Safety Rules

```python
# ✅ GOOD: Main thread for UI
def show_progress_dialog():
    if threading.current_thread() is threading.main_thread():
        dialog = xbmcgui.DialogProgress()
        dialog.create("Loading", "Please wait...")
        return dialog
    else:
        raise RuntimeError("UI operations must be on main thread")

# ✅ GOOD: Background thread for network
def fetch_data_background():
    def worker():
        data = requests.get("https://api.example.com/data")
        # Store result, don't update UI directly
        return data.json()
    
    thread = threading.Thread(target=worker)
    thread.start()
    return thread
```

## UI Interaction from Threads

### ❌ Never Do This

```python
# ❌ WRONG: UI operations from background thread
def background_worker():
    data = fetch_some_data()
    # This will cause issues!
    xbmcgui.Dialog().ok("Title", "Data fetched")
```

### ✅ Correct Approaches

#### 1. Use Main Thread for UI

```python
def safe_background_operation():
    def worker():
        # Do background work
        data = fetch_data()
        # Signal completion, don't update UI
        return data
    
    thread = threading.Thread(target=worker)
    thread.start()
    
    # Wait on main thread
    thread.join()
    
    # UI operations on main thread
    if data:
        xbmcgui.Dialog().ok("Success", "Data loaded")
```

#### 2. Use executebuiltin for Safe Notifications

```python
def safe_notification(title, message):
    """Thread-safe notification using executebuiltin"""
    command = f'Notification({title},{message},5000)'
    xbmc.executebuiltin(command)

# ✅ GOOD: Safe to call from any thread
def background_worker():
    try:
        data = fetch_data()
        safe_notification("Success", "Data loaded")
    except Exception as e:
        safe_notification("Error", str(e))
```

#### 3. Use Threading Utils Decorators

```python
from resources.lib.common.threading_utils import ensure_main_thread

@ensure_main_thread
def show_dialog(title, message):
    """This will only run on main thread"""
    return xbmcgui.Dialog().ok(title, message)

# Usage from any thread
def some_function():
    # This will raise an error if called from background thread
    # forcing you to restructure your code properly
    show_dialog("Info", "Hello")
```

## Service Addons for Persistent Tasks

For long-lived background tasks that need to persist across plugin invocations, use **Kodi service addons**:

### Service Addon Structure

```xml
<!-- addon.xml -->
<addon id="service.example" version="1.0.0">
    <extension point="xbmc.service" library="service.py" start="startup"/>
    <extension point="xbmc.addon.metadata">
        <summary>Example Service</summary>
        <description>Persistent background service</description>
    </extension>
</addon>
```

```python
# service.py
import threading
import time
import xbmc

class BackgroundService:
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.running = True
    
    def run(self):
        while not self.monitor.abortRequested() and self.running:
            # Do background work
            self.do_periodic_task()
            
            # Wait with abort checking
            if self.monitor.waitForAbort(60):  # 60 seconds
                break
    
    def do_periodic_task(self):
        # Your persistent background work here
        pass
    
    def stop(self):
        self.running = False

if __name__ == '__main__':
    service = BackgroundService()
    service.run()
```

### Communication Between Plugin and Service

```python
# In plugin
def communicate_with_service():
    # Use settings or files to communicate
    xbmcaddon.Addon('service.example').setSetting('command', 'refresh')

# In service
def check_commands(self):
    command = xbmcaddon.Addon().getSetting('command')
    if command == 'refresh':
        self.refresh_data()
        xbmcaddon.Addon().setSetting('command', '')  # Clear command
```

## Error Handling in Threads

### ✅ Always Catch Exceptions

```python
def safe_thread_worker():
    try:
        # Your thread work here
        result = do_network_request()
        return result
    except Exception as e:
        # Log the error - unhandled exceptions can crash Kodi
        xbmc.log(f"Thread error: {str(e)}", xbmc.LOGERROR)
        # Optionally notify user safely
        safe_notification("Error", "Operation failed")
        return None

def start_safe_thread():
    thread = threading.Thread(target=safe_thread_worker, daemon=True)
    thread.start()
    return thread
```

### Thread Cleanup

```python
class ThreadManager:
    def __init__(self):
        self.threads = []
    
    def start_thread(self, target, *args, **kwargs):
        thread = threading.Thread(target=target, args=args, kwargs=kwargs, daemon=True)
        self.threads.append(thread)
        thread.start()
        return thread
    
    def cleanup(self):
        """Clean up threads before plugin exit"""
        for thread in self.threads:
            if thread.is_alive():
                # Give threads a chance to finish
                thread.join(timeout=5.0)
        self.threads.clear()
```

## Threading Utils Analysis

Based on the improved `threading_utils.py` implementation:

### Current Implementation Strengths

1. **Clear thread detection**
   ```python
   def is_main_thread():
       return threading.current_thread() is threading.main_thread()
   ```

2. **Decorator for main thread enforcement**
   ```python
   @ensure_main_thread
   def ui_function():
       # Will only run on main thread
       pass
   ```

3. **Safe notification system**
   ```python
   def safe_notification(title, message, time=5000, icon=''):
       command = f'Notification({title},{message},{time},{icon})'
       run_on_main_thread(command)
   ```

4. **Global thread pool management**
   ```python
   def get_global_thread_pool(max_workers=4):
       # Returns managed ThreadPoolExecutor instance
       pass
   ```

5. **Background thread execution with monitoring**
   ```python
   def run_in_background(func, *args, timeout=30.0, thread_name=None, **kwargs):
       # Runs function in background with error handling and cleanup
       pass
   ```

6. **Concurrent task execution**
   ```python
   def run_concurrent(tasks, max_workers=4, timeout=30.0):
       # Runs multiple tasks concurrently with timeout
       pass
   ```

7. **Thread monitoring and health checks**
   ```python
   from resources.lib.common.thread_monitor import get_thread_health_report
   health = get_thread_health_report()
   ```

### Implemented Improvements

1. ✅ **Thread pool support for concurrent operations**
2. ✅ **Context managers for thread lifecycle** (`ThreadSafeOperation`)
3. ✅ **Better error handling and logging** (automatic in `run_in_background`)
4. ✅ **Timeout support for thread operations**
5. ✅ **Thread monitoring and health checking**
6. ✅ **Automatic cleanup and resource management**

## Best Practices Summary

### ✅ DO

- Use Python's `threading` module for concurrent operations within a single plugin execution
- Use `daemon=True` for threads that should end with the plugin
- Always join or cleanup threads where applicable
- Use `threading.Lock` when sharing data between threads
- Catch and log all exceptions in threads
- Use `xbmc.executebuiltin()` for thread-safe notifications
- Use service addons for persistent background tasks
- Keep UI operations on the main thread

### ❌ DON'T

- Use threads for persistent tasks across plugin invocations
- Call UI functions from background threads
- Use `xbmc.sleep()` or blocking I/O on the main thread
- Assume threads persist between plugin calls
- Leave threads running without proper cleanup
- Use complex thread marshaling patterns
- Block the main thread with network operations

## Common Pitfalls

### 1. Thread Persistence Assumption

```python
# ❌ WRONG: Assuming thread survives plugin restart
def plugin_main():
    if not hasattr(plugin_main, 'background_thread'):
        plugin_main.background_thread = start_background_task()
    # Thread won't survive between calls!
```

### 2. UI Updates from Background Threads

```python
# ❌ WRONG: Direct UI update from thread
def worker():
    data = fetch_data()
    xbmcgui.Dialog().ok("Done", "Finished")  # Will cause issues

# ✅ CORRECT: Signal main thread for UI update
def worker():
    data = fetch_data()
    safe_notification("Done", "Finished")
```

### 3. Blocking Main Thread

```python
# ❌ WRONG: Blocking main thread
def plugin_main():
    data = requests.get("http://slow-api.com")  # Blocks UI
    show_results(data)

# ✅ CORRECT: Background fetch
def plugin_main():
    def fetch_data():
        return requests.get("http://slow-api.com")
    
    thread = threading.Thread(target=fetch_data)
    thread.start()
    
    # Show progress while waiting
    progress = xbmcgui.DialogProgress()
    progress.create("Loading", "Fetching data...")
    
    while thread.is_alive():
        if progress.iscanceled():
            break
        xbmc.sleep(100)
    
    progress.close()
    thread.join()
```

## New Threading Utilities Usage

### Using the Improved Threading Utils

The addon now includes enhanced threading utilities that make it easier to follow Kodi best practices:

#### 1. Simple Background Tasks

```python
from resources.lib.common.threading_utils import run_in_background

def fetch_data():
    # Your background work here
    return data

# Run in background with automatic error handling
thread = run_in_background(fetch_data, timeout=30.0)
```

#### 2. Concurrent Operations

```python
from resources.lib.common.threading_utils import run_concurrent

def resolve_stream(url):
    # Resolve a single stream
    return resolved_url

# Create tasks for concurrent execution
tasks = [lambda: resolve_stream(url) for url in stream_urls]

# Run all tasks concurrently
results = run_concurrent(tasks, max_workers=4, timeout=30.0)
```

#### 3. Thread-Safe Operations with Context Manager

```python
from resources.lib.common.threading_utils import ThreadSafeOperation

with ThreadSafeOperation("Stream Resolution", timeout=30.0):
    # Your threaded operations here
    results = run_concurrent(tasks)
```

#### 4. Thread Monitoring

```python
from resources.lib.common.thread_monitor import get_thread_health_report, log_thread_summary

# Check thread health
health = get_thread_health_report()
if not health['healthy']:
    log_thread_summary()  # Log detailed information
```

#### 5. Automatic Cleanup

```python
from resources.lib.common.threading_utils import cleanup_all_threading

# Call during addon shutdown
cleanup_all_threading()
```

## Examples

### Example 1: Concurrent Stream Resolution

```python
import threading
import time
from resources.lib.common.threading_utils import safe_notification

def resolve_streams_concurrently(stream_urls):
    """Resolve multiple streams concurrently"""
    results = {}
    threads = []
    lock = threading.Lock()
    
    def resolve_single(url, index):
        try:
            # Simulate stream resolution
            resolved_url = resolve_stream_url(url)
            with lock:
                results[index] = resolved_url
        except Exception as e:
            xbmc.log(f"Failed to resolve stream {index}: {e}", xbmc.LOGERROR)
            with lock:
                results[index] = None
    
    # Start all threads
    for i, url in enumerate(stream_urls):
        thread = threading.Thread(
            target=resolve_single, 
            args=(url, i), 
            daemon=True
        )
        threads.append(thread)
        thread.start()
    
    # Wait for all to complete
    for thread in threads:
        thread.join(timeout=30)  # 30 second timeout
    
    # Filter successful results
    successful_streams = [url for url in results.values() if url is not None]
    
    if successful_streams:
        safe_notification("Success", f"Resolved {len(successful_streams)} streams")
        return successful_streams[0]  # Return first successful
    else:
        safe_notification("Error", "No streams could be resolved")
        return None
```

### Example 2: Background Metadata Fetching

```python
def get_video_with_metadata(video_url):
    """Fetch video URL and metadata concurrently"""
    metadata = {}
    
    def fetch_metadata():
        try:
            metadata['plot'] = get_video_description(video_url)
            metadata['duration'] = get_video_duration(video_url)
            metadata['thumbnail'] = get_video_thumbnail(video_url)
        except Exception as e:
            xbmc.log(f"Metadata fetch failed: {e}", xbmc.LOGERROR)
    
    # Start metadata fetch in background
    metadata_thread = threading.Thread(target=fetch_metadata, daemon=True)
    metadata_thread.start()
    
    # Get main video URL on main thread
    try:
        resolved_url = resolve_video_url(video_url)
    except Exception as e:
        safe_notification("Error", "Failed to resolve video")
        return None, {}
    
    # Wait for metadata (with timeout)
    metadata_thread.join(timeout=10)
    
    return resolved_url, metadata
```

### Example 3: Safe Dialog Usage

```python
from resources.lib.common.threading_utils import ensure_main_thread

class VideoPlayer:
    @ensure_main_thread
    def show_quality_dialog(self, qualities):
        """Show quality selection dialog - must be on main thread"""
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Select Quality", qualities)
        return selected if selected >= 0 else None
    
    def play_video(self, video_url):
        """Main play function"""
        # Get available qualities in background
        def get_qualities():
            return fetch_available_qualities(video_url)
        
        quality_thread = threading.Thread(target=get_qualities, daemon=True)
        quality_thread.start()
        quality_thread.join(timeout=15)
        
        qualities = get_qualities() if quality_thread.is_alive() else []
        
        if not qualities:
            safe_notification("Error", "No qualities available")
            return
        
        # Show dialog on main thread
        try:
            selected_quality = self.show_quality_dialog(qualities)
            if selected_quality is not None:
                final_url = resolve_quality_url(video_url, qualities[selected_quality])
                # Play the video
                play_resolved_url(final_url)
        except RuntimeError as e:
            # Handle main thread requirement error
            xbmc.log(f"UI operation failed: {e}", xbmc.LOGERROR)
            safe_notification("Error", "Please try again")
```

## Conclusion

Threading in Kodi plugins requires careful consideration of the plugin lifecycle, main thread requirements, and proper error handling. The key is to understand that threads are tools for concurrent operations within a single plugin execution, not for persistent background tasks. For persistent behavior, always use Kodi service addons.

Remember:
- **Threads are scoped to plugin execution**
- **UI operations must be on main thread**
- **Use service addons for persistence**
- **Always handle errors in threads**
- **Clean up threads properly**

Following these guidelines will help you create robust, responsive Kodi plugins that work reliably across different platforms and Kodi versions. 