import sys
from resources.lib.common.logger import info, debug
from resources.lib.kodiutils import create_plugin_url, container_update
from resources.lib.params import params

info('START : [{}]'.format(params.all))

# Handle skip button functionality from main thread
if len(params.all) > 0 and params.all[0] == 'show_skip':
    debug('Showing skip button from main thread')
    try:
        from resources.lib.services.SCPlayer import player
        if player and hasattr(player, 'skip_button') and player.skip_button:
            player.skip_button.show_with_callback(player.skipStart)
    except Exception as e:
        debug('Error showing skip button: {}'.format(str(e)))
elif len(params.all) > 3:
    # Original search functionality
    plugin_url = create_plugin_url({'url': '/Search/search-people?ms=1&id=search-people&search={}'.format(params.all[3])})
    container_update(plugin_url, True)
else:
    debug('Script called with unknown parameters: {}'.format(params.all))

# Script execution complete
debug('Script execution finished')
