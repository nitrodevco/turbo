# -*- coding: utf-8 -*-
"""
Test suite for the refactored Stream Cinema system.

This module demonstrates the new unified player and download manager functionality,
showing how the refactored system leverages Kodi's native capabilities.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import json


class TestStreamCinemaPlayer(unittest.TestCase):
    """Test cases for the new unified player system."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Mock Kodi modules
        self.mock_xbmc = Mock()
        self.mock_xbmcgui = Mock()
        self.mock_xbmcplugin = Mock()
        
        # Mock ListItem
        self.mock_listitem = Mock()
        self.mock_xbmcgui.ListItem.return_value = self.mock_listitem
        
        # Mock InfoTagVideo
        self.mock_info_tag = Mock()
        self.mock_listitem.getVideoInfoTag.return_value = self.mock_info_tag
        
        # Patch Kodi modules
        self.kodi_patches = [
            patch('resources.lib.player.xbmc', self.mock_xbmc),
            patch('resources.lib.player.xbmcgui', self.mock_xbmcgui),
            patch('resources.lib.player.xbmcplugin', self.mock_xbmcplugin),
        ]
        
        for patcher in self.kodi_patches:
            patcher.start()
    
    def tearDown(self):
        """Clean up test fixtures."""
        for patcher in self.kodi_patches:
            patcher.stop()
    
    def test_unified_player_creation(self):
        """Test that the unified player can be created successfully."""
        from resources.lib.player import StreamCinemaPlayer
        
        player = StreamCinemaPlayer()
        self.assertIsNotNone(player)
        self.assertEqual(player.addon_id, 'plugin.video.stream-cinema')
    
    def test_create_list_item_with_metadata(self):
        """Test ListItem creation with comprehensive metadata."""
        from resources.lib.player import StreamCinemaPlayer
        
        player = StreamCinemaPlayer()
        
        metadata = {
            'title': 'Test Movie',
            'originaltitle': 'Original Test Movie',
            'plot': 'A test movie plot',
            'year': 2023,
            'rating': 8.5,
            'duration': 7200,
            'genre': ['Action', 'Drama'],
            'director': ['Test Director'],
            'art': {
                'thumb': 'http://example.com/thumb.jpg',
                'poster': 'http://example.com/poster.jpg'
            },
            'cast': [
                {'name': 'Test Actor', 'role': 'Main Character', 'order': 0}
            ],
            'unique_ids': {'imdb': 'tt1234567'},
            'stream_info': {
                'video': {'width': 1920, 'height': 1080, 'codec': 'h264'},
                'audio': {'channels': 6, 'codec': 'ac3', 'language': 'en'}
            }
        }
        
        custom_headers = {
            'Authorization': 'Bearer test-token',
            'User-Agent': 'Test-Agent'
        }
        
        list_item = player._create_list_item(metadata, custom_headers)
        
        # Verify ListItem creation
        self.mock_xbmcgui.ListItem.assert_called_once_with(label='Test Movie')
        
        # Verify playable property
        self.mock_listitem.setProperty.assert_any_call('IsPlayable', 'true')
        
        # Verify headers
        expected_headers_json = json.dumps(custom_headers)
        self.mock_listitem.setProperty.assert_any_call('stream_headers', expected_headers_json)
        
        # Verify InfoTagVideo API usage
        self.mock_listitem.getVideoInfoTag.assert_called()
        self.mock_info_tag.setTitle.assert_called_with('Test Movie')
        self.mock_info_tag.setOriginalTitle.assert_called_with('Original Test Movie')
        self.mock_info_tag.setPlot.assert_called_with('A test movie plot')
        self.mock_info_tag.setYear.assert_called_with(2023)
        self.mock_info_tag.setRating.assert_called_with(8.5)
        self.mock_info_tag.setDuration.assert_called_with(7200)
        self.mock_info_tag.setGenres.assert_called_with(['Action', 'Drama'])
        self.mock_info_tag.setDirectors.assert_called_with(['Test Director'])
        
        # Verify artwork
        self.mock_listitem.setArt.assert_called_with({
            'thumb': 'http://example.com/thumb.jpg',
            'poster': 'http://example.com/poster.jpg'
        })
    
    def test_plugin_context_playback(self):
        """Test playback in plugin context using setResolvedUrl."""
        from resources.lib.player import StreamCinemaPlayer
        
        player = StreamCinemaPlayer()
        
        metadata = {'title': 'Test Stream'}
        stream_url = 'http://example.com/stream.mkv'
        plugin_handle = 123
        
        # Mock successful playback
        result = player.play_stream(stream_url, metadata, plugin_handle)
        
        # Verify setResolvedUrl was called
        self.mock_xbmcplugin.setResolvedUrl.assert_called_once()
        args = self.mock_xbmcplugin.setResolvedUrl.call_args[0]
        self.assertEqual(args[0], plugin_handle)  # handle
        self.assertTrue(args[1])  # succeeded
        
        # Verify URL was set on ListItem
        self.mock_listitem.setPath.assert_called_with(stream_url)
        
        self.assertTrue(result)
    
    def test_script_context_playback(self):
        """Test playback in script context using Player().play()."""
        from resources.lib.player import StreamCinemaPlayer
        
        player = StreamCinemaPlayer()
        
        metadata = {'title': 'Test Stream'}
        stream_url = 'http://example.com/stream.mkv'
        
        # Mock Player
        mock_player = Mock()
        self.mock_xbmc.Player.return_value = mock_player
        
        # Test script context (no plugin handle)
        result = player.play_stream(stream_url, metadata, plugin_handle=None)
        
        # Verify Player().play() was called
        self.mock_xbmc.Player.assert_called_once()
        mock_player.play.assert_called_once_with(stream_url, self.mock_listitem)
        
        self.assertTrue(result)
    
    def test_create_stream_headers(self):
        """Test stream headers creation utility."""
        from resources.lib.player import create_stream_headers
        
        # Mock user_agent function
        with patch('resources.lib.player.user_agent') as mock_user_agent:
            mock_user_agent.return_value = 'Default-User-Agent'
            
            headers = create_stream_headers(
                kraska_token='test-token',
                user_agent='Custom-Agent',
                referer='http://example.com',
                additional_headers={'Custom': 'Header'}
            )
            
            expected = {
                'User-Agent': 'Custom-Agent',
                'Authorization': 'Bearer test-token',
                'Referer': 'http://example.com',
                'Custom': 'Header'
            }
            
            self.assertEqual(headers, expected)


class TestStreamCinemaDownloadManager(unittest.TestCase):
    """Test cases for the new download manager system."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Mock Kodi modules
        self.mock_xbmc = Mock()
        self.mock_xbmcgui = Mock()
        
        # Patch Kodi modules
        self.kodi_patches = [
            patch('resources.lib.download_manager.xbmc', self.mock_xbmc),
            patch('resources.lib.download_manager.xbmcgui', self.mock_xbmcgui),
        ]
        
        for patcher in self.kodi_patches:
            patcher.start()
        
        # Mock settings
        self.settings_patcher = patch('resources.lib.download_manager.get_setting')
        self.mock_get_setting = self.settings_patcher.start()
        self.mock_get_setting.return_value = '/test/downloads'
        
        # Mock file system
        self.vfs_patcher = patch('xbmcvfs.exists')
        self.mock_vfs_exists = self.vfs_patcher.start()
        self.mock_vfs_exists.return_value = True
    
    def tearDown(self):
        """Clean up test fixtures."""
        for patcher in self.kodi_patches:
            patcher.stop()
        self.settings_patcher.stop()
        self.vfs_patcher.stop()
    
    def test_download_manager_creation(self):
        """Test that the download manager can be created successfully."""
        from resources.lib.download_manager import StreamCinemaDownloadManager
        
        manager = StreamCinemaDownloadManager()
        self.assertIsNotNone(manager)
        self.assertEqual(manager.addon_name, "Stream Cinema")
    
    def test_add_download_success(self):
        """Test successful download addition via JSON-RPC."""
        from resources.lib.download_manager import StreamCinemaDownloadManager
        
        manager = StreamCinemaDownloadManager()
        
        # Mock successful JSON-RPC response
        success_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"downloadid": 123}
        })
        self.mock_xbmc.executeJSONRPC.return_value = success_response
        
        # Mock path translation
        self.mock_xbmc.translatePath.return_value = '/translated/downloads'
        
        # Test download addition
        result = manager.add_download(
            download_url='http://example.com/movie.mkv',
            filename='test_movie.mkv',
            custom_headers={'Authorization': 'Bearer token'},
            title='Test Movie',
            thumbnail='http://example.com/thumb.jpg'
        )
        
        # Verify JSON-RPC was called
        self.mock_xbmc.executeJSONRPC.assert_called_once()
        
        # Verify the JSON-RPC call parameters
        call_args = self.mock_xbmc.executeJSONRPC.call_args[0][0]
        call_data = json.loads(call_args)
        
        self.assertEqual(call_data['method'], 'Download.Add')
        self.assertEqual(call_data['params']['url'], 'http://example.com/movie.mkv')
        self.assertEqual(call_data['params']['title'], 'Test Movie')
        self.assertEqual(call_data['params']['thumbnail'], 'http://example.com/thumb.jpg')
        self.assertIn('headers', call_data['params']['options'])
        self.assertEqual(call_data['params']['options']['headers']['Authorization'], 'Bearer token')
        
        self.assertTrue(result)
    
    def test_add_download_error(self):
        """Test download addition with JSON-RPC error."""
        from resources.lib.download_manager import StreamCinemaDownloadManager
        
        manager = StreamCinemaDownloadManager()
        
        # Mock error JSON-RPC response
        error_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "error": {"code": -1, "message": "Download failed"}
        })
        self.mock_xbmc.executeJSONRPC.return_value = error_response
        
        # Mock path translation
        self.mock_xbmc.translatePath.return_value = '/translated/downloads'
        
        # Test download addition with error
        result = manager.add_download(
            download_url='http://example.com/movie.mkv',
            filename='test_movie.mkv'
        )
        
        self.assertFalse(result)
    
    def test_get_downloads(self):
        """Test getting current downloads via JSON-RPC."""
        from resources.lib.download_manager import StreamCinemaDownloadManager
        
        manager = StreamCinemaDownloadManager()
        
        # Mock downloads response
        downloads_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "downloads": [
                    {"downloadid": 1, "title": "Movie 1", "progress": 50},
                    {"downloadid": 2, "title": "Movie 2", "progress": 100}
                ]
            }
        })
        self.mock_xbmc.executeJSONRPC.return_value = downloads_response
        
        downloads = manager.get_downloads()
        
        self.assertEqual(len(downloads), 2)
        self.assertEqual(downloads[0]['downloadid'], 1)
        self.assertEqual(downloads[1]['title'], 'Movie 2')
    
    def test_create_download_headers(self):
        """Test download headers creation utility."""
        from resources.lib.download_manager import create_download_headers
        
        headers = create_download_headers(
            kraska_token='test-token',
            user_agent='Custom-Agent',
            referer='http://example.com',
            additional_headers={'Custom': 'Header'}
        )
        
        expected = {
            'User-Agent': 'Custom-Agent',
            'Authorization': 'Bearer test-token',
            'Referer': 'http://example.com',
            'Custom': 'Header'
        }
        
        self.assertEqual(headers, expected)


class TestIntegration(unittest.TestCase):
    """Integration tests for the refactored system."""
    
    def test_legacy_compatibility(self):
        """Test that legacy functions still work with new system."""
        # Test legacy download function
        with patch('resources.lib.kodiutils.download_stream_legacy') as mock_legacy:
            mock_legacy.return_value = True
            
            from resources.lib.kodiutils import download
            result = download('http://example.com/file.mkv', '/downloads', 'file.mkv')
            
            mock_legacy.assert_called_once_with(
                'http://example.com/file.mkv', '/downloads', 'file.mkv'
            )
            self.assertTrue(result)
    
    def test_end_to_end_playback_flow(self):
        """Test complete playback flow from stream resolution to player."""
        # This would test the integration between:
        # 1. Stream resolution (existing)
        # 2. Metadata extraction (new)
        # 3. Header creation (new)
        # 4. Unified player (new)
        
        # Mock the complete flow
        with patch('resources.lib.player.StreamCinemaPlayer') as mock_player_class:
            mock_player = Mock()
            mock_player_class.return_value = mock_player
            mock_player.play_stream.return_value = True
            
            # Simulate the refactored play flow
            metadata = {'title': 'Test Movie', 'year': 2023}
            headers = {'Authorization': 'Bearer token'}
            
            from resources.lib.player import StreamCinemaPlayer
            player = StreamCinemaPlayer()
            
            result = player.play_stream(
                'http://example.com/stream.mkv',
                metadata,
                plugin_handle=123,
                custom_headers=headers
            )
            
            # In a real test, we would verify the complete integration
            # For now, just verify the mock was called correctly
            self.assertTrue(result)


if __name__ == '__main__':
    # Run the tests
    unittest.main() 